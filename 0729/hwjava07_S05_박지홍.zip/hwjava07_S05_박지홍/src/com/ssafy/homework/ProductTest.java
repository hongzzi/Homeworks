package com.ssafy.homework;

import java.util.Collection;
import java.util.HashMap;

public class ProductTest {

	public static void main(String[] args) {

		Product[] pdArr = { new TV("958479", "스마트뷰TV", 1600000, 5, 75), new TV("123456", "대우루컴즈TV", 2000000, 3, 65),
				new TV("654438", "삼성스마트TV", 5650000, 3, 55), new TV("321321", "LGTV", 500000, 12, 50),
				new TV("185475", "벽걸이TV", 650000, 2, 40), new Refrigerator("852852", "삼성냉장고", 4500000, 9, 450),
				new Refrigerator("258258", "딤채김치냉장고", 2600000, 2, 400),
				new Refrigerator("999999", "LG디오스 냉장고", 1500000, 8, 220),
				new Refrigerator("457877", "미니냉장고", 300000, 5, 220),
				new Refrigerator("323333", "양문형냉장고", 1900000, 10, 220),
				new SmartPhone("000000","삼성갤럭시노트10",1430000, 200,"SKT","Note10"),
				new SmartPhone("111111","LG V10",930000, 120,"KT","V10"),
				new SmartPhone("222222","아이폰 XR",1430000, 200,"SKT","XR"),
				new SmartPhone("333333","스카이 베가레이서",1430000, 200,"헬로모바일","베가레이서"),
				new SmartPhone("444444","모토로라 블랙베리",1430000, 200,"KT","블랙베리") };
		
		ProductMgrImpl pm = ProductMgrImpl.getPm();
		
		// 1. 상품 정보 저장
		System.out.println("**************************************** [1]. 상품 저장 \t\t****************************************\n");
		int index = 1;
		for (Product product : pdArr) {
			System.out.print(pm.addItem(product)+" / ");
		}
		System.out.println("\n\n");
		
		// 2. 상품 정보 전체를 검색
		System.out.println("**************************************** [2]. 상품 전체 검색 \t*************************************************\n");
		Collection<Product> pds = pm.getAllItems();
		for (Product product : pds) {
			System.out.println(product);
		}
		System.out.println("\n\n");
		
		// 3. 상품번호로 상품 검색
		System.out.println("**************************************** [3]. ISBN 상품검색 ( 457877 ) \t***************************************\n");
		Product product1 = pm.getItem("457877");
		System.out.println(product1);
		System.out.println("\n\n");
		
		// 4. 상품 명으로 상품 검색 ( 부분검색 ) 
		System.out.println("**************************************** [4]. 상품명으로 검색 ( 삼성 ) \t***************************************\n");
		Collection<Product> pds2 = pm.searchItemsBytitle("삼성");
		for (Product product : pds2) {
			System.out.println(product);
		}
		System.out.println("\n\n");
		
		// 5. TV 정보만 검색
		System.out.println("**************************************** [5]. TV 상품 전체 목록 \t***************************************\n");
		Collection<TV> tvs = pm.getAllTV();
		for (TV tv : tvs) {
			System.out.println(tv);
		}
		System.out.println("\n\n");
		
		// 6. 냉장고 정보만 검색
		System.out.println("**************************************** [6]. 냉장고 상품 전체 목록 \t***************************************\n");
		Collection<Refrigerator> refs = pm.getAllRef();
		for (Refrigerator ref : refs) {
			System.out.println(ref);
		}
		System.out.println("\n\n");
		
		// 7. 400L 이상 냉장고 정보만 검색
		System.out.println("**************************************** [7]. 400L 이상 냉장고 목록 \t***************************************\n");
		Collection<Refrigerator> refs2 = pm.searchRefByLiter();
		for (Refrigerator ref : refs2) {
			System.out.println(ref);
		}
		System.out.println("\n\n");
		
		// 8. 50인치 이상 TV만 검색
		System.out.println("**************************************** [8]. 50인치 이상 TV 목록 \t***************************************\n");
		Collection<TV> tvs2 = pm.getAllTV();
		for (TV tv : tvs) {
			System.out.println(tv);
		}
		System.out.println("\n\n");
		
		// 9. 상품번호와 가격을 입력 받아 상품 가격을 변경할 수 있음
		System.out.println("**************************************** [9]. 상품정보 업데이트 ( LG디오스 냉장고 가격 1500000 -> 2000000 ) \t***************************************\n");
		Product product2 = pm.getItem("999999");
		System.out.println("# 수정 전 : " + product2);
		System.out.println("# 업데이트 결과 : " + pm.updateItem("999999", 2000000));
		Product product3 = pm.getItem("999999");
		System.out.println("# 수정 후 : " + product3);
		System.out.println("\n\n");
		
		// 10. 상품번호로 상품 삭제
		System.out.println("**************************************** [10]. 상품정보 삭제 ( LG디오스 냉장고 ) \t***************************************\n");
		Product product4 = pm.getItem("999999");
		System.out.println("# 삭제 전 : " + product4);
		System.out.println(pm.removeItem("999999"));
		Product product5 = pm.getItem("999999");
		System.out.println("# 삭제 후 : " + product5);
		System.out.println("\n\n");
		
		// 11. 전체 재고 상품 금액을 구함
		System.out.println("**************************************** [11]. 전체 재고 금액 \t***************************************\n");
		System.out.printf("%,d 원",pm.getTotalPrice());
		System.out.println("\n\n");
		
		// 12. 상품명과 금액을 입력받아, 상품명을 포함하고 지정금액 이하일 경우 리턴
		System.out.println("**************************************** [12]. 조건에 맞는 상품 목록 ( key word : 스마트 , price : 2000000 ) \t***************************************\n");
		Collection<Product> pds3 = pm.searchDetail("스마트", 2000000);
		for (Product product : pds3) {
			System.out.println(product);
		}
		System.out.println("\n\n");
	}

}
