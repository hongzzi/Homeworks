package com.ssafy.homework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductMgrImpl implements IProductMgr {

	
	Map<String, Product> pds = new HashMap<>();
	
	private static ProductMgrImpl pmi= new ProductMgrImpl();
	
	private ProductMgrImpl() {}
	private ProductMgrImpl(Map<String, Product> pds) {
		this.pds = pds;
	}
	
	public static ProductMgrImpl getPm() {
		return pmi;
	}
	
	
	@Override
	public boolean addItem(Product product) {
		if(pds.containsKey(product.getIsbn())) {
			return false;
		}
		pds.put(product.getIsbn(), product);
		return true;
	}

	@Override
	public Collection<Product> getAllItems() {
		return pds.values();
	}

	@Override
	public Product getItem(String isbn) {
		return pds.get(isbn);
	}

	@Override
	public Collection<Product> searchItemsBytitle(String title) {
		List<Product> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd.getName().contains(title)) {
				temp.add(pd);
			}
		}
		return temp;
	}

	@Override
	public Collection<TV> getAllTV() {
		List<TV> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd instanceof TV) {
				TV tv = new TV();
				tv = (TV)pd;
				temp.add(tv);
			}
		}
		return temp;
	}

	@Override
	public Collection<Refrigerator> getAllRef() {
		List<Refrigerator> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd instanceof Refrigerator) {
				Refrigerator ref = new Refrigerator();
				ref = (Refrigerator)pd;
				temp.add(ref);
			}
		}
		return temp;
	}

	@Override
	public Collection<Refrigerator> searchRefByLiter() {
		List<Refrigerator> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd instanceof Refrigerator) {
				Refrigerator ref = new Refrigerator();
				ref = (Refrigerator)pd;
				if( ref.getSize() > 400 ) {
					temp.add(ref);
				}
			}
		}
		return temp;
	}

	@Override
	public Collection<TV> searchTVByInch() {
		List<TV> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd instanceof TV) {
				TV tv = new TV();
				tv = (TV)pd;
				if( tv.getSize() > 50 ) {
					temp.add(tv);
				}
			}
		}
		return temp;
	}

	@Override
	public boolean updateItem(String isbn, int price) {
		if(pds.containsKey(isbn)) {
			Product product = new Product();
			product = pds.get(isbn);
			product.setPrice(price);
			pds.put(isbn, product);
			return true;
		}
		return false;
	}

	@Override
	public boolean removeItem(String isbn) {
		if(pds.containsKey(isbn)) {
			pds.remove(isbn);
			return true;
		}
		return false;
	}

	@Override
	public long getTotalPrice() {
		
		long price = 0;
		for(Product pd : pds.values()) {
			price = price + pd.getStock()*pd.getPrice();
		}
		return price;
	}

	@Override
	public Collection<Product> searchDetail(String title, int price) {
		List<Product> temp = new ArrayList<>();
		for(Product pd : pds.values()) {
			if(pd.getName().contains(title) && pd.getPrice() <= price) {
				temp.add(pd);
			}
		}
		return temp;
	}

}
