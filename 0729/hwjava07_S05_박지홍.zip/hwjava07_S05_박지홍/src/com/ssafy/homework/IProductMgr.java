package com.ssafy.homework;

import java.util.Collection;

public interface IProductMgr {
	
	public boolean addItem(Product product);
	public Collection<Product> getAllItems();
	public Product getItem(String isbn);
	public Collection<Product> searchItemsBytitle(String title);
	public Collection<TV> getAllTV();
	public Collection<Refrigerator> getAllRef();
	public Collection<Refrigerator> searchRefByLiter();
	public Collection<TV> searchTVByInch();
	public boolean updateItem(String isbn, int price);
	public boolean removeItem(String isbn);
	public long getTotalPrice();
	public Collection<Product> searchDetail(String title, int price);
	
}
