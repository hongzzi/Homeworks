package com.ssafy.homework;

public class Refrigerator extends Product {

	private int size;
	
	public Refrigerator() {}
	
	public Refrigerator(String isbn, String name, int price, int stock, int size) {
		super(isbn, name, price, stock);
		this.size = size;
	}
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
	@Override
	public String toString() {
		return super.toString() + String.format("크기: %,5d L", size);
	}
	
}
