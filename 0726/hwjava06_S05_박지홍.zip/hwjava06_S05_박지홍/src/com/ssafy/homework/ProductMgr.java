package com.ssafy.homework;

import java.util.Scanner;

public class ProductMgr {

	Product [] pds = {	new TV("958479","스마트뷰TV",1600000, 5, 75),
						new TV("123456","대우루컴즈TV",2000000, 3, 65),
						new TV("654438","삼성스마트TV",5650000, 3, 55),
						new TV("321321","LGTV",500000, 12, 50),
						new TV("185475","벽걸이TV",650000, 2, 40),
						new Refrigerator("852852","삼성냉장고", 4500000, 9, 450),
						new Refrigerator("258258","딤채김치냉장고", 2600000, 2, 400),
						new Refrigerator("999999","LG디오스 냉장고", 1500000, 8, 220),
						new Refrigerator("457877","미니냉장고", 300000, 5, 220),
						new Refrigerator("323333","양문형냉장고", 1900000, 10, 220),
						new SmartPhone("000000","삼성갤럭시노트10",1430000, 200,"SKT","Note10"),
						new SmartPhone("111111","LG V10",930000, 120,"KT","V10"),
						new SmartPhone("222222","아이폰 XR",1430000, 200,"SKT","XR"),
						new SmartPhone("333333","스카이 베가레이서",1430000, 200,"헬로모바일","베가레이서"),
						new SmartPhone("444444","모토로라 블랙베리",1430000, 200,"KT","블랙베리")
			};
	private static ProductMgr pm = new ProductMgr();
	public static ProductMgr getProductMgr() {
		return pm;
	}
	
	// 첫 문장
	public static int print(Scanner sc) {
		
		StringBuilder sb = new StringBuilder();
		System.out.println(" ** 안녕하세요 고객님! 원하는 서비스를 선택해 주세요. ** \n");
		sb.append(" | 1. 재고금액 \n");
		sb.append(" | 2. 재고수량 \n");
		sb.append(" | 3. TV 평균 인치 \n");
		sb.append(" | 4. 냉장고 용량의 합계 \n");
		sb.append(" | 5. 스마트폰의 재고 수량의 합을 리턴하는 기능 \n");
		sb.append(" | 6. 상세검색 (상품명, 가격) \n");
		sb.append(" | 0. 종료 \n");
		System.out.println(sb);
		System.out.print(" [ 번호 입력 ] : ");
		int getNum = sc.nextInt();
		return getNum;
		
	}
	

	
	public long getPrice(Scanner sc) {
		System.out.println("1. TV\t\t 2. 냉장고\t 3. 스마트폰");
		int pd = sc.nextInt();
		long price = 0;
		if (pd == 1) {
			for(Product product : pds) {
				if(product instanceof TV) {
					TV tv = (TV)product;
					price += tv.getPrice()*tv.getStock();
				}
			}
		} else if (pd == 2) {
			for(Product product : pds) {
				if(product instanceof Refrigerator) {
					Refrigerator ref = (Refrigerator)product;
					price += ref.getPrice()*ref.getStock();
				}
			}
		} else if (pd == 3) {
			for(Product product : pds) {
				if(product instanceof SmartPhone) {
					SmartPhone phone = (SmartPhone)product;
					price += phone.getPrice()*phone.getStock();
				}
			}
		} else {
			System.out.println("없는 상품입니다.");
		}
		return price;
	}
	
	public int getStock(Scanner sc) {
		System.out.println("1. TV\t\t 2. 냉장고\t 3. 스마트폰");
		int pd = sc.nextInt();
		int stock = 0;
		if (pd == 1) {
			for(Product product : pds) {
				if(product instanceof TV) {
					TV tv = (TV)product;
					stock += tv.getStock();
				}
			}
		} else if (pd == 2) {
			for(Product product : pds) {
				if(product instanceof Refrigerator) {
					Refrigerator ref = (Refrigerator)product;
					stock += ref.getStock();
				}
			}
		} else if (pd == 3) {
			for(Product product : pds) {
				if(product instanceof SmartPhone) {
					SmartPhone phone = (SmartPhone)product;
					stock += phone.getStock();
				}
			}
		} else {
			System.out.println("없는 상품입니다.");
		}
		return stock;
	}
	
	public float avrageTvSize() {
		int size = 0;
		int cnt = 0;
		float avr = 0;
		for(Product product : pds) {
			if(product instanceof TV) {
				TV tv = (TV)product;
				size += tv.getSize();
				cnt ++;
			}
		}
		avr = (float)size / cnt;
		return avr;
	}
	
	public int sumRefSize() {
		int sumSize = 0;
		for(Product product : pds) {
			if(product instanceof Refrigerator) {
				Refrigerator ref = (Refrigerator)product;
				sumSize += ref.getSize();
			}
		}
		return sumSize;
	}
	
	public int sumPhoneStock() {
		int sumSize = 0;
		for(Product product : pds) {
			if(product instanceof SmartPhone) {
				SmartPhone phone = (SmartPhone)product;
				sumSize += phone.getStock();
			}
		}
		return sumSize;
	}
	
	public void searchProduct(Scanner sc) {
		
		
		System.out.print("찾으시는 제품명을 입력해주세요 : ");
		String title = sc.next();
		System.out.print("찾으시는 금액을 입력해주세요 : ");
		int price = sc.nextInt();
		
		System.out.println("찾으시는 상품의 목록은 아래와 같습니다.");
		System.out.println("=============================================================");
		int index = 1;
		for(Product product : pds) {
			if(product.getName().contains(title) && product.getPrice() <= price) {
				System.out.println((index++)+product.toString());
			}
		}
		System.out.println("=============================================================");
		
	}
	
	
	
}
