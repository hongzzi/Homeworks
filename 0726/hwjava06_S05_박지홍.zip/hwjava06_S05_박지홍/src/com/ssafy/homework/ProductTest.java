package com.ssafy.homework;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductMgr pm = ProductMgr.getProductMgr();
		Scanner sc = new Scanner(System.in);
		
		int choice = pm.print(sc);
		
		while(choice!=0) {
			switch (choice) {
			case 1:
				System.out.println("찾으시는 상품의 재고 금액은 "+pm.getPrice(sc)+"원 입니다.");
				break;
			case 2:
				System.out.println("찾으시는 상품의 재고 개수는 "+pm.getStock(sc)+"개 입니다.");
				break;
			case 3:
				System.out.println("TV재고의 평균 인치는 " + pm.avrageTvSize()+"입니다.");
				break;
			case 4:
				System.out.println("냉장고 재고의 리터 합계는 " + pm.sumRefSize()+"입니다.");
				break;
			case 5:
				System.out.println("스마트폰 재고 수량의 합계는 " + pm.sumPhoneStock()+"입니다.");
				break;
			case 6:
				pm.searchProduct(sc);
				break;	
			default:
				System.out.println("잘못된 번호를 입력하셨습니다. 다시 입력해주세요. ");
				break;
			}
			System.out.println();
			choice = pm.print(sc);
		}

	}

	
}
