package com.ssafy.news;

import java.util.Scanner;

public class NewsMain {

	public static void main(String[] args) {
		NewsDAODOMImpl dao = NewsDAODOMImpl.getDao();
		dao.getNewsList("http://rss.etnews.com/Section902.xml").forEach(news -> System.out.println(news));
		
		System.out.println("\n���ϴ� ����� ��ȣ�� �Է��� �ּ���!");
		Scanner sc = new Scanner(System.in);
		int index = sc.nextInt();
		System.out.println(dao.search(index));
	}

}
