package com.ssafy.news;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NewsDAODOMImpl implements INewsDAO{

	private static NewsDAODOMImpl dao = new NewsDAODOMImpl();
	
	public static NewsDAODOMImpl getDao() {
		return dao;
	}

	private NewsDAODOMImpl() {
		
	}
	
	private static List<News> list = new ArrayList<News>();
	
	@Override
	public List<News> getNewsList(String url) {
		connectionNews(url);
		return list;
	}

	@Override
	public News search(int index) {
		return list.get(index);
	}

	private void connectionNews (String url) {
		try {
			URL url2 = new URL(url);
			InputStream input = url2.openStream();

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(input);
			Element root = doc.getDocumentElement();
			
			NodeList datas = root.getElementsByTagName("item");
			for (int i = 0; i < datas.getLength(); i++) {
				News news = new News();
				list.add(news);
				Node node = datas.item(i);
				//String title, String desc, String link
				NodeList childs = node.getChildNodes();
				for (int j = 0; j < childs.getLength(); j++) {
					Node child = childs.item(j);
					if (child.getNodeName().equals("title")) {
						news.setTitle(child.getTextContent());
					} else if (child.getNodeName().equals("description")) {
						news.setDesc(child.getTextContent());
					} else if (child.getNodeName().equals("link")) {
						news.setLink(child.getTextContent());
					} 
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
