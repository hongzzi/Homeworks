package com.ssafy.todo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.todo.dto.Todo;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/rest")
public class MyRestController {

	Map<Long, Todo> todos = new HashMap<Long, Todo>();

	@GetMapping("/todo")
	@ApiOperation("모든 Todo객체 반환")
	public ResponseEntity<Map<String, Object>> todo() {
		try {
			return response(todos, HttpStatus.CREATED, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}

	// 일반적으로 프로젝트를 할땐 상태와 객체를 같이 표현해줌
	@PostMapping("/todo")
	@ApiOperation("새로운 Todo객체 추가")
	public ResponseEntity<Map<String, Object>> insert(@RequestBody Todo todo) {
		try {
			// 성공 시
			Todo old = todos.put(todo.getId(), todo);
			return response(old, HttpStatus.CREATED, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}

	@GetMapping("/todo/{id}")
	@ApiOperation("하나의 Todo 객체 반환")
	public ResponseEntity<Map<String, Object>> todo2(@PathVariable Long id) {
		try {
			return response(todos.get(id), HttpStatus.CREATED, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}

	// 개별 TODO 수정
	@PutMapping("/todo/{id}")
	@ApiOperation("url를 이용한 Todo 객체 수정")
	public ResponseEntity<Map<String, Object>> modify1(@PathVariable Long id,@RequestBody Todo todo) {
		try {
			return response(todos.put(todo.getId(), todo), HttpStatus.CREATED, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}

	// 개별 TODO 수정
	@PutMapping("/todo")
	@ApiOperation("Todo 객체 수정")
	public ResponseEntity<Map<String, Object>> modify2(@PathVariable Long id, Todo todo) {
		try {
			return response(todos.put(id, todo), HttpStatus.CREATED, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}

	@DeleteMapping("/todo/{id}")
	@ApiOperation("Todo객체 삭제")
	public ResponseEntity<Map<String, Object>> delete(@PathVariable Long id) {
		try {
			return response(todos.remove(id), HttpStatus.NO_CONTENT, true);
		} catch(RuntimeException e) {
			// 실패 시
			return response(e.getMessage(), HttpStatus.CONFLICT, false);
		}
	}
	
	private ResponseEntity<Map<String, Object>> response(Object data, HttpStatus httpstatus, boolean status) {
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("status", status);
		resultMap.put("data", data);
		return new ResponseEntity<Map<String,Object>>(resultMap, httpstatus);
	}
	
}
