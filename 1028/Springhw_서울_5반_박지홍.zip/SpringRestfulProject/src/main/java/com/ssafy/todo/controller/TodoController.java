package com.ssafy.todo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.todo.dto.Todo;

@Controller
public class TodoController {

	@GetMapping("/rest")
	@ResponseBody
	public String get() {
		return "Hello Rest";
	}
	
	@GetMapping("/todo")
	@ResponseBody
	public Todo restTodo() {
		return new Todo(1, "spring");
	}
}
