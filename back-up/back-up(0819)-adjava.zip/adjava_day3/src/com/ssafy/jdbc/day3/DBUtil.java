package com.ssafy.jdbc.day3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {
	private static DBUtil dbutil = new DBUtil();;
	private DBUtil() {
		
	}
	public static DBUtil getInstance() {
		return dbutil;
	}
	
	// database connection을 생성하고 반환하는 메서드
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		// 드라이버 로딩
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		// DB 접속 
		String url = "jdbc:mysql://localhost:3306/jdbc?serverTimezone=UTC";
		String user = "root";
		String password = "ssafy";
		return DriverManager.getConnection(url, user, password);
	}
	
	// database connection을 종료시키는 메서드
	public void close(Connection con) {	
		if(con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	// Connection과  statement를 종료시키는 메서드 : 얻을 때의 역순으로 close;
	public void close(Statement stmt, Connection con) {	// method overloading
		if(stmt!=null) {
			try {
				stmt.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		close(con);
	}
	// Connection과  statement를 종료시키는 메서드 : 얻을 때의 역순으로 close;
	public void close(ResultSet rset, Statement stmt, Connection con) {	// method overloading
		if(stmt!=null) {
			try {
				rset.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		close(stmt, con);
	}
}
