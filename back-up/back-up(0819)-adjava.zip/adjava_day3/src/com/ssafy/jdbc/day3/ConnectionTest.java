package com.ssafy.jdbc.day3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTest {
	
	public static void main(String[] args) {
		Connection con = null;

		try {
//			// 드라이버 로딩
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			
//			// DB 접속 
//			String url = "jdbc:mysql://localhost:3306/jdbc?serverTimezone=UTC";
//			String user = "root";
//			String password = "ssafy";
			con = DBUtil.getInstance().getConnection();
			
			System.out.println("접속!!!");
			
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 발견 오류");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("접속오류. url, id, pw확인.");
			e.printStackTrace();
		} finally {
			if(con != null) {
				try {
					con.close();
					System.out.println("접속 해제!!!");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		
	}
}
