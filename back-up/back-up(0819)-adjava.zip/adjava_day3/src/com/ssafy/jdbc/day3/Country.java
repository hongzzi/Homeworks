package com.ssafy.jdbc.day3;

import java.sql.Date;

public class Country {
	private Integer countryId;
	private String country;
	private Date last_update;
	
	public Country() {}
	
	
	private Country(Integer countryId, String country, Date last_update) {
		super();
		this.countryId = countryId;
		this.country = country;
		this.last_update = last_update;
	}


	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getLast_update() {
		return last_update;
	}
	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}

	@Override
	public String toString() {
		return "Country [countryId=" + countryId + ", country=" + country + ", last_update=" + last_update + "]";
	}
	
}
