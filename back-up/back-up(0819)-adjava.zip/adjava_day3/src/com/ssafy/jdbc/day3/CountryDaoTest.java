package com.ssafy.jdbc.day3;


public class CountryDaoTest {
	CountryDao dao = CountryDao.getDao();
	
	public static void main(String[] args) {
		CountryDaoTest cdt = new CountryDaoTest();
//		cdt.SelectAllTest();
		cdt.updateTest();
		cdt.selectTest();
		
//		cdt.insertTest();
	}
	public void updateTest() {
		dao.update(110, "자바나라");
	}
	
	public void insertTest() {
		dao.insert(110, "꿈나라");
	}
	
	public void SelectAllTest() {
		dao.selectAll();
	}
	
	public void selectTest() {
		dao.select2(110);
	}
}