package com.ssafy.jdbc.day3;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//import java.util.Date;
// data access object. 주로 쿼리 실행하는 모듈

public class CountryDao {
    private static CountryDao dao = new CountryDao();
    public static CountryDao getDao() {
        return dao;
    }
    private CountryDao() {
        
    }
    DBUtil util = DBUtil.getInstance();
    
    public void update(Country country)  {
    	String sql = "Update mycountry set country = ? where country_id = ?";
    	Connection con = null;
    	PreparedStatement pstmt = null;
    	try {
    		con = util.getConnection();
    		pstmt = con.prepareStatement(sql);
    		// prepared statement에 파라미터 세팅
    		pstmt.setString(1,  country.getCountry());
    		pstmt.setInt(2,  country.getCountryId());
    		int updated = pstmt.executeUpdate();
    		System.out.println(updated + "행이 영향을 받음 ");
    	} catch (SQLException | ClassNotFoundException e) {
    		e.printStackTrace();
    	} finally {
    		util.close(pstmt, con);
    	}
    }
    
    public void insert(Country country) {
    	String sql = "insert into mycountry (country_id, country) values(?, ?)";
    	Connection con = null;
    	PreparedStatement pstmt = null;
    	try {
    		con = util.getConnection();
    		pstmt = con.prepareStatement(sql);
    		// prepared statement에 파라미터 세팅
    		pstmt.setInt(1,  country.getCountryId());
    		pstmt.setString(2,  country.getCountry());
    		int updated = pstmt.executeUpdate();
    		System.out.println(updated + "행이 영향을 받음 ");
    	} catch (SQLException | ClassNotFoundException e) {
    		e.printStackTrace();
    	} finally {
    		util.close(pstmt, con);
    	}
    }
    
    public void select2(Country country) {
    	Country country1 = null; 
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rset = null;
        
        try {
            con = util.getConnection();
//            Statement stmt = con.createStatement();
            String query = "select * from mycountry where country_Id=?;";
//            String query = "select * from mycountry where country_Id = " + countryId + ";";
            pstmt = con.prepareStatement(query);
            pstmt.setInt(1,  country.getCountryId());
            rset = pstmt.executeQuery();
            
            while(rset.next()) {
//                int cId = rset.getInt(1);
//                String country = rset.getString(2);
//                Date lastUpdate = rset.getDate(3);
                country = new Country (countryId, rset.getString("country"), rset.getDate());
            }
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            util.close(rset, pstmt, con);
        }
    }
    
    
    public void select(Integer countryId) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rset = null;
        try {
            con = util.getConnection();
            stmt = con.createStatement();
            String query = "select * from mycountry where country_Id = " + countryId + ";";
            rset = stmt.executeQuery(query);
            
            while(rset.next()) {
                int cId = rset.getInt(1);
                String country = rset.getString(2);
                Date lastUpdate = rset.getDate(3);
                System.out.printf("id: %d, country: %s, date: %s\n", cId, country, lastUpdate);
            }
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            util.close(rset, stmt, con);
        }
    }
    
    public void selectAll() {
    	List<Country> list = new ArrayList<>();
        Connection con = null;
        Statement stmt = null;
        ResultSet rset = null;
        try {
            // 1. 접속
            con = util.getConnection();
            // 2. 쿼리
            stmt = con.createStatement();
            String query = "select * from mycountry";
            rset = stmt.executeQuery(query);        // 결과 확인을 위한 디비와의 통로(?) 개설
            Country nc = null;
            // 3. 결과 확인
            while(rset.next()) {
            	nc = new Country();
                nc.setCountryId(rset.getInt(1));                    // 컬럼 번호
                nc.setCountry(rset.getString("country"));        // 컬럼 레이블
                nc.setLast_Update(rset.getDate(3));
                System.out.printf("id: %d, country: %s, date: %s\n", nc.getCountryId, nc.country, nc.lastUpdate);
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 4. 리소스 반납
            util.close(rset, stmt, con);
        }
        
    }
}