package com.ssafy.work;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.jdbc.day3.Country;

public class BookDAO {

	private static BookDAO dao = new BookDAO();

	public static BookDAO getDao() {
		return dao;
	}

	public void insertBook(Book book) {
		String sql = "insert into book values(?, ?, ?, ?, ?, ?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = dao.getConnection();
			pstmt = con.prepareStatement(sql);
			// prepared statement에 파라미터 세팅
			pstmt.setString(1, book.getIsbn());
			pstmt.setString(2, book.getTitle());
			pstmt.setString(3, book.getAuthor());
			pstmt.setString(4, book.getPublisher());
			pstmt.setInt(5, book.getPrice());
			pstmt.setString(6, book.getDescription());
			int updated = pstmt.executeUpdate();
			System.out.println(updated + "행이 영향을 받음 ");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			dao.close(pstmt, con);
		}
	}

	public void updateBook(Book book) {
		String sql = "Update book set price = ? where isbn = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = dao.getConnection();
			pstmt = con.prepareStatement(sql);
			// prepared statement에 파라미터 세팅
			pstmt.setInt(1, book.getPrice());
			pstmt.setString(2, book.getIsbn());
			int updated = pstmt.executeUpdate();
			System.out.println(updated + "행이 영향을 받음 ");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			dao.close(pstmt, con);
		}
	}

	public void deleteBook(String isbn) {
		String sql = "delete from book where isbn = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = dao.getConnection();
			pstmt = con.prepareStatement(sql);
			// prepared statement에 파라미터 세팅
			pstmt.setString(1, isbn);
			int updated = pstmt.executeUpdate();
			System.out.println(updated + "행이 영향을 받음 ");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			dao.close(pstmt, con);
		}
	}

	public void findBook(String isbn) {
    	Book book = null; 
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rset = null;
        
        try {
            con = dao.getConnection();
            String query = "select * from book where isbn=?;";
            pstmt = con.prepareStatement(query);
            pstmt.setString(1, isbn);
            rset = pstmt.executeQuery();
            
            while(rset.next()) {
            	book = new Book(rset.getString(1),rset.getString(2),rset.getString(3),rset.getString(4),rset.getInt(5),rset.getString(6));
            	System.out.printf("isbn: %s, title: %s, author: %s, publisher: %s, price: %d, description: %s\n", book.getIsbn(), book.getTitle(), book.getAuthor(), book.getPublisher(), book.getPrice(), book.getDescription());
            }
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dao.close(rset, pstmt, con);
        }
	}

	public List<Book> listBooks() {
		List<Book> list = new ArrayList<>();
		Connection con = null;
		Statement stmt = null;
		ResultSet rset = null;
		try {
			// 1. 접속
			con = dao.getConnection();
			// 2. 쿼리
			stmt = con.createStatement();
			String query = "select * from book";
			rset = stmt.executeQuery(query); // 결과 확인을 위한 디비와의 통로(?) 개설
			Book book = null;
			// 3. 결과 확인
			while (rset.next()) {
				book = new Book();
				book.setIsbn(rset.getString(1)); // 컬럼 번호
				book.setTitle(rset.getString(2)); // 컬럼 레이블
				book.setAuthor(rset.getString(3));
				book.setPublisher(rset.getString(4));
				book.setPrice(rset.getInt(5));
				book.setDescription(rset.getString(6));
				
				list.add(book);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 4. 리소스 반납
			dao.close(rset, stmt, con);
			return list;
		}

	}
	
//	public int count() {
//		
//	}

	// database connection을 생성하고 반환하는 메서드
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		// 드라이버 로딩
		Class.forName("com.mysql.cj.jdbc.Driver");

		// DB 접속
		String url = "jdbc:mysql://localhost:3306/jdbc?serverTimezone=UTC";
		String user = "root";
		String password = "ssafy";
		return DriverManager.getConnection(url, user, password);
	}

	// database connection을 종료시키는 메서드
	public void close(Connection con) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// Connection과 statement를 종료시키는 메서드 : 얻을 때의 역순으로 close;
	public void close(Statement stmt, Connection con) { // method overloading
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		close(con);
	}

	// Connection과 statement를 종료시키는 메서드 : 얻을 때의 역순으로 close;
	public void close(ResultSet rset, Statement stmt, Connection con) { // method overloading
		if (stmt != null) {
			try {
				rset.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		close(stmt, con);
	}

}
