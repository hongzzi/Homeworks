package com.ssafy.work;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

public class BookMgrImpl implements IBookMgr {

	private List<Book> books = new ArrayList<>();

	private static BookMgrImpl bmi = new BookMgrImpl();

	private BookMgrImpl() {
	}

	private BookMgrImpl(List<Book> books) {
		this.books = books;
	}

	public static BookMgrImpl getBookMgrImpl() {
		return bmi;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	@Override
	public boolean addBook(Book book) {
		for (Book b : books) {
			if (book.getIsbn().equals(b.getIsbn())) {
				return false;
			}
		}
		books.add(book);
		return true;
	}

	@Override
	public Collection<Book> getAllBook() {
		return books;
	}

	@Override
	public Book getBook(String isbn) {
		Book book = new Book();
		for(Book b : books) {
			if (b.getIsbn().equals(isbn)) {
				book = (Book)b;
			}
		}
		return book;
	}

	@Override
	public Collection<Book> getTitleBook(String title) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = new Book();
		for(Book b : books) {
			if (b.getTitle().contains(title)) {
				book = (Book)b;
				bks.add(book);
			}
		}
		return bks;
	}

	@Override
	public Collection<Book> getOnlyBook() {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = new Book();
		for(Book b : books) {
			if(!(b instanceof Magazine)) {
				book = (Book)b;
				bks.add(book);
			}
		}
		return bks;
	}

	@Override
	public Collection<Magazine> getOnlyMaga() {
		Collection<Magazine> mgs = new ArrayList<Magazine>();
		Magazine maga = new Magazine();
		for(Book b : books) {
			if(b instanceof Magazine) {
				maga = (Magazine)b;
				mgs.add(maga);
			}
		}
		return mgs;
	}

	@Override
	public Collection<Magazine> getOnlyThisYear(int year) {
		Collection<Magazine> mgs = new ArrayList<Magazine>();
		Magazine maga = new Magazine();
		for(Book b : books) {
			if (b instanceof Magazine) {
				maga = (Magazine)b;
				if(maga.getYear() == year) {
					mgs.add(maga);
				}
			}
		}
		return mgs;
	}

	@Override
	public Collection<Book> searchPublisher(String publisher) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = new Book();
		for(Book b : books) {
			if(b.getPublisher().equals(publisher)) {
				bks.add(b);
			}
		}
		return bks;
	}

	@Override
	public Collection<Book> searchByPrice(int price) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = new Book();
		for(Book b : books) {
			if(b.getPrice() <= price) {
				bks.add(b);
			}
		}
		return bks;
	}

	@Override
	public int getSumPrice() {
		int sumPrice = 0;
		for (Book book : books) {
			sumPrice += book.getPrice();
		}
		return sumPrice;
	}

	@Override
	public int getAvrPrice() {
		int sum = this.getSumPrice();
		return sum/books.size();
	}
	
//	List<Book> temp = new ArrayList<>(magazine);
//	// 출력 시 Book 이 가지고 있는 가격 오름차순으로 정렬하시오.
//	// 단 가격이 가을 경우 ISBN 순으로 
//	Collection.sort(temp, )
	

}
