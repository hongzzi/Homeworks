package com.ssafy.work;

import java.util.Collection;

public interface IBookMgr {

	public boolean addBook(Book book);
	public Collection<Book> getAllBook();
	public Book getBook(String isbn);
	public Collection<Book> getTitleBook(String title);
	public Collection<Book> getOnlyBook();
	public Collection<Magazine> getOnlyMaga(); 
	public Collection<Magazine> getOnlyThisYear(int year);
	public Collection<Book> searchPublisher(String publisher);
	public Collection<Book> searchByPrice(int price);
	public int getSumPrice();
	public int getAvrPrice();
}
