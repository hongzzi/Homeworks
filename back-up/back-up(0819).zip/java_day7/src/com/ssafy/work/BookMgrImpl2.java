package com.ssafy.work;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class BookMgrImpl2 implements IBookMgr {

	private Map<String, Book> map = new HashMap<>();
	
	private static BookMgrImpl2 bmi2 = new BookMgrImpl2();
	
	private BookMgrImpl2() {}
	private BookMgrImpl2(Map map) {
		this.map = map;
	}
	
	public static BookMgrImpl2 getBookMgrImpl2() {
		return bmi2;
	}
	
	@Override
	public boolean addBook(Book book) {
		if(map.containsKey(book.getIsbn())) {
			return false;
		}
		map.put(book.getIsbn(), book);
		return true;
	}

	@Override
	public Collection<Book> getAllBook() {
		return map.values();
	}

	@Override
	public Book getBook(String isbn) {
		return map.get(isbn);
	}

	@Override
	public Collection<Book> getTitleBook(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Book> getOnlyBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Magazine> getOnlyMaga() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Magazine> getOnlyThisYear(int year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Book> searchPublisher(String publisher) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Book> searchByPrice(int price) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSumPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getAvrPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

}
