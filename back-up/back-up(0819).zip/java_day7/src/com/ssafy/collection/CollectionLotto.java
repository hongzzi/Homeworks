package com.ssafy.collection;

import java.util.*;

public class CollectionLotto {
	// 각각 6개의 랜덤 값으로 1~45까지의 숫자를 갖는 lotto 만들기
	Random rd = new Random();

	public void makeLottoBySet() {

		Set<Integer> lotto = new HashSet<>();
		/*
		 * for (int i = 0; i < 6; i++) { int a = rd.nextInt(45) + 1; if
		 * (!lotto.equals(a)) { lotto.add(a); } }
		 */
		while (lotto.size() < 6) {
			lotto.add(rd.nextInt(45) + 1);
		}
		System.out.println("set : " + lotto);
//		Collections.sort();
		List<Integer> list = new ArrayList<>(lotto);
		Collections.sort(list);
		System.out.println("Set sort : "+list);
		// SET은 정렬이 안됌
	}

	public void makeLottoByList() {
		List<Integer> lotto = new LinkedList<>();
		while (lotto.size() < 6) {
			int num = rd.nextInt(45) + 1;
			if(!lotto.contains(num)) {
				lotto.add(num);
			}
		}
		System.out.println("list : " + lotto);
		Collections.sort(lotto);
		System.out.println("list sort : " + lotto);
	}
	
	public void makeLottoByMap() {
		//    공	  빈도수
		Map<Integer, Integer> lotto = new HashMap<>();
		int num;
		for(int i = 0; i<1000000; i++) {
			num = rd.nextInt(45)+1;
			if (lotto.containsKey(num)) {
				int value = lotto.get(num)+1;
				lotto.put(num, value);
			} else {
				lotto.put(num, 1);
			}
		}
		System.out.println("Map : " + lotto);
		
		
		List<Integer> balls = new ArrayList<>(lotto.keySet());
		Collections.sort(balls, new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				return lotto.get(o1).compareTo(lotto.get(o2))*-1;
			}
			
		});
		
		// 람다 :3 
		List<Integer> balls2 = new ArrayList<>(lotto.keySet());
		Collections.sort(balls, new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				return lotto.get(o1).compareTo(lotto.get(o2))*-1;
			}
			
		});
		
		List<Integer> balls3 = new ArrayList<>(lotto.keySet());
		Collections.sort(balls3, (o1, o2) -> lotto.get(o1).compareTo(lotto.get(o2))*-1);

		
		System.out.println(balls);
		System.out.println(balls.subList(0,6));
		
		
	}

	public static void main(String[] args) {
		CollectionLotto cl = new CollectionLotto();
		cl.makeLottoBySet();
		cl.makeLottoByList();
		cl.makeLottoByMap();
	}
}
