package com.ssafy.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set = new TreeSet<>();
		set.add("Hello");
		set.add("World");
		set.add("Dream");
		set.add("Java");
		
		System.out.println(set);
		
		Set<HandPhone> set2 = new TreeSet<>();
		set2.add(new HandPhone("010",100));
		set2.add(new HandPhone("011",130));
		set2.add(new HandPhone("012",160));
		set2.add(new HandPhone("013",190));
		
		System.out.println(set2);
		
		List<HandPhone> list = new ArrayList<>();
		list.addAll(set2);
		HandPhoneComparetor hc = new HandPhoneComparetor();
		Collections.sort(list, hc);
		System.out.println(list);
		
		// 중 요 중 요 
		Collections.sort(list, new Comparator<HandPhone>() {
			// inner클래스를 객체로 만들어서 넣음... 
			@Override
			public int compare(HandPhone o1, HandPhone o2) {
				// TODO Auto-generated method stub
				return o1.number.compareTo(o2.number);
			}
		});
		
		List<String> strList = Arrays.asList("Dream","is","come","true");
		Collections.sort(strList, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				if(o1.length() == o2.length())
					return o1.compareTo(o2);
				return Integer.valueOf(o1.length()).compareTo(Integer.valueOf(o2.length()));
			}
		});
		System.out.println(strList);
	}

}


//// inner class , static 이 없으므로 
//class HandPhoneComparetor implements Comparator<HandPhone> {
//
//	@Override
//	public int compare(HandPhone o1, HandPhone o2) {
//		return o1.number.compareTo(o2.number);
//
//	}
//
//}
