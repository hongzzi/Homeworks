package com.ssafy.collection;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

// 정렬 comparable & comparator 
public class HandPhone implements Comparable<HandPhone>{
	public String number;
	public int price;
	
	public HandPhone() {}
	public HandPhone(String number, int price) {
		super();
		this.number = number;
		this.price = price;
	}
	
	// 
	@Override
	public int hashCode() {
		return this.number.hashCode()+price;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj != null && obj instanceof HandPhone) {
			HandPhone other = (HandPhone)obj;
			return this.number.equals(other.number);
		}
		return false;
	}
	
	@Override
	public String toString() {
		return "HandPhone [number=" + number + ", price=" + price + "]";
	}
	
	@Override
	public int compareTo(HandPhone o) {
		
//		return this.number.compareTo(o.number)*-1;
//		if(this.price > o.price) {
//			return 1;
//		}else if (this.price < o.price) {
//			return -1;
//		}else 
//			return 0;
//		return this.price - o.price;
		return Integer.valueOf(this.price).compareTo(Integer.valueOf(o.price));
	}
	

	
	
	
}
