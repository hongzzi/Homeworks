package com.ssafy.collection;

import java.util.*;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class MapTest {
	
	Map<String, String> map = new HashMap<>();
	
	public void addTest() {
		map.put("지홍", "25");
		map.put("장성", "24");
		map.put("장성", "27");
		map.put("모름", "24");
		System.out.println(map);
	}
	public void getTest() {
		System.out.println("크기: " + map.size());
		System.out.println(map.containsKey("장성")+" : "+map.containsValue("27"));
		System.out.println(map.get("지홍"));
		System.out.println(map.keySet());
		System.out.println(map.values());
		
		String value = map.get("지홍");
		System.out.println(value);
		
		Set<String> keys = map.keySet();
		for (String str : keys) {
			System.out.println(str+":"+map.get(str));
		}
	}
	public void updateTest() {
		map.put("지홍", "곧 26..");
		System.out.println(map.keySet()+""+map.values());
	}
	public void removeTest() {
		map.remove("지홍");
		System.out.println(map.keySet()+""+map.values());
		map.clear();
		System.out.println(map.keySet()+""+map.values());
	}
	
	public static void main(String[] args) {
		MapTest mp = new MapTest();
		mp.addTest();
		mp.getTest();
		mp.updateTest();
		mp.removeTest();
	}
}
