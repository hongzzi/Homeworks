package com.ssafy.collection;

import java.util.*;

public class ListTest {

//	List<String> list = new ArrayList<>();
	List<String> list = new LinkedList<>();
	public void addTest() {
		// list에 데이터를 넣고 출력해보세용
		list.add("Hello");
		list.add("Java");
		list.add("world");
		list.add(1,"뭐야");
		list.add("Java");
		System.out.println(list);
	}
	public void getTest() {
		System.out.println("크기 : "+list.size());
		System.out.println("포함? : " +list.contains("hello"));
		System.out.println(list.get(3));
		for (String string : list) {
			System.out.println(string);
		}
	}
	public void updateTest() {
		list.set(0, "replace");
		System.out.println("변경 후 : "+list);
	}
	public void removeTest() {
		list.remove("Hello");
		list.remove(1);
		System.out.println("삭제 후 : "+list);
		list.clear();
		System.out.println("삭제 후 : "+list);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListTest lt = new ListTest();
		lt.addTest();
		lt.getTest();
		lt.updateTest();
		lt.removeTest();
	}

}
