package com.ssafy.collection;

public class InnerTest {

	private int member;

	public void method() {
		Inner1 in = new Inner1();
		Inner2 in2 = new Inner2();

		// 3 . local inner class
		class Inner3 {
		}

		// 4. 어노니머스 클래스 (익명 클래스)
//		Comparable c = new Comparable<T>() {
//		};

		class MyComp implements Comparable<MyComp> {
			public int compareTo(MyComp o) {
				return 0;
			}
		}
		
		MyComp c = new MyComp();
		
		// 익명의 이너 클래스
		Comparable<String> c2 = new Comparable<String>() {
			
			@Override
			public int compareTo(String o) {
				// TODO Auto-generated method stub
				return 0;
			}
		};
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerTest it = new InnerTest();
		Inner1 in1 = it.new Inner1();
		Inner2 in22 = new Inner2();

	}

	// 1-2 . inner클래스 만드는 방법 4가지, 그 중 밑에 2가지
	class Inner1 {
		public void method() {
			member = 100; // inner에서 외부클라스의 private member에 접근 가능
		}
	}

	static class Inner2 {
	}
}
