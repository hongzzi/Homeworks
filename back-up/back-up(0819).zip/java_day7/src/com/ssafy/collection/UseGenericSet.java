package com.ssafy.collection;

import java.util.HashSet;
import java.util.Set;

public class UseGenericSet {
	
	Set<String> set = new HashSet<>();
	
	
	public static void main(String[] args) {
		UseGenericSet ugs = new UseGenericSet();
		ugs.set.add("TestTest");
		ugs.set.add("10101010");
		
		int len = 0;
		for (String string : ugs.set) {
			len += string.length();
		}
		System.out.println(len);
		
	}

	/*
	 * 		int lengthSum = 0;
		for (Object object : set) {
			System.out.println(object);
			if (object instanceof String) {
				String str = (String) object;
				lengthSum += str.length();
			}
		}
		System.out.println(lengthSum);
	 */
}
