package com.ssafy.collection;

import java.util.*;

public class SetTest {

	private Set set = new HashSet(); // 앞에있는 녀석이 인터페이스, 뒤에 있는 녀석이 구현체 어쩌고
	private Set set2 = new HashSet();

	// SET이 같은값으로 판별하는 기준 = > equals와 hashcode 값을 기준으로

	public void addTest2() {
		set2.add(new HandPhone("010", 100));
		set2.add(new HandPhone("010", 100));
		set2.add(new HandPhone("010", 100));
		set2.add(new HandPhone("010", 100));
		System.out.println(set2);
	}

	// Set은 중복, 순서 없음 !
	public void addTest() {
		set.add("Hello");
		set.add("Java");
		set.add("World");
		set.add("Java");
		System.out.println(set);
	}

	public void updateTest() {
		
		// set은 수정이 없다.
	}

	public void getTest() {
		// 크기
		System.out.println("크기 : " + set.size());
		System.out.println("포함여부 : " + set.contains("Hello"));
		// 모든 요소에 대한 순차 접근
		Iterator iter = set.iterator(); // iterater은 객체를 순서대로 만들어놓은거.. 래..
		while (iter.hasNext()) { // 다음 요소 있어? 가져와봐
			// 넣을 때는 마음대로, 뺄때는 only object
			Object obj = iter.next();
		}
		int lengthSum = 0;
		for (Object object : set) {
			System.out.println(object);
			if (object instanceof String) {
				String str = (String) object;
				lengthSum += str.length();
			}
		}
		System.out.println(lengthSum);

	}

	public void deleteTest() {
		set.remove("Java");
		System.out.println("삭제후" + set);
		set.clear();

		System.out.println("삭제후" + set);
	}

	public static void main(String[] args) {
		SetTest st = new SetTest();
		st.addTest();
		st.addTest2();
		st.getTest();
		
		st.deleteTest();
		st.getTest();

	}
}
