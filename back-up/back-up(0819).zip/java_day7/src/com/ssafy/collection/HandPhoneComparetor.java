package com.ssafy.collection;

import java.util.Comparator;

public class HandPhoneComparetor implements Comparator<HandPhone> {

	@Override
	public int compare(HandPhone o1, HandPhone o2) {
		return o1.number.compareTo(o2.number);

	}

}
