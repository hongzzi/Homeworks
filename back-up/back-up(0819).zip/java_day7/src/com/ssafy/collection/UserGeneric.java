package com.ssafy.collection;

public class UserGeneric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NormalPocket np = new NormalPocket();
		np.setObj("Hello");
		Object obj = np.getObj();
		if(obj instanceof String) {
			String str = (String)obj;
			System.out.println(str.length());
		}
		
		GenericPocket<String> gp1 = new GenericPocket<String>();
		gp1.setSome("Hello");
		String str = gp1.getSome();
		System.out.println(str.length());
		
		GenericPocket<Integer> gp2 = new GenericPocket<Integer>();
		gp2.setSome(1234);
		int a = gp2.getSome();
//		Integer data = gp2.getSome();
//		System.out.println(data.intValue());
		
		
	}

}
