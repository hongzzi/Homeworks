package com.ssafy.collection;

public class GenericPocket<T> {
	T some;
	
	public T getSome() {
		return some;
	}
	
	public void setSome(T some) {
		this.some = some;
	}
}
