package com.ssafy.inter;

public interface DefaultMethodInterface {

	void methodA();
	static void staticMethod() {
		System.out.println("static method");
	}
	default void defaultMethod() {
		System.out.println("default method");
	}
}
