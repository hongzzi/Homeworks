package com.ssafy.inter;

public class DefaultMethodTest implements DefaultMethodInterface {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		System.out.println("override method");
	}
	
	public static void main(String[] args) {
		DefaultMethodInterface.staticMethod();
		
		DefaultMethodInterface dmi = new DefaultMethodTest();
		dmi.defaultMethod();
		dmi.methodA();
		
	}

}
