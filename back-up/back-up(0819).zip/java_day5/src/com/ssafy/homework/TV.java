package com.ssafy.homework;

public class TV extends Product{
	
	int inch;
	String displayType;
	
	public TV() {}
	
	public TV(String isbn, String title, int price, int stock) {
		super(isbn, title, price, stock);
		this.inch = 0;
		this.displayType = "";
	}
	
	public TV(String isbn, String title, int price, int stock , int inch) {
		super(isbn, title, price, stock);
		this.inch = inch;
		this.displayType = "";
	}
	
	public TV(String isbn, String title, int price, int stock , int inch, String displayType) {
		super(isbn, title, price, stock);
		this.inch = inch;
		this.displayType = displayType;
	}
	
	

}
