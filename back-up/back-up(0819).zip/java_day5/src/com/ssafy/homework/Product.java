package com.ssafy.homework;

public class Product {
	
	String productNumber;
	String title;
	int price;
	int stock;
	
	public Product() {}
	
	public Product(String productNumber, String title, int price, int stock) {

		this.productNumber = productNumber;
		this.title = title;
		this.price = price;
		this.stock = stock;
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	
	@Override
	public String toString() {
		return "제품번호:" + productNumber + "| 제품명:" + title + ", price=" + price + ", stock=" + stock
				+ "]";
	}
	
	
	
	
}
