package com.ssafy.day5.modifier.other;

public final class FinalClass {
	
	final int member = 10;
	
	public final void method() {
//		member = 11;
	}
}
