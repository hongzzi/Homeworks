package com.ssafy.day5.modifier.other;
import com.ssafy.day5.modifier.Parent;

public class OtherPackageChildClass extends Parent {

	public void method() {
//		this.privateMember = 100;
//		this.defaultMember = 1000;
		this.protectedMember = 10000;
		this.publicMember = 100000;
	}
}
