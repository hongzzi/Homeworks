package com.ssafy.day5.modifier.other;

public class FinalSubClass /* extends FinalClass */ {
//
//	@Override
//	public void method() {
//		// TODO Auto-generated method stub
//		super.method();
//	}
}	// final 용도 알아보기
