package com.ssafy.day5.modifier.other;

import com.ssafy.day5.modifier.Parent;

public class OtherPackageSomeClass {
	
	public void method() {
		Parent p = new Parent();
//		p.privateMember = 100; 
//		p.defaultMember = 1000;
//		p.protectedMember = 10000;
		p.publicMember = 100000;
	}

}
