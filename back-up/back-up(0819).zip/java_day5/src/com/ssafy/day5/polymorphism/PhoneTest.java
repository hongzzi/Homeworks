//package com.ssafy.day5.polymorphism;
//
//public class PhoneTest {
//	public static void main(String[] args) {
//		HandPhone hp = new HandPhone();
//		// 다형성
//		Phone p = hp;
//		Object obj = hp;
//		
//		// 다형성 배열
//		HandPhone [] hps = new HandPhone[2];
//		hps[0] = hp;
////		hps[1] = new Phone(); 
//		
//		Phone [] phones = new Phone[2];
//		phones[0] = new Phone();
//		phones[1] = new HandPhone();
//		
//		// 다형성 덕분에 자유로워진
//		Object [] objs = new Object[5];
//		objs[0] = new Object();
//		objs[1] = new Phone();
//		objs[2] = hp;
//		objs[3] = 3;		// auto boxing --> primitive --> reference
//		
//		System.out.println(hp);	
//	}
//}
