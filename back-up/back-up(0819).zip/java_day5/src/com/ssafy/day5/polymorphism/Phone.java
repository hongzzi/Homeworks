package com.ssafy.day5.polymorphism;

public class Phone extends Object {
	
	int price = 1000;
	String number;
	
	
	public Phone(String number) {
		this.number = number;
	}
	
	public void call (String number) {
		System.out.println(this.number+"에서 "+number+"에 전화");
	}
	
	
	
	// 대표적인 오버라이드 메소드 
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "전화번호 : "+number ;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj!=null && obj instanceof Phone) {
			Phone other = (Phone)obj;
			return this.number.equals(other.number);
		} else {
			return false;
		}
	}
}
