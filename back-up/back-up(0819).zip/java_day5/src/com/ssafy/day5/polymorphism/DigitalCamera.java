package com.ssafy.day5.polymorphism;

public class DigitalCamera implements Chargeable {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("디카 충전 중 . . . .");
	}

}
