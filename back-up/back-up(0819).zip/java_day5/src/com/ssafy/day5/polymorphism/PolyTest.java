package com.ssafy.day5.polymorphism;

import com.ssafy.day5.inheritance.Person;

public class PolyTest {
	public static void main(String[] args) {
			String str = "Hello";
			Person p = new Person("박지홍");
			int num = 100;
			// 위 3개의 자료를 저장하기 위한 배열을 만들고 자료를 저장하시오.
			Object [] objs = new Object[3];
			
			objs[0] = str;
			objs[1] = p;
			objs[2] = num;
			
			for(Object obj : objs) {
				if (obj instanceof Person) {
					Person temp = (Person)obj;
					System.out.println(temp.name);
				}
				System.out.println(obj+" :" + obj.getClass().getName());
				// ob
			}
	}
}
