package com.ssafy.day5.polymorphism;

public class EqualsTest {
	public static void main(String[] args) {
		Phone p1 = new Phone("010");
		Phone p2 = new Phone("012");
		
		System.out.println(p1 == p2);
		System.out.println(p1.equals(p2));
	}
}
