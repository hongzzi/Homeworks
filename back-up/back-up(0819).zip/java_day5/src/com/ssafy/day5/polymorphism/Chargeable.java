package com.ssafy.day5.polymorphism;

public interface Chargeable {
	// 규칙 1.  모든 변수는 public static final
	public static final int a = 10;	// 항상 그렇기에 생략 가능.
	int b = 20;
	// 규칙 2.  모든 메서드는 public abstract
	public abstract void methodA();	// 항상 그렇기에 생략 가능
	void charge();
}
