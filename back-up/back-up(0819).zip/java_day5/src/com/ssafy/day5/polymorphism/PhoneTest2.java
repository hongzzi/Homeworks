//package com.ssafy.day5.polymorphism;
//
//public class PhoneTest2 {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		HandPhone hp = new HandPhone("010-2053-7168","SKT");
//		System.out.println(hp.comm);
//		System.out.println(hp.number);
//		Phone phone = hp;	// polymorphism은 자동 형변환임
////		System.out.println(phone.comm);	// 범위는 넓어지는 대신 사용할 수 있는 기능이 줄어듬.
//		System.out.println(phone.number);
//		
//		Object obj = hp;
////		System.out.println(obj.number);
//		
//		HandPhone hp2= (HandPhone)obj;
//		System.out.println(hp2.comm);
//		
//		
//		Phone phone2 = new Phone();
//		
//		if(phone2 instanceof HandPhone) {	// 런타임에 객체의 실 타입 확인
//			HandPhone hp3 = (HandPhone)phone2;
//		} else {
//			System.out.println("핸드폰 아니에요 !");
//		}
//		HandPhone hp3 = (HandPhone)phone2;
//		
//	}
//	
//	// 전화할 때 가장 적합한 메서드의 선언은 무엇?
//	public void call(HandPhone hp) {
//		hp.call("123");
//	}
//	public void call(Phone phone) {
//		phone.call("123");
//	}
//	public void call(Object obj) {
//		if(obj instanceof Phone) {
//			Phone p = (Phone)obj;
//			p.call("123");
//		}
//	}
//
//}
