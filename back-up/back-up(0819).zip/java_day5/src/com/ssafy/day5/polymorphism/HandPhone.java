package com.ssafy.day5.polymorphism;

public class HandPhone extends Phone implements Chargeable{
	// abstract 클래스가 되면 객체 생성 불가능 ㅠㅠ
	int price = 10;
	String comm;
	String lastNumber;
	
	public HandPhone(String number, String comm) {
		super(number);
		this.comm = comm;
		
	}
	
	@Override
	public void call(String number) {
		// TODO Auto-generated method stub
		this.lastNumber = number;
		super.call(number);
	}
	
	public void call() {
		call(lastNumber);
	}
	
	public void sendSMS(String to, String msg) {
		System.out.println(number+"에서 "+to+"에게 "+msg+"를 전송함.");
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+ ", 통신사 : "+comm;
	}

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("핸드폰 충전 중 . . . .");
	}

}
