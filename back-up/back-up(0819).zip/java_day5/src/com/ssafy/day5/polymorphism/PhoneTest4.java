package com.ssafy.day5.polymorphism;

public class PhoneTest4 {

	public static void main(String[] args) {
		HandPhone hp = new HandPhone("010", "skt");
		DigitalCamera dc = new DigitalCamera();

		Object[] objs = { hp, dc };

		for (Object obj : objs) {
			if(obj instanceof Chargeable) {
				Chargeable c = (Chargeable)obj;
				c.charge();
			}
		}
		
		Chargeable [] cs = {hp, dc};
		for(Chargeable c : cs) {
			c.charge();
		}
	}

}
