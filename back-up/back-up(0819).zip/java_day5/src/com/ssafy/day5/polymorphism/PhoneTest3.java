package com.ssafy.day5.polymorphism;

public class PhoneTest3 {

	public static void main(String[] args) {
		
		HandPhone hp = new HandPhone("010-2053-7168","SKT");
		System.out.println(hp);					// 왜 객체를 찍었는데 저 내용이 출력될까? , 저걸 가져다 어따 쓸까? , ctrl 과 메소드 눌러서 확인
		
		Phone phone = hp;
		System.out.println(phone.price);		// 변수는 참조하는 객체의 값을 그대로 사용
		System.out.println(phone);				// 가장 마지막으로 오버라이드 한게 최적화 시킨것일텐데, 그렇기에 오버라이드를 할때 자식메소드에서 오버라이드 되어있다면, 자동으로 자식의 메소드 부름 => 이걸 뭐라고 부른다고? ..
		
		
	}
}
