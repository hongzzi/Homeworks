package com.ssafy.day5.abs;

public abstract class Shape {
		
	public abstract double calcArea();
}
