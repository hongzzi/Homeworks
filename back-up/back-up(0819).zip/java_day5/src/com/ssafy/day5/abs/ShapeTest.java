package com.ssafy.day5.abs;

public class ShapeTest{

	public static void main(String[] args) {
		
//		abstract class는 객체 생성 불가
//		Shape shape = new Shape();
		
//		abstract class는 상속 전용의 클래스 
//		따라서 모든 메서드를 재정의 하거나 자신이 l\
		
		Shape [] shapes = {new Rectangle(10, 10), new Rectangle(1, 2), new Circle(10)};
		// abstract클래스는 타입이 될 수는 있다. 
		
		double total = 0;
		int round = 0;
		// 1. 모든 도형의 면접의 합은?
		for (Shape shape : shapes) {
			total += shape.calcArea();
		}
		System.out.println(total);
		
		// 2. 모든 사각형의 둘레는?
		for (Shape shape : shapes) {
			if(shape instanceof Rectangle) {
				Rectangle r = (Rectangle)shape;
				round += r.getRound();
			}
		}
		
		System.out.println(round);
		
	}
}
