package com.ssafy.day5.abs;

public class HorseCart extends Vehicle{

	
	// abstract method design pattern!!! (절대 빠뜨리지 말아야할 기능을 abstract로 선언해줌)
	@Override
	public void addFuel() {
		// TODO Auto-generated method stub
		System.out.println("건초 공급");
	}
	// abstract 클래스를 상속하면, 오버라이드 하라고 에러뜸 
	
	

}
