package com.ssafy.day5.abs;

public class ElecCar extends Vehicle{


	public void addFuel() {
		System.out.println("전기 충전");
	}
}
