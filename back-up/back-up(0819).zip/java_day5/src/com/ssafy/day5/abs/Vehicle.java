package com.ssafy.day5.abs;

public abstract class Vehicle {
	
	public void printPosition() {
		System.out.println("현재 위치 출력");
	}
	public abstract void addFuel(); // ㄷㅂ 선언부만 있고 바디는 없는 모양.
									// 상속에서 메소드를 이용하기 위해서 하는거임!
									// 자식클래스들이 가졌으면 좋겠는 메서드. 자식들은 그 메서드를 오버라이드해서 쓸것이기 때문에 ㅎㅎ => 클래스 또한 abstract 박아줌
	
	
}
