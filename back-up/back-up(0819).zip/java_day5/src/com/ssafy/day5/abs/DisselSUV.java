package com.ssafy.day5.abs;

public class DisselSUV extends Vehicle{


	public void addFuel() {
		System.out.println("디젤 주유");
	}
	
}
