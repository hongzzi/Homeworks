package com.ssafy.day5.abs;

public class VehicleTest {
	public static void main(String[] args) {
		Vehicle [] vehicles = {new ElecCar(), new DisselSUV()};
		
		for(Vehicle vehicle : vehicles) {
			vehicle.printPosition();
			vehicle.addFuel();	// 상속의 메소드를 없애면, 클래스로 캐스팅해서 메소드를 실행시켜야함 ㄷㄷ
		}
	}
}
