package com.ssafy.day5.object;

public class StringTest {

	public static void main(String[] args) {
		String s1 = new String("Hello");
		String s2 = new String("Hello");
		System.out.println(s1==s2+" : "+(s1.equals(s2)));
		
		String s3 = "hi";
		String s4 = "hi";
		System.out.println(s3==s4+" : "+(s3.equals(s4)));
		
		String a = "A";
		a = a+"B"+"C";	// 하면 안될일 ~~~ ^_^ 
		
		StringBuilder sb = new StringBuilder("A");
		sb.append("B").append("C");
		System.out.println(sb);
		
	}
}
