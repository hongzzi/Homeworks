package com.ssafy.day5.object;

public class WrapperTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 기본형과 객체형, 문자열의 형 변환
		String numStr = "100";
		// 문자열 => 숫자 
		int num = Integer.parseInt(numStr);
		// 숫자 => 문자열
		String reStr = String.valueOf(num);
		String reStrr = num+"";
		// 숫자 => 객체 
		Integer integer = Integer.valueOf(num);
		Integer integer2 = num;	 // auto-Boxing // 자동으로 객체 변환
		
		int reNum = integer.intValue(); 	// ㅇ0ㅇ
		int reNum2 = integer2;				// un-Boxing

	}

}
