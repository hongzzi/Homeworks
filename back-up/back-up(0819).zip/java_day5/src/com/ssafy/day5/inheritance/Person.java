package com.ssafy.day5.inheritance;

public class Person {
	
	public String name;
	private String hiddenMoney;
	int age = 1000;
	
//	public Person() {}
	public Person(String name) {
		this.name = name;
	}
	
	public void jump() {
		System.out.println("두 다리로 폴짝 ! ");
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", hiddenMoney=" + hiddenMoney + ", age=" + age + "]";
	}

}
