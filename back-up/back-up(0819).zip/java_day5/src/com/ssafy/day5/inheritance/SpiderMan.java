package com.ssafy.day5.inheritance;

public class SpiderMan extends Person {	// is a 관계

	boolean isSpider;
	Spider spider = new Spider();						// 객체안에 객체가 있을때 has a 관계라고 지칭함.
	int age = 100;
	
	public void printAge() {
//		int age = 10;
		System.out.println(age);		// 지역, 멤버 없으면 조상꺼받아옴
		System.out.println(this.age);
		System.out.println(super.age);
	}
	
	public SpiderMan(String name, boolean isSpider) {
		super(name);	// 조상의 생성자 호출, 생성자 첫줄에서만.
		this.isSpider = isSpider;
	}
	
	
	// method override : 조상이 물려준 메서드를 창조적으로 계승 발전
	@Override	// 시스템 주석 ( 만약 내가 원하는 부분과 다르게 개발한다면 오류표시 좀 )
	public void jump() {
		if(isSpider) {
			spider.jump();
		} else {
			super.jump();
		}
	}
	
	@Override
	public String toString() {
		return super.toString() + " : " + isSpider;
	}

	
	void fireWeb() {
		spider.fireWeb();
	}
}
