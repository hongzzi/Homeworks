package com.ssafy.day5.inheritance;

public class Spider {
	
	public void fireWeb() {
		System.out.println("쉭쉭~~~~~");
	}
	
	public void jump() {
		System.out.println("엄청난 점프 가능!!");
	}
	
}
