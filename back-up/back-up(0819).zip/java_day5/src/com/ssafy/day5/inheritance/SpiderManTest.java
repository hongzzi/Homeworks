package com.ssafy.day5.inheritance;

public class SpiderManTest {
	public static void main(String[] args) {
		SpiderMan sman = new SpiderMan("피터파커",false);
		sman.name = "피터파커";
		
		
		// 조상멤버 접근. 단 private제외 
//		sman.hiddenMoney = 100;
//		sman.someProp = 100;
		
		sman.jump();
		
		System.out.println(sman.toString());
		
	}
}
