//package com.ssafy.dayy5.ws2;
//
//import java.util.Arrays;
//import java.util.Scanner;
//import java.util.StringTokenizer;
//
//public class MovieTest {
//	
//	static Scanner sc;
//	static MovieMgr mm = MovieMgr.getMm();
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		sc = new Scanner(System.in);
//
//		menu();
//		
//		sc.close();
//
//		//테스트 데이터 입력
////		for (int i = 1; i <= 30; i++) {
////			mm.add(new Movie("토이스토리"+i, "조쉬 쿨리", i, "애니", "하하"));
////		}
//
//	}
//
//	public static void menu() {
//		outter: while (true) {
//			System.out.println("<<< 영화 관리 프로그램 >>>");
//			System.out.println("1.영화 정보 입력");
//			System.out.println("2.영화 정보 전체 검색");
//			System.out.println("3.영화명 검색");
//			System.out.println("4.영하 장르별 검색");
//			System.out.println("5.영화 정보 삭제");
//			System.out.println("0.종료");
//
//			int input = Integer.parseInt(sc.nextLine());
//
//			switch (input) {
//			case 0:
//				System.out.println("프로그램 종료!!");
//				break outter;
//			case 1:
//				OneSelect();
//				break;
//			case 2:
//				TwoSelect();
//				break;
//			case 3:
//				ThreeSelect();
//				break;
//			case 4:
//				FourSelect();
//				break;
//			case 5:
//				FiveSelect();
//				break;
//
//			}
//		}
//	}
//	
//	public static void OneSelect() {
//		System.out.println("-----------영화 정보-------------");
//		System.out.println("제목, 감독, 평점, 장르, 개요 순으로 입력하세요.");
//		StringTokenizer st = new StringTokenizer(sc.nextLine());
////		System.out.println(st.nextToken()+st.nextToken()+Integer.parseInt(st.nextToken())+ st.nextToken()+ st.nextToken());
//		Movie m = new Movie(st.nextToken(),st.nextToken(),Integer.parseInt(st.nextToken()), st.nextToken(), st.nextToken());		
//		if(mm.add(m)) {
//			System.out.println("추가 완료");
//		}else {
//			System.out.println("실패!!");
//		}
//		
//		System.out.println("-----------------------------------------");
//	}
//	
//	public static void TwoSelect() {
//		System.out.println("-----------영화 정보 전체 검색-------------");
//		
//		if(mm.search().length!=0){
//			for (Movie m : mm.search()) {
//				System.out.println(m.toString());
//			}
//		}else {
//			System.out.println("검색 결과가 없습니다.");
//		}
//		System.out.println("-----------------------------------------");
//		
//	}
//	
//	public static void ThreeSelect() {
//		System.out.println("-----------영화명 검색-------------");
//		System.out.println("영화명을 입력하세요");
//		String input = sc.nextLine();
//		
//		if(mm.search(input).length!=0) {
//			for (Movie m : mm.search(input)) {
//				System.out.println(m.toString());
//			}
//		}else {
//			System.out.println("검색 결과가 없습니다.");
//		}
//		
//		System.out.println("-----------------------------------------");
//	}
//	
//	public static void FourSelect() {
//		System.out.println("-----------영화명 장르별 검색-------------");
//		System.out.println("영화장르를 입력하세요");
//		
//		String input = sc.nextLine();
//		Movie[] mArr = mm.searchGenre(input);
//		
//		if(mArr.length!=0) {
//			for (Movie m : mArr) {
//				System.out.println(m.toString());
//			}
//		}else {
//			System.out.println("검색 결과가 없습니다.");
//		}
//		
//		System.out.println("-----------------------------------------");
//	}
//	
//	public static void FiveSelect() {
//		System.out.println("-----------영화 삭제-------------");
//		System.out.println("영화제목을 입력하세요");
//		
//		if(mm.delete(sc.nextLine())) {
//			System.out.println("삭제 성공");
//		}else {
//			System.out.println("삭제 실패");
//		}
//		System.out.println("-----------------------------------------");
//	}
//}
