package com.ssafy.day10.network;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NewServer {

	public static void main(String[] args) throws IOException {
		try (ServerSocket ss = new ServerSocket(6547)) {
			System.out.println("[Server is ready]");
			File file = new File("c:/Temp/myexp.exe");
			while (true) {
				// 클라이언트 접속 대기
				try (Socket socket = ss.accept();
						BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
						BufferedInputStream bin = new BufferedInputStream(socket.getInputStream());
						BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
					) {
					byte [] buffer = new byte[100];
					int readed = -1;
					while( (readed = bin.read(buffer)) > 0) {
						bos.write(buffer, 0, readed);
					}
					bos.flush();
					// 전송완료 표시
					bw.write("파일 전송완료!/n");
					bw.flush();

				} catch (IOException e) {
					System.out.println("통신 오류");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
