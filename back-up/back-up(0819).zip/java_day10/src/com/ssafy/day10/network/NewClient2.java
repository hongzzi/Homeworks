package com.ssafy.day10.network;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


public class NewClient2 {

	public static void main(String[] args) throws UnknownHostException, IOException {
		String serverIp = "Localhost";
		File file = new File("C:/windows/explorer.exe");

		try (Socket socket = new Socket(serverIp, 1234);
				ObjectOutputStream oout = new ObjectOutputStream(socket.getOutputStream());
				) {
			Person p = new Person("hong", 10);
			System.out.println("접속완료");
			oout.writeObject(p);
			System.out.println("전송완료!!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
