package com.ssafy.day10.network;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NewServer2 {

	public static void main(String[] args) throws IOException {
		try (ServerSocket ss = new ServerSocket(1234)) {
			System.out.println("[Server is ready]");
			File file = new File("c:/Temp/myexp.exe");
			while (true) {
				// 클라이언트 접속 대기
				try (Socket socket = ss.accept();
					ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
						) {
					Person p = (Person)ois.readObject();
					System.out.println(p);

				} catch (IOException e) {
					System.out.println("통신 오류");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
