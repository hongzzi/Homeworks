package com.ssafy.day10.network;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerConnect {

	public static void main(String[] args) throws IOException {
		try (ServerSocket ss = new ServerSocket(6547)) {
			System.out.println("[Server is ready]");

			while (true) {
				// 클라이언트 접속 대기
				try (Socket socket = ss.accept();
						BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
						BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
						) {
					System.out.printf("client 접속 : %s\n", socket.getInetAddress());
					// 클라이언트로부터 데이터를 받아들일 스트림 구성

					//
					bw.write(socket.getInetAddress().getHostName() + "님 성함은?");
					bw.newLine();
					bw.flush();
					String line = br.readLine();
					System.out.println(line);
					bw.write(line + "님 반갑습니다.");
					bw.newLine();
					bw.flush();
				} catch (IOException e) {
					System.out.println("통신 오류");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
