package com.ssafy.day10.work;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;

public class BookServer {

	public static void main(String[] args) throws IOException {
		try (ServerSocket ss = new ServerSocket(9999)) {
			System.out.println("Server is ready...");
			while (true) {

				try (Socket socket = ss.accept();
						ObjectInputStream oin = new ObjectInputStream(socket.getInputStream());
						BufferedWriter br = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));) {
					Object obj = oin.readObject();
					if (obj != null) {
						System.out.println("객체 수신 : " + obj);
						if (obj instanceof List) {
							List<Book> list = (List) obj;
							br.write(list.size() + "");
						} else if (obj instanceof Map) {
							Map<String, Book> list = (Map) obj;
							br.write(list.size() + "");
						}
					}
				} catch (IOException | ClassNotFoundException e) {
					e.printStackTrace();
				}

			}
		}
	}
}
