package com.ssafy.day10.work;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
//
//public class IBookImpl2 implements IBookMgr{
//	private Map<String, Book> books = new HashMap();
//	
//	private static IBookImpl2 ibm = new IBookImpl2();
//	
//	public static IBookImpl2 getBookManager() {
//		return ibm;
//	}
//	
//	private IBookImpl2() {
//		
//	}
//	
//	
//	@Override
//	public boolean addBook(Book book) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public void searchBook() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public Book searchWithIsbn(String input) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> searchWithTitle(String input) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> getBookOnly() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> getMegazine() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> getMegazinePublishedYear() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public int getSumPrice() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public Collection<Book> getMegazinePublishedThisYear() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> getBookWithPublisher(String pub) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Collection<Book> getBookWithPrice(int price) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public int getAveragePrice() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public void sell(String isbn, int quantity) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
