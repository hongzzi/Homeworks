package com.ssafy.day10.work;

public class QuantityException extends RuntimeException{
	public QuantityException(int quantity) {
		super(quantity+": 책 권수가 부족합니다.");
	}
}
