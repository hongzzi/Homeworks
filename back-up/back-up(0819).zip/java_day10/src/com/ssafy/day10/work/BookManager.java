package com.ssafy.day10.work;
public class BookManager {
	Book[] books = new Book[10];
	
	private static BookManager bm = new BookManager();
	
	public static BookManager getBookManager() {
		return bm;
	}
	
	private BookManager() {
		
	}
	
	public boolean addBook(Book book) {
		for (int i = 0; i < books.length; i++) {
			if(books[i] == null) {
				books[i] = book;
				return true;
			}
		}
		return false;
	}
	
	public void searchBook() {
		for (Book b : books) {
			if(b != null)
				System.out.println(b.toString());
		}
	}
	
	public Book searchWithIsbn(String input) {
		for (Book b : books) {
			if(b.getIsbn().equals(input)) {
				return b;
			}
		}
		return null;
	}
	
	public Book[] searchWithTitle(String input) {
		Book[] tmp = new Book[10];
		int idx = 0;
		for (int i = 0; i < books.length; i++) {
			if(books[i].getTitle().contains(input)) {
				tmp[idx++] = books[i];
			}
		}
		return null;
	}
}
