package com.ssafy.day10.work;

import java.util.Collection;

public interface IBookMgr {
	
	public boolean addBook(Book book);
	public void searchBook();
	public Book searchWithIsbn(String input);
	public Collection<Book> searchWithTitle(String input);
	public Collection<Book> getBookOnly();
	public Collection<Book> getMegazine();
	public Collection<Book> getMegazinePublishedThisYear();
	public Collection<Book> getBookWithPublisher(String pub);
	public Collection<Book> getBookWithPrice(int price);
	public int getSumPrice();
	public int getAveragePrice();
	
	public void sell(String isbn, int quantity);
	public void buy(String isbn, int quantity);
	
	public void save();
	public void load();
	
	public void send();
	
}
