package com.ssafy.day10.work;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;


public class BookClient extends Thread{

	Object books;
	int size;
	public BookClient(Object books, int size) {
		this.books = books;
		this.size = size;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try(Socket socket = new Socket("localhost", 9999);
				ObjectOutputStream oout = new ObjectOutputStream(socket.getOutputStream());
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
			
			oout.writeObject(books);
			String readed = br.readLine();
			if (size == Integer.parseInt(readed)) {
				System.out.println("전송 확인");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}

