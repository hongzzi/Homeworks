package com.ssafy.day10.work;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IBookMgrImpl implements IBookMgr{
	private List<Book> books = new ArrayList<>();
	private Map<String, Book> mbooks = new HashMap<>();
	
	private static IBookMgrImpl ibm = new IBookMgrImpl();
	
	public static IBookMgrImpl getBookManager() {
		return ibm;
	}
	
	private IBookMgrImpl() {
		
	}
	
	

	@Override
	public boolean addBook(Book book) {
		for (Book b : books) {
			if(b.isbn.equals(book)) {
				return false;
			}
		}
			books.add(book);
			return true;
	}

	@Override
	public void searchBook() {
		Collections.sort(books, (b1, b2) -> {
			if(b1.price == b2.price) {
				return -b1.isbn.compareTo(b2.isbn);
			} else {				
				return Integer.valueOf(b1.price).compareTo(b2.price);
			}
		});
		
		for (Book b : books) {
			if(b != null)
				System.out.println(b.toString());
		}
	}

	@Override
	public Book searchWithIsbn(String input) {
		for (Book b : books) {
			if(b.getIsbn().equals(input)) {
				return b;
			}
		}
		return null;
	}

	@Override
	public Collection<Book> searchWithTitle(String input) {
		List<Book> tmp = new ArrayList<>();
		for (Book b : books) {
			if(b.getTitle().contains(input)) {
				tmp.add(b);
			}
		}
		return tmp;
	}

	@Override
	public Collection<Book> getBookOnly() {
		List<Book> tmp = new ArrayList<>();
		for (Book b : tmp) {
			if(!(b instanceof Magazine)) {
				tmp.add(b);
			}
		}
		return tmp;
	}

	@Override
	public Collection<Book> getMegazine() {
		List<Book> tmp = new ArrayList<>();
		for (Book b : tmp) {
			if(b instanceof Magazine) {
				tmp.add(b);
			}
		}
		return tmp;
	}

	@Override
	public Collection<Book> getMegazinePublishedThisYear() {
		List<Book> tmp = new ArrayList<>();
		for (Book b : tmp) {
			if(b instanceof Magazine) {
				if(((Magazine)b).getYear() == 2019) {					
					tmp.add(b);
				}
			}
		}
		return tmp;
	}

	@Override
	public Collection<Book> getBookWithPublisher(String pub) {
		List<Book> tmp = new ArrayList<>();
		for (Book b : tmp) {
			if(b.getPublisher().equals(pub)) {
				tmp.add(b);
			}
		}
		return tmp;
	}

	@Override
	public Collection<Book> getBookWithPrice(int price) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public int getSumPrice() {
		int sum = 0;
		for (Book book : books) {
			sum += book.getPrice();
		}
		return sum;
	}
	
	@Override
	public int getAveragePrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void sell(String isbn, int quantity) throws QuantityException {
		// TODO Auto-generated method stub
		boolean find = false;
		for (Book book : books) {
			if(book.getIsbn().equals(isbn)){
				find = true;
				if(book.getQuantity() >= quantity){
					book.setQuantity(book.getQuantity()-quantity);
				} else{					
					throw new QuantityException(quantity);
				}
			}
		}
		if(!find){
			throw new ISBNNotFoundException(isbn);
		}
	}

	@Override
	public void buy(String isbn, int quantity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save() {
		// TODO Auto-generated method stub
		File file = new File("C:/Temp/data.dat");
		try(ObjectOutputStream oout = new ObjectOutputStream(new FileOutputStream(file));) {
			oout.writeObject(books);
			System.out.println("save completed");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void load() {
		// TODO Auto-generated method stub
		File file = new File("C:/Temp/data.dat");
		
		try(ObjectInputStream oin = new ObjectInputStream(new FileInputStream(file));) {
			try {
				books = (List<Book>) oin.readObject();
				System.out.println("load completed!");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	@Override
	public void send() {
		BookClient bc = new BookClient(books, books.size());
		bc.run();
	}

	
}
