package com.ssafy.day10.work;

public class ISBNNotFoundException extends RuntimeException{
	public ISBNNotFoundException(String isbn) {
		super(isbn+": 해당 책을 찾을 수 없습니다.");
	}
}