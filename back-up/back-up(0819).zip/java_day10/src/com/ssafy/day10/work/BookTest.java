package com.ssafy.day10.work;

public class BookTest {
	public static void main(String[] args) {
		Book book0 = new Book("21323", "Java Pro", "홍길동", "펭귄클래식", 14000, "자바기본문법", 10);
		Book book1 = new Book("2153", "C++ Pro", "김첨치", "펭귄클래식", 18000, "자바기본문법", 5);
		Book book2 = new Book("45323", "Python Pro", "임꺽정", "펭귄클래식", 22000, "자바기본문법", 3);
		Book book3 = new Book("23723", "Ruby Pro", "이순신", "펭귄클래식", 15000, "자바기본문법", 15);
		Book book4 = new Book("23534", "C# Pro", "박효신", "펭귄클래식", 15000, "자바기본문법", 2);
		Book book5 = new Book("6526", "JavaScript Pro", "아치산", "펭귄클래식", 1000, "자바기본문법", 0);
		Book book6 = new Book("81651", "Object-C Pro", "행복동", "펭귄클래식", 19000, "자바기본문법", 1);
	
		Book[] books = {book0, book1, book2, book3, book4, book5, book6};
		// singleton design pattern
		BookManager bm = BookManager.getBookManager();
		IBookMgrImpl ibm = IBookMgrImpl.getBookManager();
		
		for (Book b : books) {
//			System.out.println(bm.addBook(b));
			ibm.addBook(b);
		}
//		bm.searchBook();
		ibm.searchBook();
		
//		System.out.println(bm.searchWithIsbn("6526"));
		System.out.println(ibm.searchWithIsbn("6526"));
		
		try {
			ibm.sell("8151", 3);
		} catch (ISBNNotFoundException e) {
			// TODO: handle exception
//			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (QuantityException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			// TODO: handle exception
		}
		
//		ibm.searchBook();
//		ibm.sell("23723", 1);
//		ibm.save();
//		ibm.searchBook();
		ibm.load();
		ibm.searchBook();
		
		ibm.send();
		
		
		
		
	}
}
