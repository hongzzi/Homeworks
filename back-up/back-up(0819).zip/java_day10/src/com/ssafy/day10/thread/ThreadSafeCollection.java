package com.ssafy.day10.thread;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

public class ThreadSafeCollection {
	
	public static void test(List<Integer> list) throws InterruptedException {
		
		long start = System.currentTimeMillis();
		
		// 1부터 100까지 list에 저장하는 runnable객체
		Runnable r = () -> {
			for (int i = 0; i < 100; i++) {
				list.add(i);
			}
		};
		
		//  runnable --> thread
		Thread t = new Thread(r);
		Thread t2 = new Thread(r);
		
		t.start();
		t2.start();
		
		t.join();
		t2.join();
		
		long end = System.currentTimeMillis();
		System.out.println(list.getClass() + " : " + (end - start) + ", "+ list.size());
		
	}

	public static void main(String[] args) throws InterruptedException {
		test(new Vector<>());
		test(new ArrayList<>());
		test(Collections.synchronizedList(new ArrayList<>()));
	}
}
