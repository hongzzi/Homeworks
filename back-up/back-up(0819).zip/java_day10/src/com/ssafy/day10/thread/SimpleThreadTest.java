package com.ssafy.day10.thread;

public class SimpleThreadTest {

	// 1. Runnable Interface이용 --> 아직은 Thread 아님
	static class MyRunnable implements Runnable {
		@Override
		public void run() {
			System.out.println(Thread.currentThread().getName());
			for (int i = 0; i < 20; i++) {
				System.out.print("*");
			}

		}
	}

	// 2. Thread 클래스 이용
	static class MyThread extends Thread {
		@Override
		public void run() {
			System.out.println(Thread.currentThread().getName());
			for (int i = 0; i < 20; i++) {
				System.out.print("#");
			}
		}
	}

	public static void main(String[] args) {
		MyThread mt = new MyThread();
		Thread mt2 = new Thread(new MyRunnable());
		
		//anonymous inner class 이용
		Thread mt3 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName());
				for (int i = 0; i < 20; i++) {
					System.out.print("$");
				}
				
			}
		});
		
		Thread mt4 = new Thread(() -> {
			System.out.println(Thread.currentThread().getName());
			for (int i = 0; i < 20; i++) {
				System.out.print("&");
			}
		});
		mt.start();
		mt2.start();
		mt3.start();
		mt4.start();
		//run 일때랑 start일때랑 다름 !!!!!
		System.out.println(Thread.currentThread().getName() + "main is over . . . . . . ");
	}

}
