package com.ssafy.day10.thread;

public class LifeCycleTest {

	Thread t1 = new Thread(() -> {
		for (int i = 0; i < 100; i++) {
			System.out.print(1);
		}
	});
	Thread t2 = new Thread(() -> {
		for (int i = 0; i < 100; i++) {
			System.out.print(2);
		}
	});
	Thread t3 = new Thread(() -> {
		for (int i = 0; i < 100; i++) {
			System.out.print(3);
		}
	});

	// sleep test
	public void sleepTest() throws InterruptedException {
		t1.start();
		t2.start();
		t3.start();
		Thread.sleep(1000); // 이 메서드를 호출한 thread는 주어진 시간동안 대기
	}

	// join test
	public void joinTest() throws InterruptedException {
		t1.start();
		t2.start();
		t3.start();
		t1.join(); // t1의 작업이 종료될 때까지 이 메서드를 호출한 thread 대기
	}

	// interrupt Test
	public void interruptTest() throws InterruptedException {
		Thread sleepy = new Thread(() -> {
			try { // 왜 트라이 캐치문만 사용가능할까!?!
					// override 상황 => 조상메서드가 예외를 던지지 않고있기 때문에 자식인 나도 예외를 던질 수 없다.
				Thread.sleep(1000 * 10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("sleepy 종료");
		});

		sleepy.start();

		Thread.sleep(1000 * 5);
		sleepy.interrupt();
	}

	boolean flag = true;
	public void stopBad() throws InterruptedException {
		Thread t = new Thread(() -> {
			System.out.println("중요 자원 획득...");
			while (flag) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.print("자원사용");
			}
			System.out.println("자원반납");
		});
		t.start();
		
		Thread.sleep(1000);
		t.stop();	// 스레드는 강제종료금지! 
		flag = false;
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		LifeCycleTest lct = new LifeCycleTest();
//		lct.sleepTest();
//		lct.joinTest();
//		lct.interruptTest();
		lct.stopBad();
		System.out.println("main is over....");
	}

}
