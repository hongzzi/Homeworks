package com.ssafy.day10.thread;


// 60초 동안 현재 시각을 1초 간격으로 출력하는 스레드를 만들어보자.~
public class ThreadClock {
	void clock() {
		Thread t = new Thread(() -> {
			int i = 0;
			while (true) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println((i++) +"초");
			}
			});
		t.start();
	}
	public static void main(String[] args) {
		ThreadClock tc = new ThreadClock();
		
		tc.clock();
	}

}
