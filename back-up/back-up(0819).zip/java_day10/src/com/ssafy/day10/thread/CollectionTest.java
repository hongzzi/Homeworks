package com.ssafy.day10.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class CollectionTest {

	public static void main(String[] args) {
		testList(new ArrayList<Integer>());
		testList(new Vector<>());
	}
	public static void testList(List<Integer> list) {
		long start = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++) {
			list.add(i);
		}
		long end = System.currentTimeMillis();
		System.out.println(list.getClass().getName() + " : "+(end-start));
	}

}
