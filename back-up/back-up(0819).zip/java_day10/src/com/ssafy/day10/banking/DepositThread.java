package com.ssafy.day10.banking;

public class DepositThread extends Thread {
	Account account;

	public DepositThread(String name, Account account) {
		super(name);
		this.account = account;
	}

	@Override
	public void run() {	// 6초에 한 번씩 예금
		while (true) {
			try {
				Thread.sleep(1000 * 10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			account.deposit(5000);
		}
	}
}
