package com.ssafy.day10.banking;

public class WithdrawThread extends Thread {
	Account account;

	public WithdrawThread(String name, Account account) {
		super(name);
		this.account = account;
	}

	@Override
	public void run() {
		while (true) {
			int balance = account.withdraw(1000);
//			if (balance < 1000) {
//				break;
//			}
		}
	}
}
