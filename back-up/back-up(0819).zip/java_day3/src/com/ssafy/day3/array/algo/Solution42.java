package com.ssafy.day3.array.algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution42 {

	static int T, N, STARTX, STARTY, JUMP, MOVE;
	static int[][] map;
	static int x, y, direction, block;
	
	static int[] dx = {0, -1, 0, 1};
	static int[] dy = {-1, 0, 1, 0};
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;

		T = Integer.parseInt(br.readLine());

		for (int testcase = 0; testcase < T; testcase++) {
			
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			STARTX = Integer.parseInt(st.nextToken());
			STARTY = Integer.parseInt(st.nextToken());
			JUMP = Integer.parseInt(st.nextToken());
			map = new int[N+1][N+1];
			
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < JUMP; i++) {
				x = Integer.parseInt(st.nextToken());
				y = Integer.parseInt(st.nextToken());
				map[x][y] = 1;
			}
			
			MOVE = Integer.parseInt(br.readLine());
			
			x = STARTX;
			y = STARTY;

			boolean flag = true;
			
			st = new StringTokenizer(br.readLine());
			
			moveLoop : for (int i = 0; i < MOVE; i++) {
				direction = Integer.parseInt(st.nextToken());
				block = Integer.parseInt(st.nextToken());
				
				blockLoop : for (int j = 0; j < block; j++) {
					if ( isOut(map, x, y) || isJump(map, x, y) ) {
						flag = false;
						break moveLoop;
					} else {
						x = x + dx[direction%4];
						y = y + dy[direction%4];
					}
				}
					
			}
			if (!flag) {
				x = y = 0;
			}
			
			System.out.printf("\n#%d %d %d\n",testcase+1, x, y);
		}
	}
	
	public static boolean isOut (int[][] map, int x, int y) {

		if( x >= map.length ||  y >= map.length || x <= 0 || y <= 0 )	
			return true;
		else 
			return false;
	}
	
	public static boolean isJump (int[][] map, int x, int y) {
		if( map[x][y] == 1 )
			return true;
		else
			return false;
	}

}
