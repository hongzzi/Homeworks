package com.ssafy.day1.variable;

public class CastTest {

	public static void main(String[] args) {
		// promotion - 묵시적 형변환
		char c = 'A';	// 숫자 --> 문자로 매핑
		System.out.println(c);
		
		// 연산시 형 변환1 : int 이하의 것들 --> 무조건 int
		System.out.println(c + " : " +(c+1));
		// 기본형 - 자기가 값을 갖는다!!
		long l1 = 10l;
		double d1 = 1.0;
		
		// 형변환은 데이터의 크기와는 무관, 타입과 유관
		int i1 = (int)l1;//Type mismatch
		
		// 연산시 형 변환2 : int 이상의 것들 --> 큰 것의 타입
		double d2 = l1 + d1;
		
		int i2 = Integer.MAX_VALUE;
		long l2 = i2 + 1;
		// long l2 = (long)i2 + 1;
		System.out.println(l2);
		// 연산이 먼저여서 +연산에서 int라는 값을 받았기에 l2에 들어가는 값은 int연산으로 오버플로우 된 값이 들어감.
		
		int i3 = 1000000 * 1000000 / 1000000;	// 결과값이 다른 이유는 초기 연산을 먼저하며 오버플로우가 나기때문 
		int i4 = 1000000 / 1000000 * 1000000;
		System.out.println(i3+ " : " +i4);
		
		
	}

}
