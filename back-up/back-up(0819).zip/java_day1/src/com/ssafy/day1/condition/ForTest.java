package com.ssafy.day1.condition;

import java.util.Scanner;

public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
//		System.out.println("몇 단 ?");
//		int dan = sc.nextInt();
//		for (int i = 1 ; i< 10 ; i++) {
//			System.out.println(dan + " * " + i +" = " + i*dan);
//		}
		
		
		for (int i = 1 ; i< 10 ; i++) {
			for (int j = 1; j<10; j++) {
				System.out.println( i + " * " + j + " = " + i*j );
			}
		}
		
				
	}

}
