package com.ssafy.day1.condition;

import java.util.Random;

public class IfTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random rd = new Random();
		int num = rd.nextInt(51);
		String str = new String();
		
		if (num % 2 == 0)
			str = new String("짝수");
		else 
			str = new String("홀수");
		
		str = ( num % 2 == 0 ) ? "짝수" : "홀수" ;

		System.out.println(str + "입니다");
	}

}
