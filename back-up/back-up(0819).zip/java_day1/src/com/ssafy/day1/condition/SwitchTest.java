package com.ssafy.day1.condition;

import java.util.Random;
import java.util.Scanner;

public class SwitchTest {

	public static void main(String[] args) {
		// Month가 몇 일까지 있는지 switch case로 작성하시오.
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("월을 입력하세요.(1~12) : ");
//		int month = sc.nextInt();
		
		
		//(1)
//		int month = (int)(Math.random()*12)+1;
//		System.out.println(month);
		
		//(2)
		Random rd = new Random();
		int month = rd.nextInt(12)+1;
		
		
		switch (month) {

		case 2:
			System.out.println("28일");
			break;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			System.out.println("31일");
			break;
			// default : sysout(31)
		case 4:
		case 6:
		case 9:
		case 11:
			System.out.println("30일");
			break;
		default:
			break;
		}

	}

}
