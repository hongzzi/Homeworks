package com.ssafy.day1.condition;

import java.util.Scanner;

public class WhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Scanner sc = new Scanner(System.in);
//		int dan = sc.nextInt();
//		int i = 0;
//		int result = 1;
//		
//		while( ++i < 10) {
//			System.out.println(dan + " * " + i + " = " + dan*i );
//		}
		
		int j = 1;
		
		outer : while(j<10) {
			int k = 1;
			inner : while (k<10) {
				if (k==5)
					break outer;
				System.out.println(j + " * " + k + " = " + j*k );
				k++;
			}
			j++;
		}
		

	}

}
