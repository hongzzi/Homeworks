package com.ssafy.day1.operator;

public class shortCircuit {

	public static void main(String[] args) {
		
		int i = 10;
		i+=10;
		i-=10;
		System.out.println(i);
		
		int a = 10;
		int b = 20;
		System.out.println((a+=10) > 15 | (b -= 10) > 15 );
		System.out.println(a + " : " + b);
		
		a = 10;
		b = 20;
		System.out.println((a+=10) > 15 || (b -= 10) > 15 );	// or or을 short circuit 연산자라고 부름 , 그래서 뒷부분 b의 연산은 진행되지 않았음 !
		System.out.println(a + " : " + b);
		
	}

}
