package com.ssafy.day1.operator;

public class BitMastTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int homeElecStatus = 0 ;	// 0 32개
		int tvCheck = 0b1;			// 이진수 접두사 0b
		
		String result = "";
		
		// 티비 켜보기
		homeElecStatus |= tvCheck;
		
		// 상태확인 (삼항)
		result = (homeElecStatus & tvCheck) > 0 ? "켜짐" : "꺼짐";
		System.out.println(result);
		
		// 티비 끄기
		homeElecStatus &= 0 ;	// homeElecStatus &=~ tvCheck 
		result = (homeElecStatus & tvCheck) > 0 ? "켜짐" : "꺼짐";
		System.out.println(result);

		
		
	}

}
