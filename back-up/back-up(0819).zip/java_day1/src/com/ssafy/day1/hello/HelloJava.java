package com.ssafy.day1.hello;
// 코드의 포맷 : control + shift + f

public class HelloJava {
	// 클래스 영역에 올 수 있는 것은? = 선언문, 선언문과 함께 쓴 실행문

	// int i, 이건 선언문
	// int i = 10 , 이건 선언문과 함께 쓴 실행문

	static int num1 = 10;

	// java application 시작점
	public static void main(String[] args) { // 선언문

		System.out.println("Hello Java" + num1); // 실행문
		System.out.println();
		
	}

	// 요즘은 변수 자체에 의미를 부여함 ! 길어도 상관없어서 (자동완성)
	// 중괄호는 블럭이라 부름
}
