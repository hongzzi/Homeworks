package com.ssafy.day1.passtest;

public class PassTest {

	public static void main(String[] args) {
		
		int score = 81;
		
		if (score >= 70) {
			System.out.println("합격");
		} else {
			System.out.println("불합격");
		}

	}

}
