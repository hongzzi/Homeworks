package com.saffy.java;

public class DigitTest1 {

	public static void main(String[] args) {
		
		int num = 1; 
		
		for (int i = 0; i<5; i++) {
			// 공백 찍는 녀석
			for (int j = 0 ; j<i; j++) {
				System.out.print("\t");
			}
			// 숫자 찍는 녀석
			for (int k = 0; k<5-i; k++) {
				System.out.print(num++ +"\t");
			}
			
			System.out.println("\n");
		}
	}

}
