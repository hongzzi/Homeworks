package com.saffy.java;

public class DigitTest2 {

	public static void main(String[] args) {

		int num = 1;
		for (int i = 0; i < 5; i++) {

			// 감소
			if (i < 3) {
				for (int j = 0; j < i; j++) {
					System.out.print("\t");
				}
				for (int k = 0; k < 5-(i*2); k++) {
					System.out.print(num++ + "\t");
				}
			} 
			// 증가
			else {
				for (int j = 0; j < 5-i-1 ; j++) {
					System.out.print("\t");
				}
				for (int k = 0; k < 5-((5-i-1)*2) ; k++) {
					System.out.print(num++ + "\t");
				}
			}
			System.out.println();
		}
	}

}
