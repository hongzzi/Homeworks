package com.ssafy.java_day11.sax;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class CheckDTO extends DefaultHandler{

	List<Check> checks;
	Check current = null;
	String data;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.mm.dd");
	public List<Check> getCheck () {
		return checks;
	}
	
	@Override
	public void startDocument() throws SAXException {
		checks = new ArrayList<>();
	}
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("check")) {
			current = new Check();
			checks.add(current);
			for (int i = 0; i < attributes.getLength(); i++) {
				String attrName = attributes.getQName(i);
				String attrValue = attributes.getValue(i);
				if(attrName.equals("code")) {
					current.setCode(Integer.valueOf(attrValue));
				} else if (attrName.equals("date")) {
					try {
						current.setDate(sdf.parse(attrValue));
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		} else if (qName.equals("date")) {
			
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		// TODO Auto-generated method stub
		this.data = String.valueOf(ch, start, length);
	}
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("clean")) {
			current.setClean(data);
		} if (qName.equals("ready")) {
			current.setReady(data);
		} if (qName.equals("response")) {
			current.setResponse(data);
		} if (qName.equals("request")) {
			current.setRequest(data);
		}
		
//		private Integer code;
//		private Date date;
//		private String clean;
//		private String ready;
//		private String response;
//		private String request;
	}
	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		super.endDocument();
	}
}
