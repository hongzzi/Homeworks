package com.ssafy.java_day11.sax;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class SimpleSax {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		
		SAXParser parser = factory.newSAXParser();	//문서 처리의 핵심
		
		MyHandler mh = new MyHandler();
		
//		parser.parse(f, dh);
//		File file = new File("./share/data/addr.xml");
//		parser.parse(file, mh);
		
		InputStream is = SimpleSax.class.getResourceAsStream("../../../../share/data/addr.xml");
		parser.parse(is, mh);
		
		System.out.println(mh.getInfos());
	}

}
