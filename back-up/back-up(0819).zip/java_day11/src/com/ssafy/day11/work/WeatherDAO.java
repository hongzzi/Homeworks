package com.ssafy.day11.work;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ssafy.java.dom.Check;

public class WeatherDAO {

	private List<Weather> list;
	private static WeatherDAO dao = new WeatherDAO();
	public static WeatherDAO getDao() {
		return dao;
	}
	
	private WeatherDAO() {
		list = new ArrayList();
	}
	
	public void connectXML() throws ParserConfigurationException, SAXException, IOException {
		String urlStr = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=4159025300";
        URL url = new URL(urlStr);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		InputStream input = url.openStream();
		Document doc = builder.parse(input);
		Element root = doc.getDocumentElement();
		
		NodeList nodes = root.getElementsByTagName("data");
		for (int i = 0; i < nodes.getLength(); i++) {
			Node weatherNode = nodes.item(i);
			Weather weather = new Weather();
			list.add(weather);
		}
		

	}
}
