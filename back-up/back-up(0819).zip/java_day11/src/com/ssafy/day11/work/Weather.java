package com.ssafy.day11.work;

//http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=4159025300

public class Weather {
	private int hour;
	private double temp;
	private String sfKor;
	private int reh;
	
	public Weather () {}

	private Weather(int hour, double temp, String sfKor, int reh) {
		super();
		this.hour = hour;
		this.temp = temp;
		this.sfKor = sfKor;
		this.reh = reh;
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public double getTemp() {
		return temp;
	}

	public void setTemp(double temp) {
		this.temp = temp;
	}

	public String getSfKor() {
		return sfKor;
	}

	public void setSfKor(String sfKor) {
		this.sfKor = sfKor;
	}

	public int getReh() {
		return reh;
	}

	public void setReh(int reh) {
		this.reh = reh;
	}

	@Override
	public String toString() {
		return "Weather [hour=" + hour + ", temp=" + temp + ", sfKor=" + sfKor + ", reh=" + reh + "]";
	}
	
	
	

}
