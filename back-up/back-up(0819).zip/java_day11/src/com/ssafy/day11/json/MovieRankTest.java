package com.ssafy.day11.json;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.google.gson.Gson;
public class MovieRankTest {
    
    public static void main(String[] args) throws IOException {
        String urlStr = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=430156241533f1d058c603178cc3ca0e&targetDt=20190805";
        URL url = new URL(urlStr);
        InputStream input = url.openStream();
        
        Gson gson = new Gson();
        Map<String, Object> map = gson.fromJson(new BufferedReader(new InputStreamReader(input)), Map.class);
        
//      System.out.println(map);
        
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> map2 = (Map)map.get("boxOfficeResult");
        
        list = (List)map2.get("dailyBoxOfficeList");
        
        System.out.println(list);
        
        for (Map<String, Object> m : list) {
            System.out.print(m.get("rank")+" : "+m.get("movieNm")+"\t");
        }
        
    }
}