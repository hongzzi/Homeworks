package com.ssafy.day11.json;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ssafy.java.dom.Check;
public class JsonResultTest {
    public static void main(String[] args) throws FileNotFoundException {
        FileReader reader = new FileReader("./bin/share/data/result.json");
//      Gson gson = new Gson();
        
        
//      Map<String, Object> map = gson.fromJson(reader, Map.class);
//      
//      System.out.println(map);
//      
//      Map<String, Object> checkList = (Map<String, Object>) map.get("checkList");
//      System.out.println(checkList);
//      
//      List<Map<String, Object>> list = (List)checkList.get("check");
//      
//      System.out.println(list);
//      
//      for (Map<String, Object> map2 : list) {
//          System.out.println(map2);
//      }
        
        GsonBuilder gb = new GsonBuilder().setDateFormat("yyyy.MM.dd");
        
        Gson gson = new Gson();
        
        Type type = new TypeToken<Map<String, Map<String, List<Check>>>>(){}.getType();
        
        Map<String, Map<String, List<Check>>> map = gson.fromJson(reader, type);
        
        System.out.println(map);
        
        System.out.println(map.get("checkList").get("check").get(0).getClean());
    }
}
