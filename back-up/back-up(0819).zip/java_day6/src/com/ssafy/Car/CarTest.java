package com.ssafy.Car;

public class CarTest {

	public static void main(String[] args) {
		
		// CarMgr 얻어오기 --> 차량 추가하기
		CarMgr cmg = CarMgr.getCarMgr();
		
		for (int i = 0; i < 100; i++) {
			String num = String.format("%07d", i);
			Car car = new Car(num, "ziff", 5000000+i);
			System.out.println(cmg.add(car));
//			System.out.println(car.toString());
		}

		
		// 2. Search Test
		System.out.println("===============================================");
		Car[] all = cmg.search();
		for (Car c : all) {
			System.out.println(c.toString());
		}

		// 3. Search(num) Test
		System.out.println("===============================================");
		Car searched = cmg.search("0");
		System.out.println(searched);
		searched = cmg.search("0000005");
		System.out.println(searched);
		
		// 4. search(price) Test
		System.out.println("===============================================");
		Car[] all2 = cmg.search(5000005);
		for (Car c : all2) {
			System.out.println(c.toString());
		}
		
		// 5. update Test
		System.out.println("===============================================");
		System.out.println(cmg.update("0000005", 6000000));
		System.out.println(cmg.update("0000005", 900000));
		searched = cmg.search("0000005");
		System.out.println(searched);
		
		System.out.println("===============================================");
		System.out.println(cmg.delete("0000005"));
		searched = cmg.search("0000005");
		System.out.println(searched);
		
		Car[] all3 = cmg.search();
		for (Car c2 : all3) {
			System.out.println(c2.toString());
		}
	}

}
