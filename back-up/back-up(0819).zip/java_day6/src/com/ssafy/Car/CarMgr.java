package com.ssafy.Car;

import java.util.Arrays;

public class CarMgr {

	private Car[] cars = new Car[100];
	private int index = 0;

	// 싱글턴의 가장 중요부분

	private CarMgr() {
	}

	private CarMgr(Car[] cars, int index) {
		this.cars = cars;
		this.index = index;
	}

	private static CarMgr cm = new CarMgr();

	public static CarMgr getCarMgr() {
		return cm;
	}

	/////////////////////////
	/**
	 * cars배열에 c를 저장하고 index를 관리하자.
	 * 
	 * @param c
	 * @return 저장 성공 여부
	 */
	public boolean add(Car c) {
		if (index >= cars.length) {
			return false;
		} else {
			cars[index++] = c;
			return true;
		}
	}

	public Car[] search() {

		Car[] temp = new Car[index];
		int cnt = 0;
		for (int i = 0; i < index; i++) {
			Car c = cars[i];
			if (c != null) {
				temp[cnt++] = cars[i];
			}
		}
		Car[] answer = new Car[cnt];
		answer = Arrays.copyOf(temp, cnt);
		return answer;
	}

	public Car search(String number) {

		for (int i = 0; i < index; i++) {
			Car c = cars[i];
			if (c != null && c.getNum().equals(number)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * price 보다 저렴한 차량의 정보
	 * 
	 * @param price
	 * @return
	 */
	public Car[] search(int price) {
		int cnt = 0;
		Car[] crr = new Car[index];

		for (int i = 0; i < index; i++) {
			Car c = cars[i];
			if (c != null && c.getPrice() < price) {
				crr[cnt++] = c;
			}
		}
		Car[] answer = Arrays.copyOf(crr, cnt);
		return answer;
	}

	public boolean update(String num, int price) {
		Car c = search(num);
		if (c != null && c.BASE_PRICE < price) {
			c.setPrice(price);
			System.out.println("가격이 변경되었습니다.");
			return true;
		} else {
			System.out.println("해당 번호의 차량이 없거나 가격이 맞지 않습니다.");
			return false;
		}
	}

	public boolean delete(String num) {

		for (int i = 0; i < index; i++) {
			if (cars[i] != null && cars[i].getNum().equals(num)) {
				cars[i] = cars[index - 1];
				cars[index - 1] = null;
				index--;
				return true;
			}
		}
		return false;

	}

	public int size() {
		return index;
	}

	public int totalPrice() {
		int sum = 0;
		for (Car c : cars) {
			sum += c.getPrice();
		}
		return sum;
	}

	public int cntSeat() {
		int seats = 0;
		for (int i = 0; i < index; i++) {
			Car car = cars[i];
			if (car != null) {
				if (car instanceof Bus) {
					seats += ((Bus) car).getSeat();
				} else if (car instanceof Truck) {
					seats += 1;
				} else {
					seats += 4;
				}
			}
		}
		/*
		 * for (Car c : cars) { if(c instanceof Car) { seats += 4; } else if(c
		 * instanceof Bus) { seats += ((Bus) c).getSeat(); } else if(c instanceof Truck)
		 * { seats += 1; } }
		 */
		return seats;
	}

	public int cntCar() {
		int carCnt = index;
		for (int i = 0; i < index; i++) {
			Car car = cars[i];
			if (car instanceof Bus) {
				carCnt--;
			} else if (car instanceof Truck) {
				carCnt--;
			}
		}
		return carCnt;
	}

}
