package com.ssafy.Car;

public class Bus extends Car {

	private int seat;	// 좌석수

	public Bus(String num, String model, int price, int seat) {
		super(num, model, price);
		this.seat = seat;
	}

	public int getSeat() {
		return seat;
	}

	public void setSeat(int seat) {
		this.seat = seat;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+", 좌석수 : "+seat;
	}
	
}
