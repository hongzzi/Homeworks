package com.ssafy.Car;

public class CarTest2 {

	public static void main(String[] args) {

		CarMgr cmg = CarMgr.getCarMgr();

		for (int i = 0; i < 100; i++) {
			String num = String.format("%07d", i);
			Car car;
			if (0 <= i && i < 30) {
				car = new Car(num, "ziff", 5000000 + i);
			} else if(30<= i && i<60) {
				car = new Bus(num, "bus1000", 10000000 + i, 100);
			} else {
				car = new Truck(num, "truck2000", 15000000 + i, 8);
			}
			System.out.println(cmg.add(car));
		}
		System.out.println("===============================================");
		Car[] all = cmg.search();
		for (Car c : all) {
			System.out.println(c.toString());
		}
		System.out.println("===============================================");
		int totalSeats = cmg.cntSeat();
		System.out.println("전체 좌석 수는 " + totalSeats + "입니다.");

		System.out.println("===============================================");
		int numCars = cmg.cntCar();
		System.out.println("자동차 수는 " + numCars + "입니다.");
	}
}
