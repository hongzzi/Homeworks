package com.ssafy.Car;

public class Car {

	static final int NUM_LENGTH = 7; // 차마다 속하지만, 개별적으로 바뀌는 값이 아니기 때문에 static 선언
	static final int BASE_PRICE = 5000000;
	// num은 7자리의 문자열로 구성되어야 한다.
	private String num;
	// model은 null이 될 수 없다.
	private String model;
	// 금액은 500만원 이상이다.
	private int price;

	public Car() {
	}

	public Car(String num, String model, int price) {
		super();
		this.num = num;
		this.model = model;
		this.price = price;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		if (num.length() != 7) {
			System.out.println("차량 번호는 7자리 입니다.");
		} else {
			this.num = num;
		}
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		if (model != null) {
			System.out.println("모델은 null이 될 수 없습니다.");
		} else {
			this.model = model;
		}
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		if (price < BASE_PRICE) {
			System.out.println("500만원 이상이여야 합니다.");
		} else {
			this.price = price;
		}

	}
	
	@Override
	public String toString() {
		return "차량번호 : "+num+", 모델 : "+model+", 가격 : "+price;
	}

}
