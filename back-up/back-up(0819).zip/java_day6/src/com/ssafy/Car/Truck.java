package com.ssafy.Car;

public class Truck extends Car{
	
	private int ton;

	public Truck(String num, String model, int price, int ton) {
		super(num, model, price);
		this.ton = ton;
	}

	public int getTon() {
		return ton;
	}

	public void setTon(int ton) {
		this.ton = ton;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+", 톤 : "+ton;
	}
	

}
