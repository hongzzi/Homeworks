/**
 * 
 */
package com.ssafy.Movie;

import java.util.Scanner;

/**
 * @author student
 *
 */
public class MovieMgrCmd {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		MovieMgrCmd cmd = new MovieMgrCmd();
		
		System.out.println("");
		
	}
	
	public void menu() {
		System.out.println("0");
	}
}
