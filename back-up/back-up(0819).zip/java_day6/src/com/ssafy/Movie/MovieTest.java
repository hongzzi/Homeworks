package com.ssafy.Movie;

public class MovieTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MovieMgr mgr = MovieMgr.getMovieMgr();

		for (int i = 0; i < 100; i++) {
			Movie m;
			if (i < 20) {
				m = new Movie("데드풀", "라이언레이놀즈", i, "액션/코미디", "액션영화");
			} else if(i < 40) {
				m = new Movie("스파이더맨", "누구더라", i, "액션", "청소년 스파이더맨");
			} else if(i < 60) {
				m = new Movie("토르", "타이가", i, "액션", "사랑과 번개?");
			} else {
				m = new Movie("뽀로로", "뽀로로", i, "유아", "노는걸 좋아함");
			}
			System.out.println(mgr.add(m));
		}
		
		System.out.println("=====================================================================");
		Movie[] ms = mgr.search();
		for(Movie m : ms) {
			System.out.println(m.toString());
		}
		
		System.out.println("=====================================================================");
		Movie[] ms2 = mgr.search("스");
		for(Movie m : ms2) {
			System.out.println(m.toString());
		}
		System.out.println("=====================================================================");
		Movie[] ms3 = mgr.searchDirector("타이가");
		for(Movie m : ms3) {
			System.out.println(m.toString());
		}
		System.out.println("=====================================================================");
		Movie[] ms4 = mgr.searchGenre("유아");
		for(Movie m : ms4) {
			System.out.println(m.toString());
		}
		System.out.println("=====================================================================");
		System.out.println(mgr.delete("스파이더맨"));
		
		System.out.println("=====================================================================");
		Movie[] ms5 = mgr.search();
		for(Movie m : ms5) {
			System.out.println(m.toString());
		}
	}

}
