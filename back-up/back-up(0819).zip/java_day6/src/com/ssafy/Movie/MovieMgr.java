package com.ssafy.Movie;

import java.util.Arrays;

public class MovieMgr {

	private Movie[] movies = new Movie[100];
	private int index;

	private static MovieMgr mgr = new MovieMgr();

	public static MovieMgr getMovieMgr() {
		return mgr;
	}

	// add
	public boolean add(Movie m) {

		if (movies[index] == null) {
			movies[index++] = m;
			return true;
		} else {
			return false;
		}
	}

	// search
	public Movie[] search() {
		return movies;
	}

	// search(title)
	public Movie[] search(String title) {

		Movie[] temp = new Movie[index];
		int movieCnt = 0;

		for (int i = 0; i < index; i++) {
			Movie m = movies[i];
			if (m != null && m.getTitle().contains(title)) {
				temp[movieCnt++] = m;
			}
		}
		Movie[] answer = Arrays.copyOf(temp, movieCnt);
		if (movieCnt == 0)
			return null;
		else
			return answer;
	}

	// search(director)
	public Movie[] searchDirector(String name) {

		Movie[] temp = new Movie[index];
		int movieCnt = 0;

		for (int i = 0; i < index; i++) {
			Movie m = movies[i];
			if (m != null && m.getDirector().equals(name)) {
				temp[movieCnt++] = m;
			}
		}
		Movie[] answer = Arrays.copyOf(temp, movieCnt);
		if (movieCnt == 0)
			return null;
		else
			return answer;
	}

	// search(genre)
	public Movie[] searchGenre(String genre) {

		Movie[] temp = new Movie[index];
		int movieCnt = 0;

		for (int i = 0; i < index; i++) {
			Movie m = movies[i];
			if (m != null && m.getGenre().equals(genre)) {
				temp[movieCnt++] = m;
			}
		}
		Movie[] answer = Arrays.copyOf(temp, movieCnt);
		if (movieCnt == 0)
			return null;
		else
			return answer;
	}

	// delete(title)
	public boolean delete(String title) {
		for (int i = 0; i < index; i++) {
			if(movies[i].getTitle().equals(title)) {
				movies[i] = movies[index-1];
				movies[index-1] = null;
				index--;
				return true;
			}
		}
		return false;
	}

	// getSize
	public int getSize() {
		return index;
	}

}
