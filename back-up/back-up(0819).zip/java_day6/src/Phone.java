// 

public class Phone {
    private String number;
    private int price;

    public void call(String number){
    }

    public void Phone(String number){
    }

}
