package com.ssafy.time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Date d = new Date();
		System.out.println(d);
		System.out.println(d.getTime());
		
		// 날짜의 포멧 변경
		SimpleDateFormat format =new SimpleDateFormat("yyyy/MM/dd(E)");
		String dateStr = format.format(d);
		System.out.println(dateStr);
		
		Date reDate = format.parse(dateStr);
		System.out.println(reDate);
	}

}
