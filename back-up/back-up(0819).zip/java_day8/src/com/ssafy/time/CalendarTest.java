package com.ssafy.time;

import java.util.Calendar;
import java.util.Date;

public class CalendarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar cal = Calendar.getInstance();
		System.out.println(cal);
		// Date <--> Calendar
		Date d = cal.getTime();
		cal.setTime(new Date());
		// 특정 시각 정보 조회 - Calendar의 상수와 get 메서드 이용
		int year = cal.get(Calendar.YEAR);
		System.out.println("올해는 "+year+"년");
		// 지금은 몇 월?
		System.out.println("지금은 "+(cal.get(Calendar.MONTH)+1));
		// 특정 시각으로 변경
		cal.set(Calendar.YEAR, 1000);
		System.out.println("올해는 "+cal.get(Calendar.YEAR)+"년");
		long calTime = cal.getTimeInMillis();
		long nowTime = new Date().getTime();
		long nowTime2 = System.currentTimeMillis();
		System.out.println((nowTime - calTime)/1000/60/60/24/365);
		
		
	}
	

}
