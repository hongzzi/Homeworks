package com.ssafy.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy2 {
	File src = new File("c:/windows/explorer.exe");
	File dest = new File("c:/Temp/myexplorer.exe");
	int bufferSize = 10;

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		
		FileCopy2 fc = new FileCopy2();
		// Buffered : 내부 버퍼를 이용해 속도 향상
		try(BufferedInputStream fi= new BufferedInputStream(new FileInputStream(fc.src));
			BufferedOutputStream fout =	 new BufferedOutputStream(new FileOutputStream(fc.dest));) {
			byte [] buffer = new byte[fc.bufferSize];
			int readed = -1;
			while( (readed = fi.read(buffer))>0) {
				fout.write(buffer, 0, readed);
			}
			System.out.println("done");
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			long end = System.currentTimeMillis();
			System.out.println("buffer: "+ fc.bufferSize+" 소요시간:  "+(end-start));
		}

	}

}
