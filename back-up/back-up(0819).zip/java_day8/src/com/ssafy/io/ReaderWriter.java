package com.ssafy.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderWriter {
	public static void main(String[] args) {
		fileTest();
		writeFile();
	}
	// 파일 처리

	public static void fileTest(){
		File file = new File("./hello.txt");
		System.out.println(file.getAbsolutePath());
		try {
			file.createNewFile();
			System.out.println("file creation complete!");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	

	// 데이터 읽어보기
	public static void writeFile() {
		FileReader fi = null;
		FileWriter fout = null;
		
		try {
			fi = new FileReader("./hello.txt");
			fout = new FileWriter("./output.txt");
			
			// 기본 파일 전송 버퍼
			char[] buffer = new char[5];
			int readed = 0;	
			
			while ((readed = fi.read(buffer)) > 0) {	// 데이터를 다 읽어들이면 read는 -1반환
				System.out.println(new String(buffer, 0, readed));
				fout.write(buffer, 0, readed);
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		} finally {
			if (fi != null) {
				try {
					fi.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
}
