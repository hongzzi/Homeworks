package com.ssafy.exception;

public class NegativeAgeException extends RuntimeException{
	public NegativeAgeException(int age) {
		super("나이는 양수 : "+age);
	}
}
