package com.ssafy.exception;

public class SimpleException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("Hello");
		}catch(ClassNotFoundException e) {
			//System.out.println("예외 처리 완료" +e.getMessage());
			e.printStackTrace();
		}
		System.out.println("프로그램 종료");
	}
	

}
