package com.ssafy.exception;

public class PersonTest {

	public static void main(String[] args) {
		try {
			Person p = new Person();
			p.setName("홍길동");
			System.out.println(p.getName());
			p.setName(null);
		} catch (ValueIsNullException e) {
			System.out.println(e.getMessage());
		}

		try {
			Person p2 = new Person();
			p2.setAge(-10);
		} catch (NegativeAgeException e) {
			e.printStackTrace();
		}

	}

}
