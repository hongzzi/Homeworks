package com.ssafy.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SimpleException5 {
	public static void main(String[] args) {
		try {
			// FileNotFoundException
			FileInputStream fi = new FileInputStream("some");
			// IOException
			fi.read();
			// 계층 관계에서는 자식이 먼저 나올 것
		} catch (FileNotFoundException e) {
			System.out.println("filenotfound 처리");
		} catch (IOException e) {
			System.out.println("ioexception 처리");
		} catch (Exception e) {
			System.out.println("모든 예외 처리");
		} finally {
			System.out.println("언제나 실행");
		}

	}
}
