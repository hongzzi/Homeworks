package com.ssafy.exception;

import java.util.Scanner;

public class FinalTest {

	public static void main(String[] args) {
		System.out.println(1);
		Scanner s = null;
		try {
			s = new Scanner(System.in);
			//s.next();
			System.out.println(2);
			int i = 1 / 0;
			System.out.println(3);
		} catch (ArithmeticException e) {
			System.out.println(4);
			return;
			//System.exit(0);
		} catch (Exception e) {
			System.out.println(5);
		} finally {
			System.out.println(6);
			if(s!=null) {
				s.close();
			}
		}

	}

}
