package com.ssafy.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SimpleException4 {

	public static void main(String[] args) {
		try {
			Class.forName("Hello");
			new FileInputStream("some file");
			DriverManager.getConnection("some");
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		try {
			Class.forName("Hello");
			new FileInputStream("some file");
			DriverManager.getConnection("some");
			// 예외의 처리 내용이 같을때
		}catch(FileNotFoundException| ClassNotFoundException e) {	
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	interface I{}
	class C1{}
	class C2{}
	class C3 extends C2 implements I{}
	
	void method() {
		C3 c3 = new C3();
		//If T is a class type, then S must be the same class as T, or S must be a subclass of T;
		//System.out.println(c3 instanceof C1);

		System.out.println(c3 instanceof Comparable);
		
		I ci = new C3();
	}
	
	
	
	
	
	

}
