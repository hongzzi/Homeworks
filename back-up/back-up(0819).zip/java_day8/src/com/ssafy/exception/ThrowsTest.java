package com.ssafy.exception;

import java.io.FileNotFoundException;
import java.io.IOException;

public class ThrowsTest {

	class Inner1{
		void method() throws IOException{}
	}
	class Inner2 extends Inner1{
		// 부모가 치지 않은 사고를 자식이 칠수는 없다.
		//void method() throws Exception{}
		//void method() throws IOException{}
		//void method() throws FileNotFoundException{}
		void method(){}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			method();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void method() throws Exception{
		// 임의로 예외 발생시키기
		throw new Exception();
	}
}
