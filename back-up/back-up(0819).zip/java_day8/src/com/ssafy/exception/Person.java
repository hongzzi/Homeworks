package com.ssafy.exception;

public class Person {
	private String name;
	private int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {// runtime 계열: 별도의 throws 필요 없음
		if(age <0) {
			throw new NegativeAgeException(age);
		}
		this.age = age;
	}


	public void setName(String name) throws ValueIsNullException {
		if (name == null) {
			//System.out.println("name is null");
			throw new ValueIsNullException("name");
		} else {
			this.name = name;
		}
	}

	public String getName() {
		return name;
	}
}
