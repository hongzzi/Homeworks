package com.ssafy.exception;

public class ValueIsNullException extends Exception{// checked exception
	public ValueIsNullException(String column) {
		super(column+"은 null 불가~!!");
	}
}
