package com.ssafy.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SimpleException3 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		while (true) {
			System.out.println("숫자 입력하세요.");
			try {
				int i = s.nextInt();
				System.out.println(i);
				break;
			} catch (InputMismatchException e) {
				s.nextLine();
				System.out.println(e.getMessage());
			}
		}
		s.close();
		System.out.println("종료");
	}
}
