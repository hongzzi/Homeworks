package com.ssafy.work;

import java.util.List;

import com.ssafy.work.exception.ISBNNotFoundException;
import com.ssafy.work.exception.QuantityException;

import java.util.ArrayList;
import java.util.Collection;

public class BookMgrImpl<Megazine> implements IBookMgr {

	private List<Book> books = new ArrayList<>();

	private static BookMgrImpl bmi = new BookMgrImpl();

	private BookMgrImpl() {
	}

	private BookMgrImpl(List<Book> books) {
		this.books = books;
	}

	public static BookMgrImpl getBookMgrImpl() {
		return bmi;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	@Override
	public boolean addBook(Book book) {
		for (Book b : books) {
			if (book.getIsbn().equals(b.getIsbn())) {
				return false;
			}
		}
		books.add(book);
		return true;
	}

	@Override
	public int getSumPrice() {
		int sumPrice = 0;
		for (Book book : books) {
			sumPrice += book.getPrice();
		}
		return sumPrice;
	}

	@Override
	public Book getBookByIsbn(String isbn) {
		Book book = null;
		for(Book b : books) {
			if (b.getIsbn().equals(isbn)) {
				book = (Book)b;
			}
		}
		return book;
	}

	@Override
	public Collection<Book> getBookByTitle(String title) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = null;
		for(Book b : books) {
			if (b.getTitle().contains(title)) {
				book = (Book)b;
				bks.add(book);
			}
		}
		return bks;
	}

	@Override
	public Collection<Book> getBookOnly() {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = null;
		for(Book b : books) {
			if(!(b instanceof Magazine)) {
				book = (Book)b;
				bks.add(book);
			}
		}
		return bks;
	}

	@Override
	public Collection<Magazine> getMagazine() {
		Collection<Magazine> mgs = new ArrayList<Magazine>();
		Magazine maga = null;
		for(Book b : books) {
			if(b instanceof Magazine) {
				maga = (Magazine)b;
				mgs.add(maga);
			}
		}
		return mgs;
	}

	@Override
	public Collection<Magazine> getMagazinePublishedThisYear(int year) {
		Collection<Magazine> mgs = new ArrayList<Magazine>();
		Magazine maga = null;
		for(Book b : books) {
			if (b instanceof Magazine) {
				maga = (Magazine)b;
				if(maga.getYear() == year) {
					mgs.add(maga);
				}
			}
		}
		return mgs;
	}

	@Override
	public Collection<Book> getBookByPublisher(String publisher) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = null;
		for(Book b : books) {
			if(b.getPublisher().equals(publisher)) {
				bks.add(b);
			}
		}
		return bks;
	}

	@Override
	public Collection<Book> getBookLowerPrice(int price) {
		Collection<Book> bks = new ArrayList<Book>();
		Book book = null;
		for(Book b : books) {
			if(b.getPrice() <= price) {
				bks.add(b);
			}
		}
		return bks;
	}

	@Override
	public double getAvgPrice() {
		int sum = this.getSumPrice();
		return sum/books.size();
	}

	@Override
	public void sell(String isbn, int quantity) throws QuantityException, ISBNNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getTotalAmount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection<Book> getBookAll() {
		return books;
	}
	
//	List<Book> temp = new ArrayList<>(magazine);
//	// 출력 시 Book 이 가지고 있는 가격 오름차순으로 정렬하시오.
//	// 단 가격이 가을 경우 ISBN 순으로 
//	Collection.sort(temp, )
	

}
