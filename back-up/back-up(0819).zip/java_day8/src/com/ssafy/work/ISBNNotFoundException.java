package com.ssafy.work;

public class ISBNNotFoundException extends Exception{

}
