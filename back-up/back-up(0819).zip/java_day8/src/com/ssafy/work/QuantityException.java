package com.ssafy.work;

public class QuantityException extends Exception {

}
