package com.ssafy.date;

import java.util.Calendar;
import java.util.Date;

public class CalendarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar cal = Calendar.getInstance();
		System.out.println(cal);
		// Date <--> Calendar
		Date d = cal.getTime();
		cal.setTime(new Date());
		// 특정 시각 정보 조회 - Calendar의 상수와 get 메서드 이용
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		System.out.println("올해는 "+year+"."+month+"입니다");
		// 월은 0부터 시작하므로 +1 해주어야함
		
		// 특정 시각으로 변경
		cal.set(Calendar.YEAR, 1919);
		year = cal.get(Calendar.YEAR);
		month = cal.get(Calendar.MONTH);
		System.out.println("올해는 "+year+"."+month+"입니다");
		System.out.println();
		
		long calTime = cal.getTimeInMillis();
		long nowTime = new Date().getTime();
		System.out.println((nowTime - calTime)/1000/60/60/24/365);
		
		
		long nowTime2 = System.currentTimeMillis();
	}

}
