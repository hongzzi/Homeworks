package com.ssafy.call;
// 1. 패키지
// 2. import
// 3. 클래스
public class Home {

	// 집의 면적 양수만
	private int area;

	
	public Home() {
		
	}
	
	public Home(int area) {
		this.area = area;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		if (area > 0) {
			this.area = area;
		}
	}

	// 4. 멤버변수
	// 5. 생성자
	// 6. 겟터셋터
	
}
