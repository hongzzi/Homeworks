package com.ssafy.call;

public class HomeTest2 {
	Home [] homes = {new Home(10), new Home(20)};
	
	public static void main(String[] args) {
		// 각 집의 면적을 출력하세요.
		HomeTest2 ht = new HomeTest2();
		HomeTest ht1 = new HomeTest();
		
		// static .. 주의 ..
		for (Home home : ht.homes) {
			System.out.println(home.getArea());
			ht1.increase(home);
			System.out.println(home.getArea());
		}
	}
}
