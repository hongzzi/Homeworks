//package com.ssafy.book;
//
//import com.ssafy.work.Book;
//import com.ssafy.work.Magazine;
//
//public class BookTest {
//	
//	Book [] books = { 
//			new Book("21424", "Java Basic", "김하니", "Jean.kr", 15000, "Java 기본 문법"),
//			new Book("33455", "JDBC Pro", "김철수", "Jean.kr", 23000),
//			new Book("5355", "Servlet/JSP", "박자바", "Jean.kr", 41000,"Model2 기반"),
//			new Book("3332", "Android App", "홍길동", "Jean.kr", 25000, "Lightweight Framework"),
//			new Book("35355", "OOAD분석, 설계", "소나무", "Jean.kr", 30000)
//			};
//	
//	Magazine [] magazines = { 
//			new Magazine("35535", "Java World", "편집부", "Jean.kr", 2013, 2, 7000),
//			new Magazine("33434", "Mobile World", "편집부", "Jean.kr", 2013, 8, 8000),
//			new Magazine("75342", "Next Web", "편집부", "Jean.kr", 2012, 10, 10000,"AJAX 소개"),
//			new Magazine("76543", "Architecture", "편집부", "Jean.kr", 2010, 3, 5000,"java 시스템"),
//			new Magazine("76534", "Data Modeling", "편집부", "Jean.kr", 2012, 12, 14000)
//			};
//
//	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		BookTest bt = new BookTest();
//
//		
//		System.out.println("****************** 도서 목록 ******************\n");
//		
//		for(Book book : bt.books) {
//			System.out.println(book.toString());
//		}
//		
//		System.out.println("\n****************** 잡지 목록 ******************\n");
//		
//		for(Magazine magazine : bt.magazines) {
//			System.out.println(magazine.toString());
//		}
//	}
//
//}
