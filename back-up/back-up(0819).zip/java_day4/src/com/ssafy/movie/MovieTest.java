package com.ssafy.movie;

public class MovieTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Movie movie = new Movie();	// new 생성자()
		movie.movieInfo();
		movie.title = "맨인블랙";
		movie.movieInfo();
		
		Movie movie2 = new Movie();
		movie2 = movie;	// 이렇게 되면 movie2가 가비지가 되버림
		
		movie2.title = "기생충";
		movie.movieInfo();
	}

}