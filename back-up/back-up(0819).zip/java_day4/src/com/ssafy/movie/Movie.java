package com.ssafy.movie;

public class Movie {
/**
 * 
 */
	// 멤버 변수
	String title;
	String director;
	int grade;
	String genre;
	String summary;

	public Movie () {
		
		
	}
	
	public Movie (String title, String director, int grade, String genre) {
		this(title, director, grade);
		this.genre = genre;
	}
	
	public Movie (String title, String director, int grade, String genre, String summary) {
//		this.title = title;			// 자신의 멤버를 지정할 때 ㅎㅎ this 는 객체를 의미함 
//		this.director = director;
//		this.grade = grade;
//		this.genre = genre;
//		this.summary = summary;
		this(title, director, grade, genre);	// this의 두번째 용법 ** 근데 얘는 다른애 앞에만 올수있음
		this.summary = summary;
	}


	
	public Movie(String title, String director, int grade) {
		this.title = title;
		this.director = director;
		this.grade = grade;
	}

	// 멤버 메서드
	public void movieInfo() {
		System.out.println(this.toString());
		return;
	}

	public String toString() {

		return title+" : "+director+" : "+grade+" : "+genre+" : "+summary;
	}

}
