package com.ssafy.person;

public class Person {
	// class member 변수, static member 변수
	static String scientificName;

	// instance member 변수
	private String name;
	private int age;

	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else {
			System.out.println(" name 속성은 not null ");
		}
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if (age < 0) {
			System.out.println(" age 속성은 양의 정수여야 합니다.");
		} else {
			this.age = age;
		}
	}

	// 생성자 - 멤버 변수의 초기화 역할
	public Person(String n, int a) { // void 안씀
		name = n;
		age = a;
	}

	public void walk() {
		walk(100);
	}

	public void walk(int cm) {
		walk(cm, "cm");
	}

	public void walk(int cm, String unit) {
		if (unit.equals("inch")) {
			cm = (int) 2.54 * cm;
		}
		System.out.println(cm + "cm 이동");
	}
}
