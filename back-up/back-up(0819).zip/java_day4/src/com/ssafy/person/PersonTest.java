package com.ssafy.person;

public class PersonTest {

	public static void main(String[] args) {
		Person.scientificName = "호모사피엔스";
		Person p1 = new Person("홍길동", 10);
		Person p2 = new Person("임꺽정",20);
		
//		// name은 null이 될 수 없습니다.
//		p1.name = null;
//		p1.age = -10;
//		System.out.println(p1.name);
		
		System.out.println(p1.getName());
		p1.setName(null);
		p1.setAge(-10);
		
		System.out.println(p1.getName() + " : " + p1.getAge());
	
		// 주석은 데이터에 관섭을 못하므로 데이터 보호처리가 중요 
		
		
		// 스태틱변수는 모든 객체가 공유하는 변수 ! 
		// => 스태틱한 방법은 객체로 접근 X 클래스를 통해서 접근하라 ! (객체 이용해서 하면 워닝뜸) 
		
		
		// 메서드도 객체형이면 객체형 변수에 접근가능
		// 메서드가 스태틱일땐 객체 선언하고 객체형 변수에 접근
		// 다른 클래스 스태틱에 접근할때도 클래스.스태틱.. 똑같음. 
		// 인자로 클래스 객체를 받는다면 이미 생성되어있다는 가정하에 그냥 객체변수 호출 ok
		
		// 결론 => 메모리에 있으면 메모리에 할당하고 부름, 있으면 그냥 부름
	}
}
