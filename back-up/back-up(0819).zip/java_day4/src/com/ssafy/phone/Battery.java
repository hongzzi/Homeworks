package com.ssafy.phone;

public class Battery {

	int capacity;
	int current;
	String type;
		
	public Battery(int capacity, String type) {
		
		this.capacity = capacity;
		this.type = type;
	
	}
	
	
	// 충전량이 capacity를 넘지 못하도록 처리하시오.
	public void charge(int elec) {
		if (current + elec >= capacity ) {
			System.out.println("배터리 완충.. 더이상 충전할 수 없습니다.");
			this.current = capacity;
		} else {
			this.current+=elec;
			System.out.println("배터리 충전중 : "+current+elec);
		}
	}

}
