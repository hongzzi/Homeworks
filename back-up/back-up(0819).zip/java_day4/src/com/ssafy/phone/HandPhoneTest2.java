package com.ssafy.phone;

public class HandPhoneTest2 {

	public static void main(String[] args) {
		// 두 개의 전화를 만들어서 전화기 1에서 전화기 2로 전화하기
		
		HandPhone hp1 = new HandPhone("01020537168", 8, 300, "lidue");
		HandPhone hp2 = new HandPhone("01062540462", 7, 200, "lidue");
		
		hp1.call("01029292929");
		hp1.call();
	}
	
	
}
