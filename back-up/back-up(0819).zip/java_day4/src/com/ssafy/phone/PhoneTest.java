package com.ssafy.phone;
/**
 * 
 * 이 클래스는 핸드폰을 만들어본다
 * @author student
 *
 */
public class PhoneTest {

	public static void main(String[] args) {
	
		HandPhone hp = new HandPhone("10231", 5, 100, "Ctype");
		System.out.println(hp.battery.capacity);
//		hp.number = "010-1234-5678";
//		hp.charge(100);
		
		Battery bt = new Battery(300, "Li");
		HandPhone hp2 = new HandPhone("10101", 7, bt);
		System.out.println(hp2.battery.capacity);
		
		hp2.charge(100);
		
		System.out.println("hp : " + hp);
		
	}

}
