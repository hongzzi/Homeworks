package com.ssafy.phone;

public class HandPhone {

	//오늘한거 오버로딩
	
	String number;
	String lastCallNumber;
	int width;
	Battery battery;

	public HandPhone(String number, int width, int capacity, String type) {

		this.number = number;
		this.width = width;
		battery = new Battery(capacity, type);
	}

	public HandPhone(String number, int width, Battery battery) {

		this.number = number;
		this.width = width;
		this.battery = battery;
	}

	public void charge(int elec) {
		System.out.println(this);
		battery.charge(elec);
	}

	public void call() {
		if (lastCallNumber != null) {
			call(lastCallNumber);
		}
	}

	public void call(String number) {
		String beep = "띠~";
		for (int i = 0; i < 3; i++) {
			System.out.println(beep);
		}
		System.out.println(this.number + "에서 " + number + " 에게 전화함");
		this.lastCallNumber = number;
	}
}
