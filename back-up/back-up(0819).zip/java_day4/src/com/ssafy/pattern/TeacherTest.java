package com.ssafy.pattern;

public class TeacherTest {
 
	// 상태를 갖지않고 ... 멤버 변수가 별의미가 없고 기능만 있을떄 (stateless) 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletonTeacher st = SingletonTeacher.getTeacher();
		st.teach();
		
		SingletonTeacher st2 = SingletonTeacher.getTeacher();
		st2.teach();
		
		System.out.println(st==st2);
	}

}
