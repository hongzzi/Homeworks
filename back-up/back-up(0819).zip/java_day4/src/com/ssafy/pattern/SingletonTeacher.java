package com.ssafy.pattern;

public class SingletonTeacher {
	
	
	// 내부에서 객체 생성
	private static SingletonTeacher st = new SingletonTeacher("박지홍");
	// private한 멤버변수에 접근할 수 있는 메서드 --> 객체 생성없이 접근하도록 static 처리
	public static SingletonTeacher getTeacher() {
		return st;
	}
	
	private String name;
	
	private SingletonTeacher(String name) {
		this.name = name;
	}
	
	public void teach() {
		System.out.println(name + "이 열심히 가르친다." + this);
	}
}
