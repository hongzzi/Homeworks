package day2.lab.book.robot;

import java.util.Arrays;
import java.util.Scanner;

public class Robot {
	static int T, N; // T: 테스트케이스 수, N: 크기
	static int Answer; // Answer: 답

	public static void main(String[] args) throws Exception {
		System.setIn(Robot.class.getResourceAsStream("Robot.txt")); // *****
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			N = sc.nextInt();
			char[][] map = new char[N][N];
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					map[i][j] = sc.next().charAt(0);
				}
			}

			//////////////////////////////
			// ( 이 부분에 알고리즘 구현을 한다. )//
			// 입력확인!

			for (char[] c : map)
				System.out.println(Arrays.toString(c));

			int total = 0;

			for (int i = 0; i < map.length; i++) {
				for (int j = 0; j < map.length; j++) {
					char key = map[i][j];
					switch (key) {
					case 'C':
						for (int k = i-1; k >= 0; k--) {
							if ( map[k][j] == 'S') {
								total++;
							}
							else break;
						}
						for (int k = i+1; k < map.length; k++) {
							if ( map[k][j] == 'S') {
								total++;
							}
							else break;
						}
					case 'B':
						for (int k = j - 1; k >= 0; k --) {
							if ( map[i][k] == 'S')
								total++;
							else break;
						}
					case 'A':
						for (int k = j + 1; k < map.length; k++) {
							if ( map[i][k] == 'S')
								total++;
							else break;
						}
						break;
					default:
						break;
					}
				}
			}
			Answer = total;
			//////////////////////////////
			System.out.println("#" + test_case + " " + Answer);
		}
	}

}