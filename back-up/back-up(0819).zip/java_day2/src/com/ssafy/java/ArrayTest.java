package com.ssafy.java;

import java.util.Arrays;
import java.util.Scanner;

// 다 안했음 ~~~~~

public class ArrayTest {

	static int[] list;

	public static void print() {

		for(int l: list)
			System.out.print(l+" ");
		System.out.println();
	}

	public static void total() {
		System.out.print("배열의 합 : ");
		int sum = 0 ;
		for(int l: list)
			sum += l;
		System.out.println(sum);
	}
	
	public static void average() {
		System.out.print("배열의 평균 : ");
		int sum = 0 ;
		for(int l: list)
			sum += l;
		System.out.println(sum/10);
	}
	
	public static void minimum() {
		
		int min = Integer.MAX_VALUE;
		for(int num: list)
			if(min > num)
				min = num;

		
	}
	
	public static void selectionSort() {
		
		Arrays.sort(list);
		System.out.println("=== selection sort (Ascending Order) ===");
		for (int l: list) {
			System.out.print(l+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		list = new int[10];
		
		Scanner sc = new Scanner(System.in);
		for (int i=0; i<10; i++)
			list[i] = sc.nextInt();
		
		print();
		total();
		average();
		minimum();
		selectionSort();

	}

}
