package com.ssafy.day2.type;

import java.util.Arrays;

public class FloatProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 선언 + 생성
		int[] nums2 = new int[5];
		
		// 선언 + 생성 + 요소 할당
		int[] nums3 = { 1, 2, 3, 4, 5 };
		
		// 선언부 X 생성과 요소 할당 
		args = new String[] {"Hello"};
		
		for (int i = 0; i<nums3.length; i++) {
			int num = nums3[i];
			System.out.println(num);
			System.out.printf("%d번째 요소: %d\n", i, num);
		}
		
		for (int s: nums3)
			System.out.println(s);
		
		// 배열 내용을 단지 확인만 해보고싶음
		System.out.println(Arrays.toString(nums3));
		
	}

}
