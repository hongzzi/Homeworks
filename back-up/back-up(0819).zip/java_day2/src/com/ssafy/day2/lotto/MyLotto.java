package com.ssafy.day2.lotto;

import java.sql.Array;
import java.util.Arrays;
import java.util.Random;

public class MyLotto {

	int lo[] = new int[6];

	public void selectLotto() {

		for (int i = 0; i < lo.length; i++) {
			lo[i] = uniqueNumber(i);
		}

	}

	private int uniqueNumber(int index) {

		Random rd = new Random();
		boolean unique;
		int tmp;
		
		do {
			tmp = rd.nextInt(45) + 1;
			unique = false;
			for (int i = 0; i < index; i++) {
				if (tmp == lo[i]) {
					unique = true;
					break;
				}
			}
		} while (unique);

		return tmp;

	}

	void print() {

		System.out.println("* 로또당첨번호는 =>  ");
		Arrays.sort(lo);
		System.out.println(Arrays.toString(lo));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyLotto lotto = new MyLotto();

		lotto.selectLotto();
		lotto.print();

	}

}
