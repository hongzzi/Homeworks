package com.ssafy.day2.array;

import java.util.Arrays;

public class CopyArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] target = new String[10];
		
		String str = "Hello Java World~~~~";
		String[] strArray = new String[3];

		strArray = str.split(" ");
		
		System.arraycopy(strArray, 0, target, 0, strArray.length);
		
		System.out.println(Arrays.toString(target));
	}

}
