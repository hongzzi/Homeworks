package com.ssafy.day2.array;

public class SimpleArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 배열 선언
		int[] nums;
		
		nums = new int[5];
		System.out.println(nums);
		
		nums[2] = 'A';
		for (int s: nums)
			System.out.println(s);
		
		System.out.println((char)nums[2]);
		// 배열의 각 공간은 변수의 기본 값으로 초기화 됨
		// int ~ = 0, float ~ = 0.0, c ~ = /u 0000, b = false, reference = null
//		int[] nums2 = new int[];
	}

}
