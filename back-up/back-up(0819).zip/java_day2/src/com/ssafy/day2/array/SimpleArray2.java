package com.ssafy.day2.array;

import java.util.Arrays;

public class SimpleArray2 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		String str = "Hello Java World~~~~";
		String[] strArray = new String[3];

		strArray = str.split(" ");
		
		System.out.println(Arrays.toString(strArray));

		int maxStrIndex = 0;
		int maxStrLen = 0;

		for (String s : strArray) {
			System.out.println(s.length());
		}
		for (int i=0; i<3; i++) {
			if(maxStrLen < strArray[i].length()) {
				maxStrIndex = i; 
				maxStrLen = strArray[i].length();
			}
		}
		
		System.out.println(maxStrIndex);
	}

}
