package com.ssafy.day2.array;

public class ArrayTest2 {

	int[] nums;
	int[] reversed;
	int[][] nums2;
	int[][] rotated;
	int[][] rotated2;

	// TODO: 1 ~ 25의 값을 갖는 1차원 배열을 생성하고 출력하시오.
	public void init() {
	}

	// TODO: 위 배열의 요소들 중에서 짝수의 개수와 홀수의 합을 구해서 출력하시오.
	public void evenCountOddSum() {
	}

	// TODO: 위 배열의 값을 역순으로 reversed에 저장하고 출력하시오.
	public void reverseAndPrint() {
	}

	// TODO: nums배열의 요소들이 모든 짝수 이후에 홀수가 나오도록 수정하고 출력하시오.
	public void reorderEvenToOdd() {
	}

	// TODO: 역순된 배열을 5*5의 2차원 배열 nums2에 저장하고 출력하시오.
	public void convertReverseToTwoDimArray() {
	}

	// TODO: int[][]을 파라미터로 받아서 출력하는 메서드를 작성하시오.
	public void print2DimArray(int[][] arr) {
	}

	// TODO: 위 2차원 배열의 각 행의 합이 최대인 행은 몇 번째 행인가?
	public void getMaxSumRow() {
	}

	// TODO: 위 2차원 배열의 각 열의 합이 최대인 열은 몇 번째 열인가?
	public void getmaxSumCol() {
	}

	// TODO: 위 2차원 배열을 (0,0), (4,4)를 잊는 대각선을 중심으로 회전후 rotated에 저장하고 출력하시오.
	public void diagonalRotation() {
	}

	// TODO: 위 배열을 오른쪽으로 90도만큼 회전시킨 후 rotated2에 저장하고 출력하시오.
	public void turnRight() {
	}

	public static void main(String[] args) {
//		ArrayTest2_sol at = new ArrayTest2_sol();
//		at.init();
//		at.evenCountOddSum();
//		at.reverseAndPrint();
//		at.reorderEvenToOdd();
//		at.convertReverseToTwoDimArray();
//		at.getMaxSumRow();
//		at.getmaxSumCol();
//		at.diagonalRotation();
//		at.turnRight();
	}
}