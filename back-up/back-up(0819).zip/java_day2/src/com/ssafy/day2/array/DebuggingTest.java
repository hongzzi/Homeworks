package com.ssafy.day2.array;

public class DebuggingTest {
	
	static int [] nums = {1, 2, 3, 4, 5};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum = 0;
		
		for (int i=0; i<nums.length; i++) {
			nums[i] = (int)Math.pow(nums[i], 2);
			sum += nums[i];
		}
		
		System.out.println(sum);
		
	}

}
