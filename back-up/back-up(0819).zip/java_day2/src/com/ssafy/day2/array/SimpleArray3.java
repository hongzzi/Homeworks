package com.ssafy.day2.array;

import java.util.Arrays;

public class SimpleArray3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int 		num;
		int		[]	arr;
		int	[]	[]	arr2;
		
		
		// 권장형태 type [][] name ;
		arr = new int[] {1, 2, 3};
		arr2 = new int[][] {};

		int [][] multi1 = {{1, 2, 3}, {4, 5}, {6, 7, 8, 9, 10}};
		
		// 크기 
		System.out.println(multi1[2].length);
		System.out.println(multi1[0][2]);
		
		
		int [][] multi2 = new int[4][2];
		
		int sum = 0;
		for (int[] num1 : multi1) {
			for (int num2 : num1) {
				sum += num2;
			}
			System.out.println(Arrays.toString(num1));
		}
		System.out.println(Arrays.toString(multi1));
		System.out.println(sum);
	}

}
