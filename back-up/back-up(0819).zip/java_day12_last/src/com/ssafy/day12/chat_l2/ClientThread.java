package com.ssafy.day12.chat_l2;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;


public class ClientThread extends Thread{
	Socket socket;
	BufferedReader br;
	BufferedWriter bw;
	String name;
	
	public ClientThread(Socket socket) {
		this.socket = socket;
		try {			
			br = new BufferedReader(new InputStreamReader(socket.getInputStream(),"MS949"));
			bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Override
	public void run() {
		// 아이디 전송, 모든 사용자에게 누가 입장했습니다 알림. 메시지 모두에게 전송.
		try {
			name = br.readLine();
			broadcast("["+name+"]"+" 님이 입장했습니다.");
			while(true) {
				String line = br.readLine();
				if(line == null || line.equals("X")) {
					break;
				} else {
					broadcast(name + " : " + line);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			broadcast("["+name+"]"+" 님이 퇴장했습니다.");
			ChatServerBroadCast.clients.remove(this);
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(ChatServerBroadCast.clients.size());
		}
	}
	
	public void send(String msg) {
		try {
			bw.write(msg+"\n");
			bw.flush();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void broadcast(String msg) {
		for (ClientThread ct : ChatServerBroadCast.clients) {
			ct.send(msg);
		}
	}
}