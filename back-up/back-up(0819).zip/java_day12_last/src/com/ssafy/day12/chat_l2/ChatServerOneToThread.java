package com.ssafy.day12.chat_l2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ChatServerOneToThread {
	public static List<ClientThread> clients = new ArrayList<>();

	public static void main(String[] args) {
		try (ServerSocket ss = new ServerSocket(9090);) {
			System.out.println("server is ready...");
			while (true) {
				try {
					Socket socket = ss.accept();
					ClientThread ct = new ClientThread(socket);
					clients.add(ct);
					System.out.println("현재 사용자 수: " + clients.size());
					ct.start();
				} catch (Exception e) {
					// TODO: handle exception
				}

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
