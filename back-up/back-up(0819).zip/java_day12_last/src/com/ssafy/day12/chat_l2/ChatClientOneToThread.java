package com.ssafy.day12.chat_l2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ChatClientOneToThread {

	public static void main(String[] args) throws UnknownHostException, IOException {
		try {
			Socket socket = new Socket("localhost", 9090);
			
			new SendThread(socket).start();
			new ReceiveThread(socket).start();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
