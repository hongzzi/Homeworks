package com.ssafy.day12.chat_l2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class chatServer {
	public static void main(String[] args) throws IOException {
		try (ServerSocket ss = new ServerSocket(9090);) {
			System.out.println("server is ready....");
			while (true) {
				try (Socket forClient = ss.accept();
						Scanner scanner = new Scanner(System.in);
						BufferedReader br = new BufferedReader(new InputStreamReader(forClient.getInputStream()));
						BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(forClient.getOutputStream()));) {
					System.out.println("client info: " + forClient.getInetAddress());
					while (true) {
						String line = scanner.nextLine();
						if (line.trim().equals("X")) {
							break;
						}
						System.out.println(br.readLine());
						bw.write("서버>" + scanner.nextLine() + "\n");
						bw.flush();
					}
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
