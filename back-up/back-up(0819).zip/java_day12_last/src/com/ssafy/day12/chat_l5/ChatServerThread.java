package com.ssafy.day12.chat_l5;

import java.io.ObjectInputStream;

public class ChatServerThread extends Thread{
	
	ObjectInputStream ois;

	public ChatServerThread(ObjectInputStream ois) {
		this.ois = ois;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	
}
