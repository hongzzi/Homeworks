package com.ssafy.day12.chat_l5;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatClient {
	
	private JTextField text = null;
	private JTextArea ta = null;
	private JButton b1 = null;
	private JButton b2 = null;
	private JPanel panel = null;
	private Socket s;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private String ip;
	private int port;
	private String name;
	
	public ChatClient() {
		super();
	}

	public void createGUI() {
		JFrame frame = new JFrame("채팅");
		b1 = new JButton("전송");
		// 컨테이너에 컴포넌트 추가
		frame.add(b1,BorderLayout.EAST);
		
		// 메세지를 출력할 TestArea
		ta = new JTextArea();	//기본적으로 스크롤 불가
		ta.setEditable(false);
		JScrollPane sp = new JScrollPane(ta);
		frame.add(sp, BorderLayout.CENTER);
		// 복잡한 화면 구성 --> 추가적인 container 사용
		panel = new JPanel();
		JLabel label = new JLabel("");
		text = new JTextField("메세지를 입력하세요.");
		panel.add(text);
		frame.add(panel, BorderLayout.SOUTH);
		
		BorderLayout blayout = new BorderLayout();
		panel.setLayout(blayout);
		panel.add(label, BorderLayout.WEST);
		panel.add(text,BorderLayout.CENTER);
		
		
		// 기본으로는 닫아도 종료되지 않음
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 보이려면 크기를 지정해줘야한다.
		frame.setSize(500,300);
		
		// 기본은 안보임 
		frame.setVisible(true);
		
		
		eventHandling();
	}
	
	public void eventHandling() {
		text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER) {	//눌린 키가 엔터키라면....
					String data = text.getText();
					ta.append(data+"\n");
					text.setText("");
					ta.setCaretPosition(ta.getDocument().getLength());
				}
			}
		});
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//text의 내용을 읽어서 --> ta에 추가! 
				String data = text.getText();
				ta.append(data+"\n");
				text.setText("");
			}
		});
	}
	
	public void go(String ip, int port, String name) {
		
	}
	
	public static void main(String[] args) {
		ChatClient cl = new ChatClient();
		cl.createGUI();

	}

}
