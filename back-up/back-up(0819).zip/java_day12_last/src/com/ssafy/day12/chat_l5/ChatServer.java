package com.ssafy.day12.chat_l5;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.ssafy.day12.chat_l2.ClientThread;

public class ChatServer {

	private ArrayList<User> users;
	private int port;
	
	public void go() {
		try(ServerSocket ss = new ServerSocket(9090);) {
			System.out.println("server is ready...");
			while(true) {
				try {
//					Socket socket = ss.accept();
//					ClientThread ct = new ClientThread(socket);
//					User user =new User(socket);
//					users.add(user);
//					System.out.println("현재 사용자 수: "+users.size());
//					ct.start();
				} catch (Exception e) {
					// TODO: handle exception
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void brodcast(String msg) {
		
	}
	
	public void removeClient(ObjectInputStream ois) {
		
	}
	
	public static void main(String[] args) {
		
		
	}
}
