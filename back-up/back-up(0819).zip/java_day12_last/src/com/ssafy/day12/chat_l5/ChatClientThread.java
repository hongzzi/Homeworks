package com.ssafy.day12.chat_l5;

import java.io.ObjectInputStream;

public class ChatClientThread extends Thread {

	private ObjectInputStream ois;

	public ChatClientThread(ObjectInputStream ois) {
		super();
		this.ois = ois;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	
}
