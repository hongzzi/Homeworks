package com.ssafy.day12.chat_l1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ChatClientOneToOne {

	public static void main(String[] args) throws UnknownHostException, IOException {
		try(Socket socket = new Socket("localhost", 9090);
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				Scanner scanner = new Scanner(System.in);){
			while(true) {
				bw.write("client> "+scanner.nextLine()+"\n");
				bw.flush();
				System.out.println(br.readLine());
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
