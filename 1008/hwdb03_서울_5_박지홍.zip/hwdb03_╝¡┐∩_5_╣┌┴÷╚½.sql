select * from emp;
select * from dept;

-- 1 --
select ename, job, sal from emp natural join dept where loc = "CHICAGO"; 
-- 2 --
select empno, ename, job, deptno from emp where not empno in (select mgr from emp where mgr is not null);
-- 3 --
select ename, job, mgr from emp where mgr = (select mgr from emp where ename = "BLAKE");
-- 4 --
select * from emp order by HIREDATE asc limit 0,5;
-- 5 --
select ename, job, dname from emp natural join dept where mgr = (select empno from emp where ename = "JONES");