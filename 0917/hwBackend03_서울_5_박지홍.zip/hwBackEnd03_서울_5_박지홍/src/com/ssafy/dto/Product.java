package com.ssafy.dto;

public class Product {
	private String number, name, price, info;

	public Product(String number, String name, String price, String info) {
		this.number = number;
		this.name = name;
		this.price = price;
		this.info = info;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Override
	public String toString() {
		return "Product [number=" + number + ", name=" + name + ", price=" + price + ", info=" + info + "]";
	}
}
