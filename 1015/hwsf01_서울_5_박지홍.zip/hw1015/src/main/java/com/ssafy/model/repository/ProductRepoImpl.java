package com.ssafy.model.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{

	private static Logger logger = LoggerFactory.getLogger(ProductRepoImpl.class);
	
	public List<Product> selectAll() {
		// TODO Auto-generated method stub
		logger.trace("selectAll....");
		return null;
	}

	public Product select(String id) {
		// TODO Auto-generated method stub
		logger.trace("select....");
		return null;
	}

	public int insert(Product product) {
		// TODO Auto-generated method stub
		logger.trace("insert....");
		return 0;
	}

	public int update(Product product) {
		// TODO Auto-generated method stub
		logger.trace("update....");
		return 0;
	}

	public int delete(String id) {
		// TODO Auto-generated method stub
		logger.trace("delete....");
		return 0;
	}

}
