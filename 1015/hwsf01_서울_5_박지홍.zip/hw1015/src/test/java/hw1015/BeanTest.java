package hw1015;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.service.ProductService;

@RunWith(SpringRunner.class)
@ContextConfiguration("/productapplication.xml")
public class BeanTest {

	private static Logger logger = LoggerFactory.getLogger(BeanTest.class);
	
	@Autowired
	ProductService service;
	@Autowired
	ProductRepo repo;
	
	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void test() {
		assertThat(service, is(notNullValue()));
		assertThat(repo, is(service.getRepo()));
	}

}
