package com.ssafy.homework;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ProductClient extends Thread{

	Object pds;
	int size;
	
	ProductClient(Object pds, int size) {
		super();
		this.pds = pds;
		this.size = size;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try(Socket socket = new Socket("localhost", 9999);
				ObjectOutputStream oout = new ObjectOutputStream(socket.getOutputStream());
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
			
			oout.writeObject(pds);
			String readed = br.readLine();
			if (size == Integer.parseInt(readed)) {
				System.out.println("전송 확인");
			}
			System.out.println(size+"개의 데이터가 전송되었습니다.");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
