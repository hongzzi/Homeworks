package com.ssafy.homework;

public class ProductNotFoundException extends Exception{

	public ProductNotFoundException() {
		super(String.format("찾으시는 상품이 존재하지 않습니다."));
	}
}
