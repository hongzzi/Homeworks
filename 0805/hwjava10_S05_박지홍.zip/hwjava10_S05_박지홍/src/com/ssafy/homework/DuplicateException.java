package com.ssafy.homework;

public class DuplicateException extends Exception {

	public DuplicateException() {
		System.out.println("이미 등록된 상품입니다.");
	}
}
