package com.ssafy.homework;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;


public class ProductServer {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		try(ServerSocket ss = new ServerSocket(9999)) {
			System.out.println("Server is ready..");
			while (true) {
				try(Socket socket = ss.accept();
						ObjectInputStream oin = new ObjectInputStream(socket.getInputStream());
						BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));) {
					Object obj = oin.readObject();
					System.out.println(obj);
					if (obj != null) {
						Map<String, Product> list = (Map) obj;
						bw.write(list.size() + "");
					}
				}
			
			} 
		}
	}
}
