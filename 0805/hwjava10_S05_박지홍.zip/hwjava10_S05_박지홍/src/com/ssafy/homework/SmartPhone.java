package com.ssafy.homework;

public class SmartPhone extends Product {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String model;
	private String vender;
	
	public SmartPhone() {}

	public SmartPhone(String isbn, String name, int price, int stock, String model, String vender) {
		super(isbn, name, price, stock);
		this.model = model;
		this.vender = vender;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getVender() {
		return vender;
	}

	public void setVender(String vender) {
		this.vender = vender;
	}

	@Override
	public String toString() {
		return super.toString() + String.format("모델명 : %7s | 통신사 : %3s", this.vender, this.model);
	}
	
	
}
