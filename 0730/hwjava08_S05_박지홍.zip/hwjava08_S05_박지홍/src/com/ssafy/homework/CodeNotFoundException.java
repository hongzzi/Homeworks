package com.ssafy.homework;

public class CodeNotFoundException extends Exception {

	public CodeNotFoundException(String isbn) {
		super(String.format("%s는 찾을 수 없는 번호입니다.", isbn));
	}
}
