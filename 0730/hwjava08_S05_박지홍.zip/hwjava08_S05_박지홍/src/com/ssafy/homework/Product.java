package com.ssafy.homework;

import java.io.Serializable;

public class Product implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String isbn;
	private String name;
	private int price;
	private int stock;
	
	public Product() {}
	public Product(String isbn, String name, int price, int stock) {
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.stock = stock;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
	@Override
	public String toString() {
		return String.format(" - 상품번호: %10s | 상품명: %14s | 가격: %,10d | 재고: %,5d | ", this.isbn, this.name, this.price, this.stock);
	}
	
	
}
