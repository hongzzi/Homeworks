package com.ssafy.homework;

import java.util.Collection;

public interface IProductMgr {
	
	public boolean addItem(Product product) throws DuplicateException;
	public Collection<Product> getAllItems();
	public Product getItem(String isbn) throws CodeNotFoundException;
	public Collection<Product> searchItemsBytitle(String title);
	public Collection<TV> getAllTV();
	public Collection<Refrigerator> getAllRef();
	public Collection<Refrigerator> searchRefByLiter() throws ProductNotFoundException;
	public Collection<TV> searchTVByInch() throws ProductNotFoundException;
	public boolean updateItem(String isbn, int price);
	public boolean removeItem(String isbn);
	public long getTotalPrice();
	public Collection<Product> searchDetail(String title, int price);
	public void open();
	public void close();
	
}
