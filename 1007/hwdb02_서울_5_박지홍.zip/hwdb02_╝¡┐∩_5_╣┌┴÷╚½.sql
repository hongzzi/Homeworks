create database workshop2;

use workshop2;
drop table product;

create table product(
	product_no char(8),
    product_name varchar(100) not null,
    price int(10) not null,
    maker varchar(10) not null
);

select * from product;

insert into product values("ntb-2000","삼성PenS","2800000","samsung");
insert into product values("tv-10011","스마트TV","5000000","lg");
insert into product values("ntb-8521","삼성시리즈9","1600000","samsung");
insert into product values("ref-4002","양문형냉장고","6000000","dimche");
insert into product values("tv-35689","QLED TV","34000000","lg");

select product_no, product_name, price*0.85 as "세일 가격" from product; 

update product set price = price *0.8 where product_name like "%TV%";
select * from product;

select count(product_name) as "총 상품 갯수", sum(price) as "총 금액" from product;