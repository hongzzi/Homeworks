package com.ssafy.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.PageBean;

public class BoardDaoImpl implements BoardDao {
	
	private final String namespace = "com.ssafy.mapper.BoardMapper.";
	
	private static BoardDaoImpl dao = new BoardDaoImpl();
	public static BoardDaoImpl getDao() {
		return dao;
	}
	public BoardDaoImpl() {
	}
	
	@Override
	public int getBoardNo(SqlSession session)  {
		String stmt = namespace+"getBoardNo";
		return session.selectOne(stmt);
	}

	@Override
	public int insertBoard(SqlSession session, Board board)  {
		String stmt = namespace+"insertBoard";
		return session.insert(stmt, board);
	}

	@Override
	public Board search(SqlSession session, String no)  {
		String stmt = namespace+"search";
		return session.selectOne(stmt, Integer.parseInt(no));
	}

	@Override
	public Map<String, Object> searchAll(SqlSession session, PageBean bean)  {
		String stmt = namespace+"searchAll";
		List<Board> list = session.selectList(stmt, bean);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("list", list);
		if (list != null && list.size()>0) {
			map.put("totalNumber", list.get(0).getTotal());
		}
		return map;
	}

//	@Override
//	public int count(SqlSession session, PageBean bean)  {
//		String stmt = namespace+"count";
//		return session.selectOne(stmt);
//	}

	@Override
	public int updateBoard(SqlSession session, Board board)  {
		String stmt = namespace+"updateBoard";
		return session.update(stmt, board);
	}

	@Override
	public int deleteBoard(SqlSession session, String no)  {
		String stmt = namespace+"deleteBoard";
		return session.delete(stmt, Integer.parseInt(no));
	}

}
