package com.ssafy.model.dao;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import com.ssafy.model.dto.Member;

public class MemberDAOImp implements MemberDAO {
	
	private final String namespace = "com.ssafy.mapper.MemberMapper.";
	private static MemberDAO dao = new MemberDAOImp();
	public static MemberDAO getDao() {
		return dao;
	}
	public MemberDAOImp() { }
	
	
	@Override
	public Member search(SqlSession session, String id) {
		String stmt = namespace + "search";
		return session.selectOne(stmt, id);
	}

	@Override
	public List<Member> searchAll(SqlSession session) {
		String stmt = namespace + "searchAll";
		return session.selectList(stmt);
	}

	@Override
	public int add(SqlSession session, Member member) {
		String stmt = namespace + "add";
		return session.insert(stmt, member);
	}

	@Override
	public int update(SqlSession session, Member member) {
		String stmt = namespace + "update";
		return session.update(stmt, member);
	}

	@Override
	public int remove(SqlSession session, String id) {
		String stmt = namespace + "remove";
		return session.delete(stmt, id);
	}
	
}
