package com.ssafy.model.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ssafy.model.dao.BoardDaoImpl;
import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.PageBean;
import com.ssafy.util.MyBatisUtil;

public class BoardServiceImpl implements BoardService {
	
	
	private static Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	private static BoardServiceImpl service = new BoardServiceImpl();
	public static BoardServiceImpl getService() {
		return service;
	}
	
	private BoardDaoImpl dao = BoardDaoImpl.getDao();
	private MyBatisUtil util = MyBatisUtil.getUtil();
	
	public BoardServiceImpl() {
	}

	@Override
	public int insertBoard(Board board) {
		SqlSession session = null;
		int result = 0;
		try {
			session = util.getSession();
			result = dao.insertBoard(session, board);
			session.commit();
		} catch (RuntimeException e) {
			logger.error("추가 실패", e);
		} finally {
			session.close();
		}
		return result;
	}

	@Override
	public int updateBoard(Board board) {
		SqlSession session = null;
		int result = 0;
		try {
			session = util.getSession();
			result = dao.updateBoard(session, board);
			session.commit();
		} catch (RuntimeException e) {
			logger.error("수정 실패", e);
		} finally {
			session.close();
		}
		return result;
	}

	@Override
	public int deleteBoard(String no) {
		SqlSession session = null;
		int result = 0;
		try {
			session = util.getSession();
			result = dao.deleteBoard(session, no);
			session.commit();
		} catch (RuntimeException e) {
			logger.error("삭제 실패", e);
		} finally {
			session.close();
		}
		return result;
	}

	@Override
	public Board search(String no) {
		Board board = null;
		SqlSession session = null;
		try {
			session = util.getSession();
			board = dao.search(session, no);
		}catch (RuntimeException e) {
			logger.error("게시물 검색 중 오류 발생", e);
		} finally {
			session.close();
		}
		
		return board;
	}

	@Override
	public Map<String, Object> searchAll(PageBean bean) {
		Map<String, Object> map = new HashMap<String, Object>();
		SqlSession session = null;
		try {
			session = util.getSession();
			map = dao.searchAll(session, bean);
		}catch (RuntimeException e) {
			logger.error("게시물 검색 중 오류 발생", e);
		} finally {
			session.close();
		}
		
		return map;
	}
}
