package com.ssafy.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ssafy.model.dao.MemberDAO;
import com.ssafy.model.dao.MemberDAOImp;
import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.MemberException;
import com.ssafy.util.MyBatisUtil;

public class MemberServiceImp implements MemberService {

	private static Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	private static MemberServiceImp service = new MemberServiceImp();

	public static MemberServiceImp getService() {
		return service;
	}

	public MemberServiceImp() {
	}

	private MemberDAO dao = new MemberDAOImp();
	private MyBatisUtil util = MyBatisUtil.getUtil();

	@Override
	public Member search(String id) {
		SqlSession session = null;
		Member member = null;
		try {
			session = util.getSession();
			member = dao.search(session, id);

			if (member == null) {
				throw new MemberException("등록되지 않은 아이디입니다.");
			}
		} catch (RuntimeException e) {
			logger.error("검색 실패", e);
		} finally {
			session.close();
		}
		return member;
	}

	@Override
	public List<Member> searchAll() {
		SqlSession session = null;
		List<Member> list = null;
		try {
			session = util.getSession();
			list = dao.searchAll(session);
		} catch (RuntimeException e) {
			logger.error("검색 실패", e);
		} finally {
			session.close();
		}
		return list;
	}

	@Override
	public boolean login(String id, String pw) {
		SqlSession session = null;
		boolean flag = false;
		try {
			session = util.getSession();
			Member member = dao.search(session, id);
			if (member == null) {
				throw new MemberException("등록되지 않은 회원 아이디입니다.");
			} else {
				if (pw.equals(member.getPassword())) {
					flag = true;
				} else {
					throw new MemberException("비밀 번호 오류");
				}
			}
		} catch (RuntimeException e) {
			logger.error("추가 실패", e);
		} finally {
			session.close();
		}
		if (flag) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean checkID(String id) {
		SqlSession session = null;
		try {
			session = util.getSession();
			Member member = dao.search(session, id);
			if (member == null) {
				return false;
			}
		} catch (RuntimeException e) {
			logger.error("추가 실패", e);
		} finally {
			session.close();
		}
		return true;
	}

	@Override
	public void update(Member member) {
		SqlSession session = null;
		try {
			session = util.getSession();
			Member find = dao.search(session, member.getId());
			if (find == null) {
				throw new MemberException("수정할 회원 정보가 없습니다.");
			} else {
				dao.update(session, member);
			}
		} catch (RuntimeException e) {
			logger.error("수정 실패", e);
		} finally {
			session.close();
		}
	}

	@Override
	public void remove(String id) {
		SqlSession session = null;
		try {
			session = util.getSession();
			Member find = dao.search(session, id);
			if (find == null) {
				throw new MemberException("탈퇴할 회원 정보가 없습니다.");
			} else {
				dao.remove(session, id);
			}
		} catch (RuntimeException e) {
			logger.error("삭제 실패", e);
		} finally {
			session.close();
		}
	}

	@Override
	public void add(Member member) {
		SqlSession session = null;
		try {
			session = util.getSession();
			Member find = dao.search(session, member.getId());
			if (find != null) {
				throw new MemberException("이미 등록된 아이디입니다.");
			} else {
				dao.add(session, member);
			}
		} catch (RuntimeException e) {
			logger.error("추가 실패", e);
		} finally {
			session.close();
		}
	}
}
