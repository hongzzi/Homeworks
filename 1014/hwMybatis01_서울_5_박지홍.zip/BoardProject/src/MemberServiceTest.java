import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ssafy.model.dto.Member;
import com.ssafy.model.service.MemberServiceImp;
import com.ssafy.util.MyBatisUtil;

public class MemberServiceTest {

	MemberServiceImp service;
	SqlSession session;
	@Before
	public void setUp() throws Exception {
		service = MemberServiceImp.getService();
		
		session = MyBatisUtil.getUtil().getSession();
	}

	@After
	public void tearDown() throws Exception {
		session.rollback();
	}

	@Test
	public void testSearch() {
		Member member = service.search("hong");
		assertThat(member.getName(), is("qkrwlghd"));
	}

	@Test
	public void testSearchAll() {
		List<Member> list = service.searchAll();
		assertThat(list.size(), is(3));
	}
	
	@Test
	public void testAdd() {
		Member member = new Member("h","1234","홍지홍","hongzzi.dev@gmail.com","01020537168","경기도");
		service.add(member);
		
		Member member2 = service.search("h");
		assertThat(member2.getName(), is("홍지홍"));
	}
	
	@Test
	public void testUpdate() {
		Member member = new Member("ssafy","1234","홍지홍","hongzzi.dev@gmail.com","01020537168","경기도");
		service.update(member);
		
		Member member2 = service.search("ssafy");
		assertThat(member.getName(), is("홍지홍"));
	}
	
	@Test
	public void testRemove() {
		service.remove("hong");
		Member member2 = service.search("hong");
		assertNull(member2);
	}
	

}
