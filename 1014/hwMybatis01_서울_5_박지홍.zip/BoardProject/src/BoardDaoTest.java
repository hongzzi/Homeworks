import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ssafy.model.dao.BoardDao;
import com.ssafy.model.dao.BoardDaoImpl;
import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.PageBean;
import com.ssafy.util.MyBatisUtil;

public class BoardDaoTest {

	BoardDaoImpl dao;
	SqlSession session;
	
	@Before
	public void setUp() throws Exception {
		dao = BoardDaoImpl.getDao();
		session = MyBatisUtil.getUtil().getSession();
	}

	@After
	public void tearDown() throws Exception {
		session.rollback();
	}

	@Test
	public void testSearch() {
		Board board = dao.search(session, "5");
		assertThat(board.getId(), is("ssafy"));
	}
	
	@Test
	public void testGetBoardNo() {
		int result = dao.getBoardNo(session);
		assertThat(result, is(7));
	}
	
	@Test
	public void testInsertBoard() {
		Board board = new Board("ssafy", "자바의밤", "마이바티스하는중");
		int i = dao.insertBoard(session, board);
		assertThat(i, is(1));
	}
	
	@Test
	public void testSelectAll() {
		PageBean bean = new PageBean("title","삼성","");
		Map<String, Object> map = dao.searchAll(session, bean);
		assertNotNull(map);
	}
	
	@Test
	public void testUpdate() {
		Board board = new Board(6,"ssafy", "자바의밤", "마이바티스하는중");
		int result = dao.updateBoard(session, board);
		assertThat(result, is(1));
		
		Board board2 = dao.search(session, "6");
		assertThat(board2.getTitle(), is("자바의밤"));
	}

	@Test
	public void testDelete() {
		int result = dao.deleteBoard(session, "6");
		assertThat(result, is(1));
		
		Board board2 = dao.search(session, "6");
		assertNull(board2);
	}

	
}
