import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.ssafy.model.dao.MemberDAO;
import com.ssafy.model.dao.MemberDAOImp;
import com.ssafy.model.dto.Member;
import com.ssafy.util.MyBatisUtil;

public class MemberDaoTest {

	MemberDAO dao;
	SqlSession session;
	
	@Before
	public void setUp() throws Exception {
		dao = MemberDAOImp.getDao();
		session = MyBatisUtil.getUtil().getSession();
	}

	@After
	public void tearDown() throws Exception {
		session.rollback();
	}

	@Test
	public void testSearch() {
		Member member = dao.search(session, "hong");
		assertThat(member.getName(), is("qkrwlghd"));
	}

	@Test
	public void testSearchAll() {
		List<Member> list = dao.searchAll(session);
		assertThat(list.size(), is(3));
	}
	
	@Test
	public void testAdd() {
		Member member = new Member("hongzzihong","1234","홍지홍","hongzzi.dev@gmail.com","01020537168","경기도");
		int result = dao.add(session, member);
		assertThat(result, is(1));
	}
	
	@Test
	public void testUpdate() {
		Member member = new Member("ssafy","1234","홍지홍","hongzzi.dev@gmail.com","01020537168","경기도");
		int result = dao.update(session, member);
		assertThat(result, is(1));
		
		Member member2 = dao.search(session, "ssafy");
		assertThat(member.getName(), is("홍지홍"));
	}
	
	@Test
	public void testRemove() {
		int result = dao.remove(session, "ssafy");
		assertThat(result, is(1));
	}
	
}
