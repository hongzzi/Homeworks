import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.PageBean;
import com.ssafy.model.service.BoardServiceImpl;
import com.ssafy.util.MyBatisUtil;

public class BoardServiceTest {

	BoardServiceImpl service;
	SqlSession session;
	
	@Before
	public void setUp() throws Exception {
		service = BoardServiceImpl.getService();
		session = MyBatisUtil.getUtil().getSession();
	}

	@After
	public void tearDown() throws Exception {
		session.rollback();
	}

	
	@Test
	public void testSearch() {
		Board board = service.search("5");
		assertThat(board.getId(), is("ssafy"));
	}

	@Test
	public void testInsertBoard() {
		Board board = new Board("ssafy", "자바의밤", "마이바티스하는중");
		int i = service.insertBoard(board);
		assertThat(i, is(1));
	}
	
	@Test
	public void testSelectAll() {
		PageBean bean = new PageBean("title","삼성","");
		Map<String, Object> map = service.searchAll(bean);
		assertNotNull(map);
	}
	
	@Test
	public void testUpdate() {
		Board board = new Board(5,"ssafy", "자바의밤", "마이바티스하는 중");
		int result = service.updateBoard(board);
		
		Board board2 = service.search("5");
		assertThat(board2.getTitle(), is("자바의밤"));
	}

	@Test
	public void testDelete() {
		int result = service.deleteBoard("5");
		assertThat(result, is(1));
		
		Board board2 = service.search("5");
		assertNull(board2);
	}

}
