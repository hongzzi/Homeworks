package com.ssafy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService pService;
	
	@GetMapping("/product/regist")
	public String registForm() {
		return "product/regist";
	}
	
	@PostMapping("/product/regist")
	public String regist(Product product, Model model) {
		int a = pService.insert(product);
		return "product/list";
	}
	
	@GetMapping("/product/list")
	public String getList() {
		return "product/list";
	}
	
}
