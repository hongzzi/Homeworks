package com.ssafy.homework;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		Map<String, String[]> map = request.getParameterMap();
		
		String isbn = request.getParameter("isbn1");
		isbn += "-" + request.getParameter("isbn2");
		isbn += "-" + request.getParameter("isbn3");
	
		System.out.println(isbn);
		
		for (String key : map.keySet()) {
			System.out.println(key+" "+map.get(key)[0]);
		}
		
		PrintWriter pw = response.getWriter();
		
		pw.println("<html><head></head><body>");
		pw.print("<h1>도서정보</h1>");
		pw.println("<table border='1px'> <tbody><tr><td colspan=2 width='200px'>도서정보</td></tr>"
				+ "<tr><td>도서명</td><td>"+map.get("title")[0]+"</td></tr>"
				+ "<tr><td>도서번호</td><td>"+isbn+"</td></tr>"
				+ "<tr><td>도서분류</td><td>"+map.get("booktype")[0]+"</td></tr>"
				+ "<tr><td>도서국가</td><td>"+map.get("frombook")[0]+"</td></tr>"
				+ "<tr><td>출판일</td><td>"+map.get("publishDate")[0]+"</td></tr>"
				+ "<tr><td>출판사</td><td>"+map.get("publisher")[0]+"</td></tr>"
				+ "<tr><td>저자</td><td>"+map.get("writer")[0]+"</td></tr>"
				+ "<tr><td>도서가격</td><td>"+map.get("price")[0]+"</td></tr>"
				+ "<tr><td>도서설명</td><td>"+map.get("desc")[0]+"</td></tr>"
				+ "</table>");
		pw.println("<a href='Result.html'>도서등록</a>");
		
		pw.flush();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		if(id.equals("ssafy") && pw.equals("1111")) {
			RequestDispatcher rd = request.getRequestDispatcher("./Result.html");
			rd.forward(request, response);
		} else {
			response.sendRedirect("./Login.html");
		}
	}

}
