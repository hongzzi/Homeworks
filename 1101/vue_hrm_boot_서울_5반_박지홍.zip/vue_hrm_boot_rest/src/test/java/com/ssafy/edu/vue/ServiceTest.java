package com.ssafy.edu.vue;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.service.EmployeeService;

@SpringBootTest
@Transactional
class ServiceTest {

	@Autowired
	EmployeeService service;

	@Test
	void test1() {
		List<EmployeeDto> list = service.findAllEmployees();
		assertEquals(list.size(), 25);
	}

	@Test
	void test2() {
		int result = service.getEmployeesTotal();
		assertEquals(result, 25);
	}

	@Test
	void test3() {
		List<EmployeeDto> list = service.findLikeEmployees("박");
		assertNotEquals(list.size(), 0);
	}

	@Test
	void test4() {
		List<DepartmentDto> list = service.findAllDepartments();
		assertEquals(list.size(), 12);
	}

	@Test
	void test5() {
		List<EmployeeDto> list = service.findAllTitles();
		assertEquals(list.size(), 8);
	}

	@Test
	void test6() {
		EmployeeDto emp = service.findEmployeeById(1);
		assertEquals(emp.getName(), "박구곤");
	}

}
