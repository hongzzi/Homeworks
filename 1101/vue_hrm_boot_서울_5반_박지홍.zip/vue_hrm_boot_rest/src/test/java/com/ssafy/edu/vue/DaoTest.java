package com.ssafy.edu.vue;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dao.EmployeeDAO;
import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.DepartmentEmpDto;
import com.ssafy.edu.vue.dto.EmployeeDto;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Transactional
@Slf4j
class DaoTest {

	@Autowired
	EmployeeDAO dao;

//	@Test
//	void test1() {
//		List<EmployeeDto> list = dao.findAllEmployees();
//		assertEquals(list.size(), 25);
//	}
//	@Test
//	void test2() {
//		int result = dao.getEmployeesTotal();
//		assertEquals(result, 25);
//	}
//	@Test
//	void test3() {
//		List<EmployeeDto> list = dao.findLikeEmployees("박");
//		assertNotEquals(list.size(), 0);
//	}
//	@Test
//	void test4() {
//		List<DepartmentDto> list = dao.findAllDepartments();
//		assertEquals(list.size(), 12);
//	}
//	@Test
//	void test5() {
//		List<EmployeeDto> list = dao.findAllTitles();
//		assertEquals(list.size(), 8);
//	}
//	@Test
//	void test6() {
//		EmployeeDto emp = dao.findEmployeeById(1);
//		assertEquals(emp.getName(), "박구곤");
//	}
////	@Test
////	void insertTest() {
////		EmployeeDto emp = new EmployeeDto(null, "홍길동", "hong", "2019-01-01", null, "사장", 110, 100.0, 10.0);
////		boolean tf = dao.addEmployee(emp);
////		assertTrue(tf);
////		log.trace("직원 번호 : {}", emp.getId());
////	}
//	@Test
//	void updateTest() {
//		EmployeeDto emp = new EmployeeDto(1, "홍길동", "sky98", "2019-01-01", null, "사장", 110, 100.0, 10.0);
//		boolean tf = dao.updateEmployee(emp);
//		assertTrue(tf);
//		log.trace("직원 번호 : {}", emp.getId());
//	}
//	@Test
//	void deleteTest() {
//		boolean tf = dao.deleteEmployee(1);
//		assertTrue(tf);
//		log.trace("직원 번호 : {}", 1);
//	}
//	
//	
	@Test
	void findEmployeesByManagerIdTest() {
		List<EmployeeDto> list = dao.findEmployeesByManagerId(10);
		assertEquals(list.size(), 2);
	}
	@Test
	void findDepartmentsBydeptidTest() {
		List<EmployeeDto> list = dao.findDepartmentsBydeptid(111);
		assertEquals(list.size(), 3);
	}
	@Test
	void findDepartmentsBynameTest() {
		List<EmployeeDto> list = dao.findDepartmentsByname("영업부");
		assertEquals(list.size(), 7);
	}
	@Test
	void findAllDeptEmpsTest() {
		List<DepartmentEmpDto> list = dao.findAllDeptEmps();
		assertEquals(list.size(), 26);
	}
	
}
