package com.ssafy.edu.vue.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.DepartmentEmpDto;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.EmployeeService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/rest")
@Slf4j
public class RestHrmController {

	@Autowired
	EmployeeService service;

	@PostMapping("/addEmployee")
	@ApiOperation(value="")
	public ResponseEntity<Object> addEmployee(@RequestBody EmployeeDto emp) {
		log.trace("addEmployee : {}", emp);
		try {
			boolean result = service.addEmployee(emp);
			NumberResult nr = null;
			if(result) {
				nr = new NumberResult("addEmployee", emp.getId(), "SUCCESS");
			} else {
				nr = new NumberResult("addEmployee", -1, "FAIL");
			}
			return new ResponseEntity<Object>(nr, HttpStatus.OK);
		} catch (RuntimeException e) {
			log.error("addEmployee",e);
			throw e;
		}
	}
	
	@PutMapping("/updateEmployee")
	@ApiOperation(value="")
	public ResponseEntity<Object> updateEmployee(@RequestBody EmployeeDto emp) {
		log.trace("updateEmployee : {}", emp);
		try {
			boolean result = service.updateEmployee(emp);
			BoolResult br = null;
			if(result) {
				br = new BoolResult("deleteEmployee", true, "SUCCESS");
			} else {
				br = new BoolResult("deleteEmployee", false, "FAIL");
			}
			return new ResponseEntity<Object>(br, HttpStatus.OK);
		} catch (RuntimeException e) {
			log.error("updateEmployee",e);
			throw e;
		}
	}
	
	@DeleteMapping("/deleteEmployee/{id}")
	@ApiOperation(value="")
	public ResponseEntity<Object> deleteEmployee(@PathVariable int id) {
		log.trace("deleteEmployee : {}", id);
		try {
			boolean result = service.deleteEmployee(id);
			BoolResult br = null;
			if(result) {
				br = new BoolResult("deleteEmployee", true, "SUCCESS");
			} else {
				br = new BoolResult("deleteEmployee", false, "FAIL");
			}
			return new ResponseEntity<Object>(br, HttpStatus.OK);
		} catch (RuntimeException e) {
			log.error("deleteEmployee",e);
			throw e;
		}
	}
	
	
	@GetMapping("/findAllEmployees")
	@ApiOperation(value = "전체 사원의 정보를 반환한다", response = List.class)
	public ResponseEntity<Object> findAllEmployees() {
		log.trace("findAllEmployees");
		try { 
			List<EmployeeDto> emps = service.findAllEmployees();
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findAllEmployees", e);;
			throw e;
		}
	}
	
	@GetMapping("/findEmployeeById/{id}")
	@ApiOperation(value = "아이디로 사원의 정보를 반환한다")
	public ResponseEntity<Object> findEmployeeById(@PathVariable int id) {
		log.trace("findEmployeeById");
		try { 
			EmployeeDto emp = service.findEmployeeById(id);
			return new ResponseEntity<Object>(emp, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findEmployeeById", e);;
			throw e;
		}
	}
	
	@GetMapping("/getEmployeesTotal")
	@ApiOperation(value = "전체 직원 수")
	public ResponseEntity<Object> getEmployeesTotal() {
		log.trace("getEmployeesTotal");
		try { 
			int result = service.getEmployeesTotal();
			return new ResponseEntity<Object>(result, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findEmployeeById", e);;
			throw e;
		}
	}
	
	@GetMapping("/findLikeEmployees/{name}")
	@ApiOperation(value = "비슷한 이름의 직원을 출력한다")
	public ResponseEntity<Object> findLikeEmployees(@PathVariable String name) {
		log.trace("findLikeEmployees");
		try { 
			List<EmployeeDto> emps = service.findLikeEmployees(name);
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findLikeEmployees", e);;
			throw e;
		}
	}
	
	@GetMapping("/findAllDepartments")
	@ApiOperation(value = "전체 부서 정보를 반환한다", response = List.class)
	public ResponseEntity<Object> findAllDepartments() {
		log.trace("findAllDepartments");
		try { 
			List<DepartmentDto> emps = service.findAllDepartments();
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findAllDepartments", e);;
			throw e;
		}
	}
	@GetMapping("/findAllTitles")
	@ApiOperation(value = "전체 직무 정보를 반환한다", response = List.class)
	public ResponseEntity<Object> findAllTitles() {
		log.trace("findAllTitles");
		try { 
			List<EmployeeDto> emps = service.findAllTitles();
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findAllTitles", e);;
			throw e;
		}
	}
	
	@GetMapping("/findEmployeesByManagerId/{managerId}")
	@ApiOperation(value = "managerId에 속한 직원들의 목록을 반환한다", response = List.class)
	public ResponseEntity<Object> findEmployeesByManagerId(@PathVariable int managerId) {
		log.trace("findEmployeesByManagerId");
		try { 
			List<EmployeeDto> emps = service.findEmployeesByManagerId(managerId);
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findEmployeesByManagerId", e);;
			throw e;
		}
	}
	
	@GetMapping("/findDepartmentsBydeptid/{deptId}")
	@ApiOperation(value = "deptId에 속한 직원들의 목록을 반환한다", response = List.class)
	public ResponseEntity<Object> findDepartmentsBydeptid(@PathVariable int deptId) {
		log.trace("findDepartmentsBydeptid");
		try { 
			List<EmployeeDto> emps = service.findDepartmentsBydeptid(deptId);
			return new ResponseEntity<Object> (emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findDepartmentsBydeptid", e);;
			throw e;
		}
	}
	
	@GetMapping("/findDepartmentsByname/{name}")
	@ApiOperation(value = "deptId에 속한 직원들의 목록을 반환한다", response = List.class)
	public ResponseEntity<Object> findDepartmentsByname(@PathVariable String name) {
		log.trace("findDepartmentsByname");
		try { 
			List<EmployeeDto> emps = service.findDepartmentsByname(name);
			return new ResponseEntity<Object>(emps, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findDepartmentsByname", e);;
			throw e;
		}
	}

	
	@GetMapping("/findAllDepCounts")
	@ApiOperation(value = "모든 부서에 대해 부서별 코드, 이름과 함께 직원수를 DepCountDto의 목록 형태로 반환한다", response = List.class)
	public ResponseEntity<Object> findAllDepCounts() {
		log.trace("findDepartmentsByname");
		try { 
			List<DepCountDto> dc = service.findAllDepCounts();
			return new ResponseEntity<Object>(dc, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findAllDepCounts", e);;
			throw e;
		}
	}
	
	@GetMapping("/findAllDeptEmps")
	@ApiOperation(value = "직원의 정보와 함께 부서 정보를 DepartmentEmpDto의 목록 형태로 반환하시오", response = List.class)
	public ResponseEntity<Object> findAllDeptEmps() {
		log.trace("findAllDeptEmps");
		try { 
			List<DepartmentEmpDto> de = service.findAllDeptEmps();
			return new ResponseEntity<Object>(de, HttpStatus.OK);
		}catch( RuntimeException e){
			log.error("findAllDeptEmps", e);;
			throw e;
		}
	}
	
}
