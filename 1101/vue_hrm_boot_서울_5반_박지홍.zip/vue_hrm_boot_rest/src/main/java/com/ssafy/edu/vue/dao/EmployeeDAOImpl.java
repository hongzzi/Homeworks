package com.ssafy.edu.vue.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.DepartmentEmpDto;
import com.ssafy.edu.vue.dto.EmployeeDto;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	private final String namespace = "com.ssafy.edu.vue.dao.HrmMapper.";
	@Autowired
	SqlSession session;
	
	@Override
	public List<EmployeeDto> findAllEmployees() {
		return session.selectList(namespace+"findAllEmployees");
	}

	@Override
	public int getEmployeesTotal() {
		return session.selectOne(namespace+"getEmployeesTotal");
	}

	@Override
	public List<EmployeeDto> findLikeEmployees(String name) {
		return session.selectList(namespace+"findLikeEmployees",name);
	}

	@Override
	public List<DepartmentDto> findAllDepartments() {
		return session.selectList(namespace+"findAllDepartments");
	}

	@Override
	public List<EmployeeDto> findAllTitles() {
		return session.selectList(namespace+"findAllTitles");
	}

	@Override
	public EmployeeDto findEmployeeById(int id) {
		return session.selectOne(namespace+"findEmployeeById", id);
	}

	@Override
	public boolean addEmployee(EmployeeDto emp) {
		return session.insert(namespace+"addEmployee", emp) > 0;
	}

	@Override
	public boolean updateEmployee(EmployeeDto emp) {
		return session.update(namespace+"updateEmployee", emp) > 0;
	}

	@Override
	public boolean deleteEmployee(int id) {
		return session.delete(namespace+"deleteEmployee", id) > 0;
	}

	@Override
	public List<EmployeeDto> findEmployeesByManagerId(int managerId) {
		return session.selectList(namespace+"findEmployeesByManagerId", managerId);
	}

	@Override
	public List<EmployeeDto> findDepartmentsBydeptid(int dept_id) {
		return session.selectList(namespace+"findDepartmentsBydeptid", dept_id);
	}

	@Override
	public List<EmployeeDto> findDepartmentsByname(String name) {
		return session.selectList(namespace+"findDepartmentsByname", name);
	}

	@Override
	public List<DepCountDto> findAllDepCounts() {
		return session.selectList(namespace+"findAllDepCounts");
	}

	@Override
	public List<DepartmentEmpDto> findAllDeptEmps() {
		return session.selectList(namespace+"findAllDeptEmps");
	}

}
