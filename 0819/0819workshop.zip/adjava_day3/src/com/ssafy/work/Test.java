package com.ssafy.work;

import java.util.ArrayList;
import java.util.List;

public class Test {

	static List<Book> books = new ArrayList<>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookDAO dao = BookDAO.getDao();
//		dao.insertBook(new Book("a1101","JAVA 기본","자앤 기술연구소","자앤 출판사",23000,"기본"));
//		dao.insertBook(new Book("a1102","JAVA 중급","자앤 기술연구소","자앤 출판사",25000,"중급"));
//		dao.insertBook(new Book("a1103","JAVA 실전","자앤 기술연구소","자앤 출판사",30000,"실전"));
//		
//		books = dao.listBooks();
//		
//		for (Book book : books) {
//			System.out.println(book);
//		}
//		
//		dao.findBook("a1101");
//		
//		dao.insertBook(new Book("a1104","JAVA 심화","자앤 기술연구소","자앤 출판사",28000, "심화"));
//		
		dao.updateBook(new Book("a1101","JAVA 기본","자앤 기술연구소","자앤 출판사",20000,"기본"));
		dao.deleteBook("a1103");
		books = dao.listBooks();
		
		for (Book book : books) {
			System.out.println(book);
		}
		
		
		
	}

}
