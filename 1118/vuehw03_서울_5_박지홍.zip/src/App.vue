
<template>
  <div id="app">
    <router-link to="/">메인으로 돌아가기</router-link> | 
    <router-link to="/searchByName">이름으로 검색하기</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
import router from "./assets/router"

export default {
  name: 'app',
  router,
  components: {
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
