<template>
  <div id="search-box">
    <h1>HRM system</h1>
    <hr />
    <div>
      <h2>사원 상세보기</h2>
    </div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-if="emp.id">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary}}</td>
      </tr>
    </table>
    <a href="/">목록으로돌아가기</a>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
import router from "../assets/router";

export default {
  props: ["id"],
  router,
  data() {
    return {
      emp: {}
    };
  },
  mounted() {
    ajax
      .get("/findEmployeeById/"+this.id)
      .then(res => {
        this.emp = res.data;
      })
      .catch(error => {
        alert(error);
      });
  }
};
</script>

<style>

</style>