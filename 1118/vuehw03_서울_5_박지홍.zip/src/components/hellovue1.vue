<template>
  <div id="search-box">
    <h1>HRM system</h1>
    <hr />
    <div>

    </div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-for="emp in emps" :key="emp.id" @click="detail(emp.id)">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary}}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
import router from "../assets/router";

export default {
  router,
  data() {
    return {
      emps: []
    };
  },
  mounted() {
    ajax
      .get("/findAllEmployees")
      .then(res => {
        this.emps = res.data;
      })
      .catch(error => {
        alert(error);
      });
  },
  methods: {
    detail(id) {
        router.push({
            path:'/detail/'+id
        })
    }
  }
};
</script>

<style>
</style>