import VueRouter from "vue-router"
import Hello1 from "../components/hellovue1.vue"
import Hello2 from "../components/hellovue2.vue"
import Hello3 from "../components/hellovue3.vue"

const router = new VueRouter({
    routes: [
        {
            name: "main",
            path: "/",
            component: Hello1
        },
        {
            name: "detail",
            path: "/detail/:id",
            props: true,
            component: Hello2
        },
        {
            name: "searchByName",
            path: "/searchByName",
            component: Hello3
        }
    ]
})

export default router