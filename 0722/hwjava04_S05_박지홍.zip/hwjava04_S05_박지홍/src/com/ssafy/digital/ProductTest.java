package com.ssafy.digital;


public class ProductTest {
//	productNumber, String title, int price, int stock, int inch, String displayType
	Television[] tvs = { new Television("1-5254", "삼성 스마트 티비", 6524000, 20, 60, "UHD"),
			new Television("1-1818", "엘지 울트라 에이치디 ", 1584000, 10, 42, "LCD") };
	Refrigerator[] refs = { new Refrigerator("828228", "양문형 냉장고", 5524000, 1),
			new Refrigerator("66545", "원룸형 냉장고", 824000, 2, 100) };
	Conditioner[] conds = { new Conditioner("12348", "통합형 에어컨", 3004000, 15),
			new Conditioner("99040", "신상 에어컨", 2123000, 30, 20) };

	public static void main(String[] args) {

		ProductTest pt = new ProductTest();

		System.out.println("****************** 티비 목록 ******************\n");

		for (Television tv : pt.tvs) {
			System.out.println(tv.toString());
		}

		System.out.println("\n****************** 냉장고 목록 ******************\n");

		for (Refrigerator ref : pt.refs) {
			System.out.println(ref.toString());
		}
		
		System.out.println("\n****************** 에어컨 목록 ******************\n");
		
		for (Conditioner cond : pt.conds) {
			System.out.println(cond.toString());
		}
		
	}
}
