package com.ssafy.digital;

public class Conditioner {

	String productNumber;
	String title;
	int price;
	int stock;
	int m3;
	
	public Conditioner() {

	}
	
	public Conditioner(String productNumber, String title, int price, int stock, int m3) {

		this.productNumber = productNumber;
		this.title = title;
		this.price = price;
		this.stock = stock;
		this.m3 = m3;
	}
	
	public Conditioner(String productNumber, String title, int price, int stock) {
		this(productNumber, title, price, stock, 0);
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getCapacity() {
		return m3;
	}

	public void setCapacity(int m3) {
		this.m3 = m3;
	}
	
	public String toString() {
		
		return "제품번호 : "+productNumber +"\t제품명 :"+ title+"\t가격 :"+ price +"\t재고 :"+stock+"\t평수"+ m3;
	}
	
	
}
