package com.ssafy.digital;

public class Refrigerator {

	String productNumber;
	String title;
	int price;
	int stock;
	int volume;
	
	public Refrigerator() {

	}

	public Refrigerator(String productNumber, String title, int price, int stock, int volume) {
		super();
		this.productNumber = productNumber;
		this.title = title;
		this.price = price;
		this.stock = stock;
		this.volume = volume;
	}

	public Refrigerator(String productNumber, String title, int price, int stock) {
		this(productNumber, title, price, stock, 0);
	}
	
	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public String toString() {
		
		return "제품번호 : "+productNumber +"\t제품명 :"+ title+"\t가격 :"+ price +"\t재고 :"+stock+"\t용량"+volume;
	}

}
