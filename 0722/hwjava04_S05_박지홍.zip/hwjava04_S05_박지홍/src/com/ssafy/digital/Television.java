package com.ssafy.digital;

public class Television {

	String productNumber;
	String title;
	int price;
	int stock;
	int inch;
	String displayType;
	
	public Television() {

	}

	public Television(String productNumber, String title, int price, int stock, int inch, String displayType) {
		
		this.productNumber = productNumber;
		this.title = title;
		this.price = price;
		this.stock = stock;
		this.inch = inch;
		this.displayType = displayType;
	}
	
	public Television (String productNumber, String title, int price, int stock ) {
		this(productNumber, title, price, stock, 0 ,"");
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}
	
	public String toString() {
		
		return "제품번호 : "+productNumber +"\t제품명 :"+ title+"\t가격 :"+ price +"\t재고 :"+stock+"\t인치 :"+ inch+"\t타입 :"+ displayType+"\n";
	}
	
	
}
