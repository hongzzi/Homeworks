package com.ssafy.model.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService{

	private static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	@Autowired
	ProductRepo repo;

	public List<Product> selectAll() {
		List<Product> products = repo.selectAll();
		return products;
	}

	public Product select(String id) {
		Product product = repo.select(id);
		return product;
	}

	@Transactional
	public int insert(Product product) {
		int result = repo.insert(product);
		return result;
	}

	@Transactional
	public int update(Product product) {
		int result = repo.update(product);
		return result;
	}

	@Transactional
	public int delete(String id) {
		int result = repo.delete(id);
		return result;
	}
	
}
