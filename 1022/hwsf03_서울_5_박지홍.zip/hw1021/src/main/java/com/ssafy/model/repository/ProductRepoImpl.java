package com.ssafy.model.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{

	private static Logger logger = LoggerFactory.getLogger(ProductRepoImpl.class);
	private final String ns = "com.ssafy.model.ProductMapper.";
	
	@Autowired
	SqlSession session;

	@Override
	public List<Product> selectAll() {
		return session.selectList(ns+"selectAll");
	}

	@Override
	public Product select(String id) {
		return session.selectOne(ns+"select", id);
	}

	@Override
	public int insert(Product product) {
		return session.insert(ns+"insert", product);
	}

	@Override
	public int update(Product product) {
		return session.update(ns+"update", product);
	}

	@Override
	public int delete(String id) {
		return session.delete(ns+"delete", id);
	}

}
