package com.ssafy.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {
	private static Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	ProductService pService;

	@GetMapping("/product/regist")
	public String registForm() {
		return "product/regist";
	}

	@PostMapping("/product/regist")
	public String regist(Product product, Model model, RedirectAttributes redir) {
		try {
			int a = pService.insert(product);
			redir.addFlashAttribute("message", "등록 성공");
		} catch (RuntimeException e) {
			logger.error("등록실패 : ", e);
			redir.addFlashAttribute("message", "등록에 실패했습니다. 다시 시도해주세요");
		}
		return "redirect:list";
	}

	@GetMapping("/product/list")
	public String getList(Model model) {
		model.addAttribute("list", pService.selectAll());
		return "product/list";
	}

}
