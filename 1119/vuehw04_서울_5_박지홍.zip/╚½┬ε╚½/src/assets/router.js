import VueRouter from "vue-router"
import List from "../components/EmpList.vue"
import Insert from "../components/insert.vue"
import SearchById from "../components/searchById"
import SearchByName from "../components/searchByName"
import Detail from "../components/Detail.vue"
import Update from "../components/update.vue"

const router = new VueRouter({
    routes : [
        {
            name: "main",
            path: "/",
            component: List
        },
        {
            name: "insert",
            path: "/insert",
            component: Insert
        },
        {
            name: "searchById",
            path: "/searchById",
            component: SearchById
        },
        {
            name: "searchByName",
            path: "/searchByName",
            component: SearchByName
        },
        {
            name: "detail",
            path: "/detail/:id",
            props: true,
            component: Detail
        },
        {
            name: "update",
            path: "/update/:id",
            props: true,
            component: Update
        }
    ]
})


export default router