<template>
  <div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-if="emp.id" @click="update(emp.id)">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary}}</td>
      </tr>
    </table>
    <h4>해당 직원을 매니저로 두고있는 직원들</h4>
        <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-for="e in emps" :key="e.id" @click="update(e.id)">
        <td>{{e.id}}</td>
        <td>{{e.name}}</td>
        <td>{{e.dept_id}}</td>
        <td>{{e.title}}</td>
        <td>{{e.salary}}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
import router from "../assets/router";

export default {
  props: ["id"], //라우터에서 넘겨주는 id 사용할 계획
  data() {
    return {
      loading: true,
      error: "",
      emps: [],
      emp: {}
    };
  },
  mounted() {
    console.log(this.id);
    this.loading = true;
    ajax
      .get("/findEmployeeById/"+this.id)
      .then(res => {
        this.emp = res.data;
      })
      .catch(e => {
        console.log(e);
      })
      .finally(() => {
        this.loading = false;
      });
    this.loading = true;
    ajax
      .get("/findEmployeesByManagerId/"+this.id)
      .then(res => {
        this.emps = res.data;
      })
      .catch(e => {
        console.log(e);
      })
      .finally(() => {
        this.loading = false;
      });
  },
  methods: {
    update(id) {
      router.push({
        path: "/update/" + id
      });
    }
  },
};
</script>

<style>
</style>