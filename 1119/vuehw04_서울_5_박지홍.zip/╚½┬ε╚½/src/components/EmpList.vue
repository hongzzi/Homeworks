<template>
  <div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
        <th>퇴사</th>
      </tr>
      <tr v-for="emp in emps" :key="emp.id" @click="detail(emp.id)">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary}}</td>
        <td>
          <input type="button" value="퇴사" @click="deleteEmp(emp.id)" />
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
import router from "../assets/router";

console.log(ajax);
export default {
  router,
  data() {
    return {
      emps: [],
      loading: false
    };
  },
  mounted() {
    this.loading = true;
    ajax
      .get("/findAllEmployees")
      .then(res => {
        this.emps = res.data;
      })
      .catch(e => {
        console.log(e);
      })
      .finally(() => {
        this.loading = false;
      });
  },
  methods: {
    detail(id) {
      router.push({
        path: "/detail/"+id
      });
    },
    deleteEmp(id) {
      this.loading = true;
      console.log(id);
      ajax
        .delete("/deleteEmployee/" + id)
        .then(res => {
          console.log(res.data.state);
        })
        .catch(e => {
          console.log(e);
        })
        .finally(() => {
          this.loading = false;
        });
    }
  }
};
</script>

<style>
</style>