<template>
  <div id="main-content">
    <h3>사원 등록하기</h3>
    <table class="content_table">
      <tr>
        <th>사원 아이디</th>
        <td>
          <input type="text" v-model="e.name" id="_name" disabled/>
        </td>
      </tr>
      <tr>
        <th>이름</th>
        <td>
          <input type="text" v-model="e.name" id="_name" />
        </td>
      </tr>
      <tr>
        <th>이메일</th>
        <td>
          <input type="text" v-model="e.mailid" id="_mail" />
        </td>
      </tr>
      <tr>
        <th>고용일</th>
        <td>
          <input type="date" v-model="e.start_date" id="_hiredate" />
        </td>
      </tr>
      <tr>
        <th>관리자</th>
        <td>
          <select v-model="e.manager_id">
            <option disabled value>관리자를 선택하세요.</option>
            <option :value="emp.id" v-for="emp in emps" v-bind:key="emp.id">{{emp.name}}</option>
          </select>
        </td>
      </tr>
      <tr>
        <th>직책</th>
        <td>
          <select v-model="e.title">
            <option disabled value>직책을 선택하세요.</option>
            <option :value="t.title" v-for="t in titles" v-bind:key="t.title">{{t.title}}</option>
          </select>
        </td>
      </tr>
      <tr>
        <th>부서</th>
        <td>
          <select v-model.number="e.dept_id">
            <option disabled value>부서를 선택하세요.</option>
            <option
              :value="dept.dept_id"
              v-for="dept in depts"
              v-bind:key="dept.dept_id"
            >{{dept.name}}-{{dept.region_id}}</option>
          </select>
        </td>
      </tr>
      <tr>
        <th>월급</th>
        <td>
          <input type="number" v-model.number="e.salary" />
        </td>
      </tr>
      <tr>
        <th>커미션</th>
        <td>
          <input type="text" v-model="e.commission_pct" />
        </td>
      </tr>
      <tr>
        <td>
          <input type="button" value="수정" @click="updateEmployee" />
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
import router from "../assets/router";

export default {
  props: ["id"], //라우터에서 넘겨주는 id 사용할 계획
  router,
  data() {
    return {
      emps: [],
      titles: [],
      depts: [],
      e: {}
    };
  },
  mounted() {
    let getE = ajax
      .get("/findEmployeeById/"+this.id)
      .then(res => {
        this.e = res.data;
        console.log(this.e);
      })
      .catch(error => {
        console.log(error);
      })
      .finally();
    let getemp = ajax
      .get("/findAllEmployees")
      .then(res => {
        this.emps = res.data;
        console.log(this.emps);
      })
      .catch(error => {
        console.log(error);
      })
      .finally();
    let getdept = ajax
      .get("/findAllDepartments")
      .then(res => {
        this.depts = res.data;
      })
      .catch(error => {
        console.log(error);
      })
      .finally();
    let gettitle = ajax
      .get("/findAllTitles")
      .then(res => {
        this.titles = res.data;
      })
      .catch(error => {
        console.log(error);
      })
      .finally();
    ajax.all([getE, getemp, getdept, gettitle]).then();
  },
  filters: {
    toFixed(num) {
      return num.toFixed(2);
    }
  },
  methods: {
    updateEmployee() {
      console.log(this.e);
      ajax
        .put("/updateEmployee", this.e)
        .then(res => {
          let result = res.data;
          if (result.state == "SUCCESS") {
            alert("사용자 수정 성공 : " + result.count);
          } else {
            alert("사용자 수정 실패");
          }
        })
        .catch(error => {
          alert(error + "사용자 수정 오류");
        })
        .finally(() => {
          console.log("끝~");
        });
    }
  }
};
</script>

<style>
</style>