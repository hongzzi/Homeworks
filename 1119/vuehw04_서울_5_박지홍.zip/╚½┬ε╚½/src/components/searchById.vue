<template>
  <div id="main-content">
    <h3>아이디 기반 검색</h3>
    <div class="searchbox">
      <select name="id" v-model="selectedId" @change="findById" v-cloak>
        <option v-for="emp in emps" v-bind:value="emp.id" v-bind:key="emp.id">{{emp.id}}</option>
      </select>
    </div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-if="emp.id">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary}}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";

export default {
  data() {
    return {
      selectedId: "",
      emp: {},
      emps: [],
      loading: false
    };
  },
  mounted() {
    this.loading = true;
    ajax
      .get("/findAllEmployees")
      .then(res => {
        this.emps = res.data;
      })
      .catch(e => {
        console.log(e);
      })
      .finally(() => {
        this.loading = false;
      });
  },
  methods: {
    findById() {
      this.loading = true;
      console.log(this.selectedId);
      ajax
        .get("/findEmployeeById/" + this.selectedId)
        .then(res => {
          this.emp = res.data;
        })
        .catch(e => {
          alert(e);
        })
        .finally(() => {
          console.log("작업 종료");
          this.loading = false;
        });
    }
  }
};
</script>

<style>
</style>