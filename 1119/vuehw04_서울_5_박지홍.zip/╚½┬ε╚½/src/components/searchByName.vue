<template>
  <div id="main-content">
    <h3>이름 기반 검색</h3>
    <div class="search_box">
      <span>이름으로 찾기</span>
      <input type="text" v-model="name" @keyup.enter="findbyname" />
    </div>
    <table class="list_table">
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-for="emp in emps" v-bind:key="emp.id">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.dept_id}}</td>
        <td>{{emp.title}}</td>
        <td>{{emp.salary | toFixed()}}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import ajax from "../js/http-commons.js";
export default {
  data() {
    return {
      name: "",
      emps: [],
      loading: false
    };
  },
  methods: {
    findbyname() {
      console.log(this.name);
      this.processing = true;
      ajax
        .get("/findLikeEmployees/" + this.name)
        .then(res => {
          console.log(res.data);
          this.emps = res.data;
        })
        .catch(e => {
          alert(e);
        })
        .finally(() => {
          console.log("작업 종료");
          this.isProcessing = false;
        });
    }
  }
};
</script>

<style>
</style>