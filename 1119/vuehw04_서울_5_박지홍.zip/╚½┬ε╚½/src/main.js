import Vue from 'vue'
import App from './App.vue'
// import "./css/table.css"  // css 파일 import

import VueRouter from "vue-router"

Vue.config.productionTip = true

// vue router 사용 선언
Vue.use(VueRouter);
new Vue({
  render: h => h(App),
}).$mount('#app')
