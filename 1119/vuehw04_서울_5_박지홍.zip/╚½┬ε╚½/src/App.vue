<template>
  <div id="app">
    <h1>SSAFY HRM LIST</h1>
    <div class="search_box">
      <nav>
        <a href=""><router-link to="/">모든사원보기 </router-link></a> | 
        <a href=""><router-link to="/insert">사원추가 </router-link></a> | 
        <a href=""><router-link to="/searchByName">이름으로찾기 </router-link></a> | 
        <a href=""><router-link to="/searchById">아이디로찾기 </router-link></a>
      </nav>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'
// import list from "./components/EmpList.vue";
// import searchById from "./components/searchById.vue";
// import searchByName from "./components/searchByName.vue";
// import insert from "./components/insert.vue";
import router from './assets/router.js'

export default {
  name: "app",
  router,
  components: {
    // HelloWorld
    // searchById,
    // searchByName,
    // insert
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
