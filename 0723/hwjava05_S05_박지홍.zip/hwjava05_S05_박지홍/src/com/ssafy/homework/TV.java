package com.ssafy.homework;

public class TV extends Product{
	
	private int size;
	private String type;
	
	public TV() {}
	
	public TV(String isbn, String name, int price, int stock, int size, String type) {
		super(isbn, name, price, stock);
		this.size = size;
		this.type = type;
	}
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	@Override
	public String toString() {
		return super.toString() + String.format("인치: %,3d inch | 디스플레이타입: %5s", this.size, this.type);
	}
}
