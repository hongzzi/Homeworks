package com.ssafy.homework;

public class ProductTest {
	public static void main(String[] args) {
		TV tv1 = new TV("958479","스마트뷰TV",1600000, 5, 75, "UHD");
		TV tv2 = new TV("123456","대우루컴즈TV",2000000, 3, 65, "LED");
		TV tv3 = new TV("654438","삼성스마트TV",5650000, 3, 55, "UHD");
		TV tv4 = new TV("321321","LGTV",500000, 12, 50, "LED");
		TV tv5 = new TV("185475","벽걸이TV",650000, 2, 40, "UHD");
		
		Refrigerator ref1 = new Refrigerator("852852","삼성냉장고", 4500000, 9, 450);
		Refrigerator ref2 = new Refrigerator("258258","딤채김치냉장고", 2600000, 2, 400);
		Refrigerator ref3 = new Refrigerator("999999","LG디오스 냉장고", 1500000, 8, 220);
		Refrigerator ref4 = new Refrigerator("457877","미니냉장고", 300000, 5, 220);
		Refrigerator ref5 = new Refrigerator("323333","양문형냉장고", 1900000, 10, 220);
		
		Product[] products = {tv1,tv2,tv3,tv4,tv5,ref1,ref2,ref3,ref4,ref5};
		ProductMgr pm = ProductMgr.getProductManager();
		
		
		for(Product product : products) {
			System.out.println(pm.addProduct(product)? "상품을 등록했습니다.":"더 이상 상품을 등록할 수 없습니다.");
			
		}
		
		pm.searchAll();
		System.out.println();
		
		System.out.println("===============상품번호 검색결과===============");
		System.out.println(pm.searchIsbn("123456").toString());
		
		
		System.out.println("===============상품명 검색결과===============");
		for(Product prod : pm.searchName("스마트")) {
			System.out.println(prod.toString());
		}
		
		
		System.out.println("===============TV 검색결과===============");
		for(Product prod : pm.searchTV()) {
			System.out.println(prod.toString());
		}
		
		
		System.out.println("===============냉장고 검색결과===============");
		for(Product prod : pm.searchRefrigerator()) {
			System.out.println(prod.toString());
		}
		
		
		System.out.println("===============50inch이상 티비 검색===============");
		for(Product prod : pm.searchTVOver(50)) {
			System.out.println(prod.toString());
		}

		
		System.out.println("===============400L이상 냉장고 검색결과===============");
		for(Product prod : pm.searchRefrigeratorOver(400)) {
			System.out.println(prod.toString());
		}
		
		
		// 상품번호로 가격 변경
		pm.changePrice("852852", 1800000);
		
		
		// 상품번호로 상품 삭제
		pm.deleteProduct("999999");
		
		
		System.out.println("===============전체 재고 상품 금액===============");
		System.out.println("전체 재고 금액: "+String.format("%,d", pm.getTotalStockPrice()));
		pm.printEachTotalStockPrice();

	}
}
