package com.ssafy.homework;

public class ProductMgr {
	
	Product[] products = new Product[10];
	
	private ProductMgr() {};
	
	private static ProductMgr pm = new ProductMgr();
	
	public static ProductMgr getProductManager() {
		return pm;
	}
	
	public boolean addProduct(Product prod) {
		
		for(int i=0;i<10;i++) {
			
			Product stored = products[i];
			
			if(stored==null) {
				products[i] = prod;
				return true;
			}
		}
		return false;
	}
	
	public void searchAll() {
		
		System.out.println("===============상품 목록===============");
		
		for(Product product : products) {
			
			if(product!=null) {
				System.out.println(product.toString());
			}
		}
		System.out.println("=======================================\n");
	}
	
	public Product searchIsbn(String isbn) {
		
		for(Product product : products) {
			
			if(product!=null && product.getIsbn().equals(isbn)) {
				
				return product;
			}
		}
		return null;
	}
	
	public Product[] searchName(String name) {
		
		Product[] temp = new Product[10];
		int idx = 0;
		
		for(Product product : products) {
			
			if(product!=null && product.getName().contains(name)) {
				temp[idx++] = product;
			}
		}
		if(idx==0){
			return null;		
		} else {
			Product[] temp2 = new Product[idx];
			System.arraycopy(temp, 0, temp2, 0, temp2.length);
			return temp2;
		}
	}
	
	public TV[] searchTV() {
		
		TV[] temp = new TV[10];
		int idx = 0;
		
		for(Product product : products) {
			
			if(product!=null && product instanceof TV) {
				TV tempTV = (TV)product;
				temp[idx++] = tempTV;
			}
		}
		if(idx==0){
			return null;
		} else {
			TV[] temp2 = new TV[idx];
			System.arraycopy(temp, 0, temp2, 0, temp2.length);
			return temp2;
		}
	}
	
	public Refrigerator[] searchRefrigerator() {
		
		Refrigerator[] temp = new Refrigerator[10];
		int idx = 0;
		
		for(Product product : products) {
			
			if(product!=null && product instanceof Refrigerator) {
				Refrigerator tempRefrigerator = (Refrigerator)product;
				temp[idx++] = tempRefrigerator;
			}
		}
		if(idx==0){
			return null;
		} else {
			Refrigerator[] temp2 = new Refrigerator[idx];
			System.arraycopy(temp, 0, temp2, 0, temp2.length);
			return temp2;
		}
	}
	
	public Refrigerator[] searchRefrigeratorOver(int size) {
		
		Refrigerator[] temp = new Refrigerator[10];
		int idx = 0;
		
		for(Product product : products) {
			
			if(product!=null && product instanceof Refrigerator) {
				Refrigerator tempRefrigerator = (Refrigerator)product;
				if(tempRefrigerator.getSize()>=size) {
					temp[idx++] = tempRefrigerator;
				}
			}
		}
		if(idx==0){
			return null;
		} else {
			Refrigerator[] temp2 = new Refrigerator[idx];
			System.arraycopy(temp, 0, temp2, 0, temp2.length);
			return temp2;
		}
	}
	
	public TV[] searchTVOver(int size) {
		
		TV[] temp = new TV[10];
		int idx = 0;
		
		for(Product prod : products) {
			if(prod!=null && prod instanceof TV) {
				TV tempTV = (TV)prod;
				if(tempTV.getSize()>=size) {
					temp[idx++] = tempTV;
				}
			}
		}
		if(idx==0){
			return null;
		} else {
			TV[] temp2 = new TV[idx];
			System.arraycopy(temp, 0, temp2, 0, temp2.length);
			return temp2;
		}
	}
	
	public void changePrice(String isbn, int price) {
		
		System.out.println("===============상품 금액 변경===============");
		for(Product prod : products) {
			
			if(prod!=null && prod.getIsbn().equals(isbn)) {
				int prevPrice = prod.getPrice();
				prod.setPrice(price);
				System.out.printf("상품번호: %s의 금액이 변경되었습니다( %d => %d)\n",isbn,prevPrice,price);
				System.out.println("=======================================\n");
				return;
			}
		}
		System.out.println("해당하는 상품이 존재하지 않습니다.");
		System.out.println("=======================================\n");
	}
	
	
	public void deleteProduct(String isbn) {
		
		System.out.println("===============상품 삭제===============");
		
		Product deletedProduct;
		
		int findIdx = -1;
		int productsLength = 0;
		
		for(int i=0;i<10;i++) {
			
			if(products[i]!=null) {
				productsLength++;
				if(products[i].getIsbn().equals(isbn)) {
					
					findIdx = i;
				}
			}
		}
		
		if(findIdx==-1) {
			System.out.println("삭제할 상품이 존재하지 않습니다.");
			
		} else {
			
			deletedProduct = products[findIdx];
			products[findIdx]=null;
			
			for(int i=findIdx+1;i<productsLength;i++) {
				
				products[i-1] = products[i];
				
				if(i == productsLength-1) {
					
					products[i]=null;
				}
			}
			System.out.println("해당 상품을 삭제했습니다 : " + deletedProduct.toString());
		}
		System.out.println("=======================================\n");
	}
	
	public long getTotalStockPrice() {
		
		long sum = 0;
		
		for(Product prod : products) {
			
			if(prod!=null) {
				
				sum += ((long)prod.getPrice()*(long)prod.getStock());
			}
		}
		return sum;
	}
	
	public void printEachTotalStockPrice() {
		
		for(Product prod : products) {
			
			if(prod!=null) {
				
				System.out.println(prod.toString()+String.format(" ---> 재고 금액: %,d", (long)prod.getPrice()*(long)prod.getStock()));
			}
		}
	}
}
